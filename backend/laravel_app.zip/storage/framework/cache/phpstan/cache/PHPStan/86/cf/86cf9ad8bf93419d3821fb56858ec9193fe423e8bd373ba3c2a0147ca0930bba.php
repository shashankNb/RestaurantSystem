<?php declare(strict_types = 1);

// ftm-/var/www/html/vendor/larastan/larastan/stubs/common/Http/Request.stub
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'a203f51dfb2013da30565960f687e0d7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '416f99beec350d8545f4252b4cc03146' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'header',
         'templatePhpDocNodes' => 
        array (
          'TDefault' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TDefault',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\UnionTypeNode::__set_state(array(
                 'types' => 
                array (
                  0 => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => 'string',
                     'attributes' => 
                    array (
                      'startLine' => 4,
                      'endLine' => 4,
                    ),
                  )),
                  1 => 
                  \PHPStan\PhpDocParser\Ast\Type\GenericTypeNode::__set_state(array(
                     'type' => 
                    \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                       'name' => 'array',
                       'attributes' => 
                      array (
                        'startLine' => 4,
                        'endLine' => 4,
                      ),
                    )),
                     'genericTypes' => 
                    array (
                      0 => 
                      \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                         'name' => 'string',
                         'attributes' => 
                        array (
                          'startLine' => 4,
                          'endLine' => 4,
                        ),
                      )),
                      1 => 
                      \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                         'name' => 'string',
                         'attributes' => 
                        array (
                          'startLine' => 4,
                          'endLine' => 4,
                        ),
                      )),
                    ),
                     'variances' => 
                    array (
                      0 => 'invariant',
                      1 => 'invariant',
                    ),
                     'attributes' => 
                    array (
                      'startLine' => 4,
                      'endLine' => 4,
                    ),
                  )),
                  2 => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => 'null',
                     'attributes' => 
                    array (
                      'startLine' => 4,
                      'endLine' => 4,
                    ),
                  )),
                ),
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/vendor/larastan/larastan/stubs/common/Http/Request.stub' => 'a92f29774319bfe9ced18b46cd1175313c3922b557e1cbabf40924f3b9ba3cf9',
    ),
  ),
));