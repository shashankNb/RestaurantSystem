<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../chillerlan/php-qrcode/src/QROptions.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-925154ea4d963186d32481f7d94c474933bafd524bb74712f816301b4f6baee8-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'chillerlan\\qrcode\\qroptions' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));