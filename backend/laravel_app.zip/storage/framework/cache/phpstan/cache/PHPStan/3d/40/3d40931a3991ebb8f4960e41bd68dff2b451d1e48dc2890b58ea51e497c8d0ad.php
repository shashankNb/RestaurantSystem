<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-228d6b7c339e8f80c507146812ebdc6a1e9ce3bc030957b4673ba759c4069879-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\view\\middleware\\shareerrorsfromsession' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));