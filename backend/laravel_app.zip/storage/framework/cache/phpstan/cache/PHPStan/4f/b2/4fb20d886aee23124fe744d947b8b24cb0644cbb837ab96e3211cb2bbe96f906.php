<?php declare(strict_types = 1);

// ftm-/var/www/html/database/factories/OrderItemModifierFactory.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '0e6e9b344a4e846da5e1d79afd6f21c4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Database\\Factories',
         'uses' => 
        array (
          'orderitem' => 'App\\Models\\OrderItem',
          'orderitemmodifier' => 'App\\Models\\OrderItemModifier',
          'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
        ),
         'className' => 'Database\\Factories\\OrderItemModifierFactory',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '65557e7929eacd7e1cf6a9f56f0c59a1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Database\\Factories',
         'uses' => 
        array (
          'orderitem' => 'App\\Models\\OrderItem',
          'orderitemmodifier' => 'App\\Models\\OrderItemModifier',
          'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
        ),
         'className' => 'Database\\Factories\\OrderItemModifierFactory',
         'functionName' => 'definition',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Database\\Factories',
           'uses' => 
          array (
            'orderitem' => 'App\\Models\\OrderItem',
            'orderitemmodifier' => 'App\\Models\\OrderItemModifier',
            'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
          ),
           'className' => 'Database\\Factories\\OrderItemModifierFactory',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/database/factories/OrderItemModifierFactory.php' => '2ba1763366946b11ebb8573b8471eafe297826dd4480cb97cb687221f227cb95',
    ),
  ),
));