<?php declare(strict_types = 1);

// ftm-/var/www/html/app/Http/Controllers/Api/QuoteController.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '60cb6709f310268c72312829299ebe4d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Http\\Controllers\\Api',
         'uses' => 
        array (
          'controller' => 'App\\Http\\Controllers\\Controller',
          'quoterequest' => 'App\\Http\\Requests\\QuoteRequest',
          'quoteresource' => 'App\\Http\\Resources\\QuoteResource',
          'restaurant' => 'App\\Models\\Restaurant',
          'pricingservice' => 'App\\Services\\PricingService',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
        ),
         'className' => 'App\\Http\\Controllers\\Api\\QuoteController',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '15f5a53ee81e376f980b53b9872d4ca9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Http\\Controllers\\Api',
         'uses' => 
        array (
          'controller' => 'App\\Http\\Controllers\\Controller',
          'quoterequest' => 'App\\Http\\Requests\\QuoteRequest',
          'quoteresource' => 'App\\Http\\Resources\\QuoteResource',
          'restaurant' => 'App\\Models\\Restaurant',
          'pricingservice' => 'App\\Services\\PricingService',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
        ),
         'className' => 'App\\Http\\Controllers\\Api\\QuoteController',
         'functionName' => '__invoke',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/app/Http/Controllers/Api/QuoteController.php' => '2bd00b4ec35168dc62a35c800e081ee8bbfb38c75731028fbd649da02fe6e213',
    ),
  ),
));