<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/forms/src/Components/TagsInput.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-a37efd38f2bb3d53e01a39de13d4447475eeb1b5654028ceb61a9b12972ca0b0-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\forms\\components\\tagsinput' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));