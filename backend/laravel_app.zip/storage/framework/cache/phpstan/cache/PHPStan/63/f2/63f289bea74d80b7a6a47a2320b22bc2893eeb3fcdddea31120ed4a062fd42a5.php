<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/schemas/src/Concerns/CanBeDisabled.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Filament\Schemas\Concerns\CanBeDisabled
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-e518f6f325d93454ec0e679e2c70c78ccb86e8aae7c6cfa7b8be07878f6dfe9f-8.5.11-6.73.0.5',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Filament\\Schemas\\Concerns\\CanBeDisabled',
        'filename' => '/var/www/html/vendor/composer/../filament/schemas/src/Concerns/CanBeDisabled.php',
      ),
    ),
    'namespace' => 'Filament\\Schemas\\Concerns',
    'name' => 'Filament\\Schemas\\Concerns\\CanBeDisabled',
    'shortName' => 'CanBeDisabled',
    'isInterface' => false,
    'isTrait' => true,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 7,
    'endLine' => 27,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => NULL,
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
      'isDisabled' => 
      array (
        'declaringClassName' => 'Filament\\Schemas\\Concerns\\CanBeDisabled',
        'implementingClassName' => 'Filament\\Schemas\\Concerns\\CanBeDisabled',
        'name' => 'isDisabled',
        'modifiers' => 2,
        'type' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionUnionType',
          'data' => 
          array (
            'types' => 
            array (
              0 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'bool',
                  'isIdentifier' => true,
                ),
              ),
              1 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'Closure',
                  'isIdentifier' => false,
                ),
              ),
            ),
          ),
        ),
        'default' => 
        array (
          'code' => 'false',
          'attributes' => 
          array (
            'startLine' => 9,
            'endLine' => 9,
            'startTokenPos' => 30,
            'startFilePos' => 124,
            'endTokenPos' => 30,
            'endFilePos' => 128,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 9,
        'endLine' => 9,
        'startColumn' => 5,
        'endColumn' => 49,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
    ),
    'immediateMethods' => 
    array (
      'disabled' => 
      array (
        'name' => 'disabled',
        'parameters' => 
        array (
          'condition' => 
          array (
            'name' => 'condition',
            'default' => 
            array (
              'code' => 'true',
              'attributes' => 
              array (
                'startLine' => 11,
                'endLine' => 11,
                'startTokenPos' => 49,
                'startFilePos' => 189,
                'endTokenPos' => 49,
                'endFilePos' => 192,
              ),
            ),
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionUnionType',
              'data' => 
              array (
                'types' => 
                array (
                  0 => 
                  array (
                    'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                    'data' => 
                    array (
                      'name' => 'bool',
                      'isIdentifier' => true,
                    ),
                  ),
                  1 => 
                  array (
                    'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                    'data' => 
                    array (
                      'name' => 'Closure',
                      'isIdentifier' => false,
                    ),
                  ),
                ),
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 11,
            'endLine' => 11,
            'startColumn' => 30,
            'endColumn' => 61,
            'parameterIndex' => 0,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'static',
            'isIdentifier' => false,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 11,
        'endLine' => 16,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Filament\\Schemas\\Concerns',
        'declaringClassName' => 'Filament\\Schemas\\Concerns\\CanBeDisabled',
        'implementingClassName' => 'Filament\\Schemas\\Concerns\\CanBeDisabled',
        'currentClassName' => 'Filament\\Schemas\\Concerns\\CanBeDisabled',
        'aliasName' => NULL,
      ),
      'isDisabled' => 
      array (
        'name' => 'isDisabled',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'bool',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 18,
        'endLine' => 21,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Filament\\Schemas\\Concerns',
        'declaringClassName' => 'Filament\\Schemas\\Concerns\\CanBeDisabled',
        'implementingClassName' => 'Filament\\Schemas\\Concerns\\CanBeDisabled',
        'currentClassName' => 'Filament\\Schemas\\Concerns\\CanBeDisabled',
        'aliasName' => NULL,
      ),
      'isEnabled' => 
      array (
        'name' => 'isEnabled',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'bool',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 23,
        'endLine' => 26,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Filament\\Schemas\\Concerns',
        'declaringClassName' => 'Filament\\Schemas\\Concerns\\CanBeDisabled',
        'implementingClassName' => 'Filament\\Schemas\\Concerns\\CanBeDisabled',
        'currentClassName' => 'Filament\\Schemas\\Concerns\\CanBeDisabled',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));