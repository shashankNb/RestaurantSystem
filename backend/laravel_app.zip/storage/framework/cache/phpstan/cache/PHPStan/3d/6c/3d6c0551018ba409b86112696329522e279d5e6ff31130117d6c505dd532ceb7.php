<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../stripe/stripe-php/lib/Service/SubscriptionService.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-67040c01f26f5252251e79d53d8bca2e95ddf12f3626b4b1ee9c0fc259a2eeae-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'stripe\\service\\subscriptionservice' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));