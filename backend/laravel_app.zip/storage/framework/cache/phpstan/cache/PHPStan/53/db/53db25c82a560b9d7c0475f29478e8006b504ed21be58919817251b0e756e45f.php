<?php declare(strict_types = 1);

// ftm-/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '45ac0cc60ca223921a15ad2a0a01cc67' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
          'TModel' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TModel',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'Model',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
               'default' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'Model',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 2,
                'endLine' => 2,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'beebf830720347488899f422636462b5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'contenttabposition' => 'Filament\\Resources\\Pages\\Enums\\ContentTabPosition',
          'relationgroup' => 'Filament\\Resources\\RelationManagers\\RelationGroup',
          'relationmanager' => 'Filament\\Resources\\RelationManagers\\RelationManager',
          'relationmanagerconfiguration' => 'Filament\\Resources\\RelationManagers\\RelationManagerConfiguration',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'group' => 'Filament\\Schemas\\Components\\Group',
          'livewire' => 'Filament\\Schemas\\Components\\Livewire',
          'tabs' => 'Filament\\Schemas\\Components\\Tabs',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'arr' => 'Illuminate\\Support\\Arr',
          'url' => 'Livewire\\Attributes\\Url',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'dd6bb80b1a8788fe9535949325682cea' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'contenttabposition' => 'Filament\\Resources\\Pages\\Enums\\ContentTabPosition',
          'relationgroup' => 'Filament\\Resources\\RelationManagers\\RelationGroup',
          'relationmanager' => 'Filament\\Resources\\RelationManagers\\RelationManager',
          'relationmanagerconfiguration' => 'Filament\\Resources\\RelationManagers\\RelationManagerConfiguration',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'group' => 'Filament\\Schemas\\Components\\Group',
          'livewire' => 'Filament\\Schemas\\Components\\Livewire',
          'tabs' => 'Filament\\Schemas\\Components\\Tabs',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'arr' => 'Illuminate\\Support\\Arr',
          'url' => 'Livewire\\Attributes\\Url',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getAllRelationManagers',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'eed64c4535e9418c0b2857c49313936f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'contenttabposition' => 'Filament\\Resources\\Pages\\Enums\\ContentTabPosition',
          'relationgroup' => 'Filament\\Resources\\RelationManagers\\RelationGroup',
          'relationmanager' => 'Filament\\Resources\\RelationManagers\\RelationManager',
          'relationmanagerconfiguration' => 'Filament\\Resources\\RelationManagers\\RelationManagerConfiguration',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'group' => 'Filament\\Schemas\\Components\\Group',
          'livewire' => 'Filament\\Schemas\\Components\\Livewire',
          'tabs' => 'Filament\\Schemas\\Components\\Tabs',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'arr' => 'Illuminate\\Support\\Arr',
          'url' => 'Livewire\\Attributes\\Url',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getCachedRelationManagers',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '182d07d7285253194190ef81c21e77a6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'contenttabposition' => 'Filament\\Resources\\Pages\\Enums\\ContentTabPosition',
          'relationgroup' => 'Filament\\Resources\\RelationManagers\\RelationGroup',
          'relationmanager' => 'Filament\\Resources\\RelationManagers\\RelationManager',
          'relationmanagerconfiguration' => 'Filament\\Resources\\RelationManagers\\RelationManagerConfiguration',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'group' => 'Filament\\Schemas\\Components\\Group',
          'livewire' => 'Filament\\Schemas\\Components\\Livewire',
          'tabs' => 'Filament\\Schemas\\Components\\Tabs',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'arr' => 'Illuminate\\Support\\Arr',
          'url' => 'Livewire\\Attributes\\Url',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getRelationManagers',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '60df9b7a4fb9d6c80cf34aba4348c446' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'contenttabposition' => 'Filament\\Resources\\Pages\\Enums\\ContentTabPosition',
          'relationgroup' => 'Filament\\Resources\\RelationManagers\\RelationGroup',
          'relationmanager' => 'Filament\\Resources\\RelationManagers\\RelationManager',
          'relationmanagerconfiguration' => 'Filament\\Resources\\RelationManagers\\RelationManagerConfiguration',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'group' => 'Filament\\Schemas\\Components\\Group',
          'livewire' => 'Filament\\Schemas\\Components\\Livewire',
          'tabs' => 'Filament\\Schemas\\Components\\Tabs',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'arr' => 'Illuminate\\Support\\Arr',
          'url' => 'Livewire\\Attributes\\Url',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'normalizeRelationManagerClass',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '831a499ea4f358bdd9d0568aea744b7d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'contenttabposition' => 'Filament\\Resources\\Pages\\Enums\\ContentTabPosition',
          'relationgroup' => 'Filament\\Resources\\RelationManagers\\RelationGroup',
          'relationmanager' => 'Filament\\Resources\\RelationManagers\\RelationManager',
          'relationmanagerconfiguration' => 'Filament\\Resources\\RelationManagers\\RelationManagerConfiguration',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'group' => 'Filament\\Schemas\\Components\\Group',
          'livewire' => 'Filament\\Schemas\\Components\\Livewire',
          'tabs' => 'Filament\\Schemas\\Components\\Tabs',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'arr' => 'Illuminate\\Support\\Arr',
          'url' => 'Livewire\\Attributes\\Url',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'renderingHasRelationManagers',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '9ab7331cd97332eecb74ea1871cdf87c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'contenttabposition' => 'Filament\\Resources\\Pages\\Enums\\ContentTabPosition',
          'relationgroup' => 'Filament\\Resources\\RelationManagers\\RelationGroup',
          'relationmanager' => 'Filament\\Resources\\RelationManagers\\RelationManager',
          'relationmanagerconfiguration' => 'Filament\\Resources\\RelationManagers\\RelationManagerConfiguration',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'group' => 'Filament\\Schemas\\Components\\Group',
          'livewire' => 'Filament\\Schemas\\Components\\Livewire',
          'tabs' => 'Filament\\Schemas\\Components\\Tabs',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'arr' => 'Illuminate\\Support\\Arr',
          'url' => 'Livewire\\Attributes\\Url',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'hasCombinedRelationManagerTabsWithContent',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'bccad15045efab786ea5ae3a317773e6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'contenttabposition' => 'Filament\\Resources\\Pages\\Enums\\ContentTabPosition',
          'relationgroup' => 'Filament\\Resources\\RelationManagers\\RelationGroup',
          'relationmanager' => 'Filament\\Resources\\RelationManagers\\RelationManager',
          'relationmanagerconfiguration' => 'Filament\\Resources\\RelationManagers\\RelationManagerConfiguration',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'group' => 'Filament\\Schemas\\Components\\Group',
          'livewire' => 'Filament\\Schemas\\Components\\Livewire',
          'tabs' => 'Filament\\Schemas\\Components\\Tabs',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'arr' => 'Illuminate\\Support\\Arr',
          'url' => 'Livewire\\Attributes\\Url',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getBaseContentTabComponent',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'f287d9ba268f267ff2e38cb8d904e9e1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'contenttabposition' => 'Filament\\Resources\\Pages\\Enums\\ContentTabPosition',
          'relationgroup' => 'Filament\\Resources\\RelationManagers\\RelationGroup',
          'relationmanager' => 'Filament\\Resources\\RelationManagers\\RelationManager',
          'relationmanagerconfiguration' => 'Filament\\Resources\\RelationManagers\\RelationManagerConfiguration',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'group' => 'Filament\\Schemas\\Components\\Group',
          'livewire' => 'Filament\\Schemas\\Components\\Livewire',
          'tabs' => 'Filament\\Schemas\\Components\\Tabs',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'arr' => 'Illuminate\\Support\\Arr',
          'url' => 'Livewire\\Attributes\\Url',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getContentTabLabel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'd36444c2b5171f2c2b6830ade90aabd3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'contenttabposition' => 'Filament\\Resources\\Pages\\Enums\\ContentTabPosition',
          'relationgroup' => 'Filament\\Resources\\RelationManagers\\RelationGroup',
          'relationmanager' => 'Filament\\Resources\\RelationManagers\\RelationManager',
          'relationmanagerconfiguration' => 'Filament\\Resources\\RelationManagers\\RelationManagerConfiguration',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'group' => 'Filament\\Schemas\\Components\\Group',
          'livewire' => 'Filament\\Schemas\\Components\\Livewire',
          'tabs' => 'Filament\\Schemas\\Components\\Tabs',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'arr' => 'Illuminate\\Support\\Arr',
          'url' => 'Livewire\\Attributes\\Url',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getContentTabIcon',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '3806a3270d6723e86810a49f830448bf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'contenttabposition' => 'Filament\\Resources\\Pages\\Enums\\ContentTabPosition',
          'relationgroup' => 'Filament\\Resources\\RelationManagers\\RelationGroup',
          'relationmanager' => 'Filament\\Resources\\RelationManagers\\RelationManager',
          'relationmanagerconfiguration' => 'Filament\\Resources\\RelationManagers\\RelationManagerConfiguration',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'group' => 'Filament\\Schemas\\Components\\Group',
          'livewire' => 'Filament\\Schemas\\Components\\Livewire',
          'tabs' => 'Filament\\Schemas\\Components\\Tabs',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'arr' => 'Illuminate\\Support\\Arr',
          'url' => 'Livewire\\Attributes\\Url',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getContentTabPosition',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '4b7e89ace47dfa96454ae9e89b4dd4e1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'contenttabposition' => 'Filament\\Resources\\Pages\\Enums\\ContentTabPosition',
          'relationgroup' => 'Filament\\Resources\\RelationManagers\\RelationGroup',
          'relationmanager' => 'Filament\\Resources\\RelationManagers\\RelationManager',
          'relationmanagerconfiguration' => 'Filament\\Resources\\RelationManagers\\RelationManagerConfiguration',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'group' => 'Filament\\Schemas\\Components\\Group',
          'livewire' => 'Filament\\Schemas\\Components\\Livewire',
          'tabs' => 'Filament\\Schemas\\Components\\Tabs',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'arr' => 'Illuminate\\Support\\Arr',
          'url' => 'Livewire\\Attributes\\Url',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getRelationManagersContentComponent',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\HasRelationManagers',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '6323cf9d55d7b347a1343733ea588dc6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'action' => 'Filament\\Actions\\Action',
          'deleteaction' => 'Filament\\Actions\\DeleteAction',
          'forcedeleteaction' => 'Filament\\Actions\\ForceDeleteAction',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'locked' => 'Livewire\\Attributes\\Locked',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'cc3062d9738abaa6d742a74bc18dfdb0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'action' => 'Filament\\Actions\\Action',
          'deleteaction' => 'Filament\\Actions\\DeleteAction',
          'forcedeleteaction' => 'Filament\\Actions\\ForceDeleteAction',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'locked' => 'Livewire\\Attributes\\Locked',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'mountCanAuthorizeAccess',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '35894a6d12b28d8083d852a6a519b544' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'action' => 'Filament\\Actions\\Action',
          'deleteaction' => 'Filament\\Actions\\DeleteAction',
          'forcedeleteaction' => 'Filament\\Actions\\ForceDeleteAction',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'locked' => 'Livewire\\Attributes\\Locked',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'hydrateCanAuthorizeAccess',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'a3c88dfb8331ff38cab4110c62fc8bf4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'action' => 'Filament\\Actions\\Action',
          'deleteaction' => 'Filament\\Actions\\DeleteAction',
          'forcedeleteaction' => 'Filament\\Actions\\ForceDeleteAction',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'locked' => 'Livewire\\Attributes\\Locked',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'resolveRecord',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'cfcceafad5ab6cef4173fd126a23f3b0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'action' => 'Filament\\Actions\\Action',
          'deleteaction' => 'Filament\\Actions\\DeleteAction',
          'forcedeleteaction' => 'Filament\\Actions\\ForceDeleteAction',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'locked' => 'Livewire\\Attributes\\Locked',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getBaseRecord',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '8813b2296a2439f49a1be7fe95857a91' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'action' => 'Filament\\Actions\\Action',
          'deleteaction' => 'Filament\\Actions\\DeleteAction',
          'forcedeleteaction' => 'Filament\\Actions\\ForceDeleteAction',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'locked' => 'Livewire\\Attributes\\Locked',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'hasRecord',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '140454be1c5ef8c027cdbe23be987ded' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'action' => 'Filament\\Actions\\Action',
          'deleteaction' => 'Filament\\Actions\\DeleteAction',
          'forcedeleteaction' => 'Filament\\Actions\\ForceDeleteAction',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'locked' => 'Livewire\\Attributes\\Locked',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getRecordTitle',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'd4415ba11f66fd7d46e7c95929366e78' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'action' => 'Filament\\Actions\\Action',
          'deleteaction' => 'Filament\\Actions\\DeleteAction',
          'forcedeleteaction' => 'Filament\\Actions\\ForceDeleteAction',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'locked' => 'Livewire\\Attributes\\Locked',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getBreadcrumbs',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '1d0593178da5819b838451bfab27342b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'action' => 'Filament\\Actions\\Action',
          'deleteaction' => 'Filament\\Actions\\DeleteAction',
          'forcedeleteaction' => 'Filament\\Actions\\ForceDeleteAction',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'locked' => 'Livewire\\Attributes\\Locked',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'afterActionCalled',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'd2f24b4d7de5948930dbf5604445c66e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'action' => 'Filament\\Actions\\Action',
          'deleteaction' => 'Filament\\Actions\\DeleteAction',
          'forcedeleteaction' => 'Filament\\Actions\\ForceDeleteAction',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'locked' => 'Livewire\\Attributes\\Locked',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getSubNavigationParameters',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '990deec286542c14c7f2e225c9eae528' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'action' => 'Filament\\Actions\\Action',
          'deleteaction' => 'Filament\\Actions\\DeleteAction',
          'forcedeleteaction' => 'Filament\\Actions\\ForceDeleteAction',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'locked' => 'Livewire\\Attributes\\Locked',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getSubNavigation',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '12f3e207272689d152c3ed921a5d1ab8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'action' => 'Filament\\Actions\\Action',
          'deleteaction' => 'Filament\\Actions\\DeleteAction',
          'forcedeleteaction' => 'Filament\\Actions\\ForceDeleteAction',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'locked' => 'Livewire\\Attributes\\Locked',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getWidgetData',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'b7aa573c5524d308b5aacee075d1cb98' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'action' => 'Filament\\Actions\\Action',
          'deleteaction' => 'Filament\\Actions\\DeleteAction',
          'forcedeleteaction' => 'Filament\\Actions\\ForceDeleteAction',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'locked' => 'Livewire\\Attributes\\Locked',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getMountedActionSchemaModel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '96a5a1905dc799186504b3a54f329080' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'action' => 'Filament\\Actions\\Action',
          'deleteaction' => 'Filament\\Actions\\DeleteAction',
          'forcedeleteaction' => 'Filament\\Actions\\ForceDeleteAction',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'locked' => 'Livewire\\Attributes\\Locked',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getDefaultActionRecord',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '98d4902245d46f5d5d1b055e83d8c39c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'action' => 'Filament\\Actions\\Action',
          'deleteaction' => 'Filament\\Actions\\DeleteAction',
          'forcedeleteaction' => 'Filament\\Actions\\ForceDeleteAction',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'locked' => 'Livewire\\Attributes\\Locked',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getDefaultActionRecordTitle',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'a817ab6606c2d3d282e5e60bf44cc2f8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages\\Concerns',
         'uses' => 
        array (
          'action' => 'Filament\\Actions\\Action',
          'deleteaction' => 'Filament\\Actions\\DeleteAction',
          'forcedeleteaction' => 'Filament\\Actions\\ForceDeleteAction',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'locked' => 'Livewire\\Attributes\\Locked',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getDefaultActionSuccessRedirectUrl',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php',
          1 => 'Filament\\Resources\\Pages\\ViewRecord',
          2 => 'Filament\\Resources\\Pages\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'a63e9fea076abc849bc162fc23eb8bc9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getNavigationIcon',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '61d88122528c09b5508d7dee09773004' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getBreadcrumb',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'da4b947aa7c6b50329d0f0b13ad03e90' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getNavigationLabel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8b1b440574972868c5e1b184062590fc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getContentTabLabel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dc57be1f790d1cc4111ffe49739b2997' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'mount',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '008c7fc032e3df9dd087da4b50fad816' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'authorizeAccess',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7d16c74b17a4a134bfc390161d15f1e4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'hydrate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7f39ba703058544491100e38a3da7a45' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'hasInfolist',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '650f5fe30c2b8c48891281b260c500fa' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'fillForm',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0c8c7eedf976661a0bfbfafb5bbf9963' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'fillFormWithDataAndCallHooks',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '69f059a75340651fa37ac7c25b33a9f8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'refreshFormData',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c47d6aeb243f058003d801809a781167' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'mutateFormDataBeforeFill',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '835c9337c81e384409e09f0bc88020b5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getDefaultActionSchemaResolver',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'de89596c231dec538a93eb5315fd326e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getTitle',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'beb2ff291e04caf47fb1b19c91f7e71c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'defaultForm',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cdc6beb835c1cbd3720cdafc8686a8ba' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'form',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '69995eb1aa8acb8781123f4db3cd5cf7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'defaultInfolist',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6c63c9eb47fc2c6b2c172c820642ec4e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'infolist',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c82a05b3ece51550f7e70257110635f6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'shouldRegisterNavigation',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '653de794a27a1b2279860958edf4467b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'content',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '09acf1e16ecab4d196b7e5d7d8085458' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getFormContentComponent',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3029a05d78fd875459170ab31a01b373' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getInfolistContentComponent',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1dd88009784bda617dd9492713801730' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getContentTabComponent',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a8309e13802faaffdcc7c5ee5fe9891b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getPageClasses',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c2dfd1259bcabfd53275edd1918de840' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getDefaultTestingSchemaName',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5fa283260df2980361eb08c6f4aaafcf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Resources\\Pages',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'editaction' => 'Filament\\Actions\\EditAction',
          'viewaction' => 'Filament\\Actions\\ViewAction',
          'filament' => 'Filament\\Facades\\Filament',
          'component' => 'Filament\\Schemas\\Components\\Component',
          'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
          'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
          'schema' => 'Filament\\Schemas\\Schema',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Resources\\Pages\\ViewRecord',
         'functionName' => 'getRecord',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Resources\\Pages',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'createaction' => 'Filament\\Actions\\CreateAction',
            'editaction' => 'Filament\\Actions\\EditAction',
            'viewaction' => 'Filament\\Actions\\ViewAction',
            'filament' => 'Filament\\Facades\\Filament',
            'component' => 'Filament\\Schemas\\Components\\Component',
            'embeddedschema' => 'Filament\\Schemas\\Components\\EmbeddedSchema',
            'tab' => 'Filament\\Schemas\\Components\\Tabs\\Tab',
            'schema' => 'Filament\\Schemas\\Schema',
            'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
            'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
            'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
          ),
           'className' => 'Filament\\Resources\\Pages\\ViewRecord',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/vendor/filament/filament/src/Resources/Pages/ViewRecord.php' => 'b5f1957666cf4de85a1a7ca16b552f26eae93c1bf4edf9fa1833c0d05270ffff',
      '/var/www/html/vendor/composer/../filament/filament/src/Resources/Pages/Concerns/HasRelationManagers.php' => '1bf5bdd8ff4a1d2ad52b0eac26762a5765618dbdd3df6da255ded2f754727186',
      '/var/www/html/vendor/composer/../filament/filament/src/Resources/Pages/Concerns/InteractsWithRecord.php' => '377b49a7db1837db233ca0d7c04c16a68a5432659a7e371983070900ede5ae76',
    ),
  ),
));