<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/filament/src/Resources/Resource/Concerns/CanGenerateUrls.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6b52ea527c8d59dae0e48147f2887dbf594788c6b53b07ae3ef0cfce5a92b470-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\resources\\resource\\concerns\\cangenerateurls' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));