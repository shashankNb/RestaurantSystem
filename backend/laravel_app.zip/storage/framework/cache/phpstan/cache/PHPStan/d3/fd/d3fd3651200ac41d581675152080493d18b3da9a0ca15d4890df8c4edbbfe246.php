<?php declare(strict_types = 1);

// ftm-/var/www/html/app/Http/Resources/OpeningHourResource.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'fae4c8e6fd88695df00e3400d335e116' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Http\\Resources',
         'uses' => 
        array (
          'openinghour' => 'App\\Models\\OpeningHour',
          'request' => 'Illuminate\\Http\\Request',
          'jsonresource' => 'Illuminate\\Http\\Resources\\Json\\JsonResource',
        ),
         'className' => 'App\\Http\\Resources\\OpeningHourResource',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5107c44b525715ed75a607cea79a063c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Http\\Resources',
         'uses' => 
        array (
          'openinghour' => 'App\\Models\\OpeningHour',
          'request' => 'Illuminate\\Http\\Request',
          'jsonresource' => 'Illuminate\\Http\\Resources\\Json\\JsonResource',
        ),
         'className' => 'App\\Http\\Resources\\OpeningHourResource',
         'functionName' => 'toArray',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Http\\Resources',
           'uses' => 
          array (
            'openinghour' => 'App\\Models\\OpeningHour',
            'request' => 'Illuminate\\Http\\Request',
            'jsonresource' => 'Illuminate\\Http\\Resources\\Json\\JsonResource',
          ),
           'className' => 'App\\Http\\Resources\\OpeningHourResource',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/app/Http/Resources/OpeningHourResource.php' => 'b7f75c5f1101935c1d4c0a4efec19d438dae141b4b7cc8188baa164f99aa1960',
    ),
  ),
));