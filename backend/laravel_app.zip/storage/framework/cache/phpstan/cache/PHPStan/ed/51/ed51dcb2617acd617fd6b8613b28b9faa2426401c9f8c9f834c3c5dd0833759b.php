<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../stripe/stripe-php/lib/Service/ExchangeRateService.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-20db287306aa8f02547e338ecd4613936b572bd0a8346245ce475fb758022650-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'stripe\\service\\exchangerateservice' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));