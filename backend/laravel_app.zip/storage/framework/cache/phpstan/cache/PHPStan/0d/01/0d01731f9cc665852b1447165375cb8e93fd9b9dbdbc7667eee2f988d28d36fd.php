<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../stripe/stripe-php/lib/Service/PromotionCodeService.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-4be9a711e5b70f5c4003349fad2e8fd0af23b4bb14fa0fb00cc67f183cadbc55-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'stripe\\service\\promotioncodeservice' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));