<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../laravel/framework/src/Illuminate/Database/Eloquent/Attributes/Table.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-8c413956cc7d3affc6d131078fb186b9372fd6aaea75f9b848be41b395ac911d-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\database\\eloquent\\attributes\\table' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));