<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/notifications/src/Concerns/HasId.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-e2f57a42839fd9876e88ec4fd3960611983a845072c659e41ddd0a9a8ee23d81-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\notifications\\concerns\\hasid' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));