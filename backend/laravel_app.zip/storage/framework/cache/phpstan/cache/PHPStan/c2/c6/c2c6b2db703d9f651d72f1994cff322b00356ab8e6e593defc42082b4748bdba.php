<?php declare(strict_types = 1);

// ftm-/var/www/html/vendor/larastan/larastan/stubs/common/Mail/Mailables/Content.stub
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'f355982b75b24114162bd54f87d933ee' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Mail\\Mailables',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\Mail\\Mailables\\Content',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6a26c42890079b3fdf24a6a4198ed3bd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Mail\\Mailables',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\Mail\\Mailables\\Content',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/vendor/larastan/larastan/stubs/common/Mail/Mailables/Content.stub' => 'bcc23832118aab175100ca71b4c4e138bc9fe976bb675ba90cc27a12d19a3d07',
    ),
  ),
));