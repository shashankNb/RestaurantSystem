<?php declare(strict_types = 1);

// ftm-/var/www/html/vendor/filament/filament/src/Facades/Filament.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'e4111a884d471848a021868c3f357329' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Facades',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'multifactorauthenticationprovider' => 'Filament\\Auth\\MultiFactor\\Contracts\\MultiFactorAuthenticationProvider',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'plugin' => 'Filament\\Contracts\\Plugin',
          'databasenotificationsposition' => 'Filament\\Enums\\DatabaseNotificationsPosition',
          'globalsearchposition' => 'Filament\\Enums\\GlobalSearchPosition',
          'thememode' => 'Filament\\Enums\\ThemeMode',
          'usermenuposition' => 'Filament\\Enums\\UserMenuPosition',
          'filamentmanager' => 'Filament\\FilamentManager',
          'globalsearchprovider' => 'Filament\\GlobalSearch\\Providers\\Contracts\\GlobalSearchProvider',
          'hastenants' => 'Filament\\Models\\Contracts\\HasTenants',
          'navigationgroup' => 'Filament\\Navigation\\NavigationGroup',
          'navigationitem' => 'Filament\\Navigation\\NavigationItem',
          'subnavigationposition' => 'Filament\\Pages\\Enums\\SubNavigationPosition',
          'pageconfiguration' => 'Filament\\Pages\\PageConfiguration',
          'panel' => 'Filament\\Panel',
          'panelregistry' => 'Filament\\PanelRegistry',
          'resourceconfiguration' => 'Filament\\Resources\\ResourceConfiguration',
          'theme' => 'Filament\\Support\\Assets\\Theme',
          'width' => 'Filament\\Support\\Enums\\Width',
          'widget' => 'Filament\\Widgets\\Widget',
          'authenticatable' => 'Illuminate\\Contracts\\Auth\\Authenticatable',
          'canresetpassword' => 'Illuminate\\Contracts\\Auth\\CanResetPassword',
          'mustverifyemail' => 'Illuminate\\Contracts\\Auth\\MustVerifyEmail',
          'statefulguard' => 'Illuminate\\Contracts\\Auth\\StatefulGuard',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'facade' => 'Illuminate\\Support\\Facades\\Facade',
          'component' => 'Livewire\\Component',
        ),
         'className' => 'Filament\\Facades\\Filament',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '284a3da8dfc7aa69a54a11a5b272f4e0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Facades',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'multifactorauthenticationprovider' => 'Filament\\Auth\\MultiFactor\\Contracts\\MultiFactorAuthenticationProvider',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'plugin' => 'Filament\\Contracts\\Plugin',
          'databasenotificationsposition' => 'Filament\\Enums\\DatabaseNotificationsPosition',
          'globalsearchposition' => 'Filament\\Enums\\GlobalSearchPosition',
          'thememode' => 'Filament\\Enums\\ThemeMode',
          'usermenuposition' => 'Filament\\Enums\\UserMenuPosition',
          'filamentmanager' => 'Filament\\FilamentManager',
          'globalsearchprovider' => 'Filament\\GlobalSearch\\Providers\\Contracts\\GlobalSearchProvider',
          'hastenants' => 'Filament\\Models\\Contracts\\HasTenants',
          'navigationgroup' => 'Filament\\Navigation\\NavigationGroup',
          'navigationitem' => 'Filament\\Navigation\\NavigationItem',
          'subnavigationposition' => 'Filament\\Pages\\Enums\\SubNavigationPosition',
          'pageconfiguration' => 'Filament\\Pages\\PageConfiguration',
          'panel' => 'Filament\\Panel',
          'panelregistry' => 'Filament\\PanelRegistry',
          'resourceconfiguration' => 'Filament\\Resources\\ResourceConfiguration',
          'theme' => 'Filament\\Support\\Assets\\Theme',
          'width' => 'Filament\\Support\\Enums\\Width',
          'widget' => 'Filament\\Widgets\\Widget',
          'authenticatable' => 'Illuminate\\Contracts\\Auth\\Authenticatable',
          'canresetpassword' => 'Illuminate\\Contracts\\Auth\\CanResetPassword',
          'mustverifyemail' => 'Illuminate\\Contracts\\Auth\\MustVerifyEmail',
          'statefulguard' => 'Illuminate\\Contracts\\Auth\\StatefulGuard',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'facade' => 'Illuminate\\Support\\Facades\\Facade',
          'component' => 'Livewire\\Component',
        ),
         'className' => 'Filament\\Facades\\Filament',
         'functionName' => 'getFacadeAccessor',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Facades',
           'uses' => 
          array (
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'multifactorauthenticationprovider' => 'Filament\\Auth\\MultiFactor\\Contracts\\MultiFactorAuthenticationProvider',
            'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
            'plugin' => 'Filament\\Contracts\\Plugin',
            'databasenotificationsposition' => 'Filament\\Enums\\DatabaseNotificationsPosition',
            'globalsearchposition' => 'Filament\\Enums\\GlobalSearchPosition',
            'thememode' => 'Filament\\Enums\\ThemeMode',
            'usermenuposition' => 'Filament\\Enums\\UserMenuPosition',
            'filamentmanager' => 'Filament\\FilamentManager',
            'globalsearchprovider' => 'Filament\\GlobalSearch\\Providers\\Contracts\\GlobalSearchProvider',
            'hastenants' => 'Filament\\Models\\Contracts\\HasTenants',
            'navigationgroup' => 'Filament\\Navigation\\NavigationGroup',
            'navigationitem' => 'Filament\\Navigation\\NavigationItem',
            'subnavigationposition' => 'Filament\\Pages\\Enums\\SubNavigationPosition',
            'pageconfiguration' => 'Filament\\Pages\\PageConfiguration',
            'panel' => 'Filament\\Panel',
            'panelregistry' => 'Filament\\PanelRegistry',
            'resourceconfiguration' => 'Filament\\Resources\\ResourceConfiguration',
            'theme' => 'Filament\\Support\\Assets\\Theme',
            'width' => 'Filament\\Support\\Enums\\Width',
            'widget' => 'Filament\\Widgets\\Widget',
            'authenticatable' => 'Illuminate\\Contracts\\Auth\\Authenticatable',
            'canresetpassword' => 'Illuminate\\Contracts\\Auth\\CanResetPassword',
            'mustverifyemail' => 'Illuminate\\Contracts\\Auth\\MustVerifyEmail',
            'statefulguard' => 'Illuminate\\Contracts\\Auth\\StatefulGuard',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'facade' => 'Illuminate\\Support\\Facades\\Facade',
            'component' => 'Livewire\\Component',
          ),
           'className' => 'Filament\\Facades\\Filament',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '102270a4a1db3ac3741f1ad59e88dc63' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Facades',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'multifactorauthenticationprovider' => 'Filament\\Auth\\MultiFactor\\Contracts\\MultiFactorAuthenticationProvider',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'plugin' => 'Filament\\Contracts\\Plugin',
          'databasenotificationsposition' => 'Filament\\Enums\\DatabaseNotificationsPosition',
          'globalsearchposition' => 'Filament\\Enums\\GlobalSearchPosition',
          'thememode' => 'Filament\\Enums\\ThemeMode',
          'usermenuposition' => 'Filament\\Enums\\UserMenuPosition',
          'filamentmanager' => 'Filament\\FilamentManager',
          'globalsearchprovider' => 'Filament\\GlobalSearch\\Providers\\Contracts\\GlobalSearchProvider',
          'hastenants' => 'Filament\\Models\\Contracts\\HasTenants',
          'navigationgroup' => 'Filament\\Navigation\\NavigationGroup',
          'navigationitem' => 'Filament\\Navigation\\NavigationItem',
          'subnavigationposition' => 'Filament\\Pages\\Enums\\SubNavigationPosition',
          'pageconfiguration' => 'Filament\\Pages\\PageConfiguration',
          'panel' => 'Filament\\Panel',
          'panelregistry' => 'Filament\\PanelRegistry',
          'resourceconfiguration' => 'Filament\\Resources\\ResourceConfiguration',
          'theme' => 'Filament\\Support\\Assets\\Theme',
          'width' => 'Filament\\Support\\Enums\\Width',
          'widget' => 'Filament\\Widgets\\Widget',
          'authenticatable' => 'Illuminate\\Contracts\\Auth\\Authenticatable',
          'canresetpassword' => 'Illuminate\\Contracts\\Auth\\CanResetPassword',
          'mustverifyemail' => 'Illuminate\\Contracts\\Auth\\MustVerifyEmail',
          'statefulguard' => 'Illuminate\\Contracts\\Auth\\StatefulGuard',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'facade' => 'Illuminate\\Support\\Facades\\Facade',
          'component' => 'Livewire\\Component',
        ),
         'className' => 'Filament\\Facades\\Filament',
         'functionName' => 'registerPanel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Filament\\Facades',
           'uses' => 
          array (
            'closure' => 'Closure',
            'action' => 'Filament\\Actions\\Action',
            'multifactorauthenticationprovider' => 'Filament\\Auth\\MultiFactor\\Contracts\\MultiFactorAuthenticationProvider',
            'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
            'plugin' => 'Filament\\Contracts\\Plugin',
            'databasenotificationsposition' => 'Filament\\Enums\\DatabaseNotificationsPosition',
            'globalsearchposition' => 'Filament\\Enums\\GlobalSearchPosition',
            'thememode' => 'Filament\\Enums\\ThemeMode',
            'usermenuposition' => 'Filament\\Enums\\UserMenuPosition',
            'filamentmanager' => 'Filament\\FilamentManager',
            'globalsearchprovider' => 'Filament\\GlobalSearch\\Providers\\Contracts\\GlobalSearchProvider',
            'hastenants' => 'Filament\\Models\\Contracts\\HasTenants',
            'navigationgroup' => 'Filament\\Navigation\\NavigationGroup',
            'navigationitem' => 'Filament\\Navigation\\NavigationItem',
            'subnavigationposition' => 'Filament\\Pages\\Enums\\SubNavigationPosition',
            'pageconfiguration' => 'Filament\\Pages\\PageConfiguration',
            'panel' => 'Filament\\Panel',
            'panelregistry' => 'Filament\\PanelRegistry',
            'resourceconfiguration' => 'Filament\\Resources\\ResourceConfiguration',
            'theme' => 'Filament\\Support\\Assets\\Theme',
            'width' => 'Filament\\Support\\Enums\\Width',
            'widget' => 'Filament\\Widgets\\Widget',
            'authenticatable' => 'Illuminate\\Contracts\\Auth\\Authenticatable',
            'canresetpassword' => 'Illuminate\\Contracts\\Auth\\CanResetPassword',
            'mustverifyemail' => 'Illuminate\\Contracts\\Auth\\MustVerifyEmail',
            'statefulguard' => 'Illuminate\\Contracts\\Auth\\StatefulGuard',
            'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'facade' => 'Illuminate\\Support\\Facades\\Facade',
            'component' => 'Livewire\\Component',
          ),
           'className' => 'Filament\\Facades\\Filament',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/vendor/filament/filament/src/Facades/Filament.php' => '0373e1de43876a2c9129c42ac7e806fdd24a6b7d8f7ada2a359b82902fa7fba8',
    ),
  ),
));