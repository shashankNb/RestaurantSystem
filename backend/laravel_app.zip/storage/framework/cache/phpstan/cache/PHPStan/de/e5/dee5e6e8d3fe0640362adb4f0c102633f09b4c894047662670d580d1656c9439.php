<?php declare(strict_types = 1);

// ftm-/var/www/html/app/Support/TrackingUrl.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '18a010a8604fa56121717bdf09d9c34d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Support',
         'uses' => 
        array (
          'order' => 'App\\Models\\Order',
        ),
         'className' => 'App\\Support\\TrackingUrl',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'efcbbb93ef741d4d921320149f8ed7fe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Support',
         'uses' => 
        array (
          'order' => 'App\\Models\\Order',
        ),
         'className' => 'App\\Support\\TrackingUrl',
         'functionName' => 'for',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Support',
           'uses' => 
          array (
            'order' => 'App\\Models\\Order',
          ),
           'className' => 'App\\Support\\TrackingUrl',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/app/Support/TrackingUrl.php' => 'a56eed11f34a3921e663145fe1697aedb643cdba093c7c9366f2efec24f4b8e8',
    ),
  ),
));