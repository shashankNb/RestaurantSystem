<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../laravel/framework/src/Illuminate/Contracts/Cache/Repository.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-21b8931d64a35b02f995b3833a267aaa91922afa7eb7ebf6ab93519b270fa4b8-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\contracts\\cache\\repository' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));