<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../stripe/stripe-php/lib/Service/Entitlements/EntitlementsServiceFactory.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-e0fcdde2e8b64e7d73d587164629bf3f869797b2b7bcb7096299aece95850629-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'stripe\\service\\entitlements\\entitlementsservicefactory' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));