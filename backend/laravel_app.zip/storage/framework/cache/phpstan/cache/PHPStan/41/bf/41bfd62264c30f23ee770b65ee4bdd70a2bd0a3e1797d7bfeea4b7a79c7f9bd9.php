<?php declare(strict_types = 1);

// ftm-/var/www/html/database/factories/ModifierGroupFactory.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '31341daa3ffdac0a2b0f71a768782730' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Database\\Factories',
         'uses' => 
        array (
          'modifiergroup' => 'App\\Models\\ModifierGroup',
          'restaurant' => 'App\\Models\\Restaurant',
          'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
        ),
         'className' => 'Database\\Factories\\ModifierGroupFactory',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'aac5f33e995603486b659e569d85b5c0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Database\\Factories',
         'uses' => 
        array (
          'modifiergroup' => 'App\\Models\\ModifierGroup',
          'restaurant' => 'App\\Models\\Restaurant',
          'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
        ),
         'className' => 'Database\\Factories\\ModifierGroupFactory',
         'functionName' => 'definition',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Database\\Factories',
           'uses' => 
          array (
            'modifiergroup' => 'App\\Models\\ModifierGroup',
            'restaurant' => 'App\\Models\\Restaurant',
            'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
          ),
           'className' => 'Database\\Factories\\ModifierGroupFactory',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5ec788fac6075d1f3b48d5b43f0f9360' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Database\\Factories',
         'uses' => 
        array (
          'modifiergroup' => 'App\\Models\\ModifierGroup',
          'restaurant' => 'App\\Models\\Restaurant',
          'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
        ),
         'className' => 'Database\\Factories\\ModifierGroupFactory',
         'functionName' => 'selecting',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Database\\Factories',
           'uses' => 
          array (
            'modifiergroup' => 'App\\Models\\ModifierGroup',
            'restaurant' => 'App\\Models\\Restaurant',
            'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
          ),
           'className' => 'Database\\Factories\\ModifierGroupFactory',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/database/factories/ModifierGroupFactory.php' => '38d4bd1ba4ddf9bc084b90e3602944ea4da1e616939d66ec7d3967dfed2e9275',
    ),
  ),
));