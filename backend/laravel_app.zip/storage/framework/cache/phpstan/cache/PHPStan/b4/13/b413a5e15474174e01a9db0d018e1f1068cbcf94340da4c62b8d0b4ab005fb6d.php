<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/filament/src/Resources/Pages/Concerns/HasRelationManagers.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-1bf5bdd8ff4a1d2ad52b0eac26762a5765618dbdd3df6da255ded2f754727186-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\resources\\pages\\concerns\\hasrelationmanagers' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));