<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/tables/src/Columns/Concerns/CanBeValidated.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-0cfba98f038a00de92eadbb9f37c568168207ceace069245124215a10a01d902-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\tables\\columns\\concerns\\canbevalidated' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));