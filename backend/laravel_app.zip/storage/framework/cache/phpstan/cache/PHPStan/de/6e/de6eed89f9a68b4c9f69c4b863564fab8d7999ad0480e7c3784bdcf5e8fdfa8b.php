<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/support/src/Enums/FontWeight.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-494bf2c018bcab6cbdf8c5fbb2741af89e63b5946eb29ac53111494f9ff4338c-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\support\\enums\\fontweight' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));