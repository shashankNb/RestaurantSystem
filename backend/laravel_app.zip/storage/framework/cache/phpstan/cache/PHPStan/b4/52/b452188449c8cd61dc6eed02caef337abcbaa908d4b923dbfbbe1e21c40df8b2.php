<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../laravel/framework/src/Illuminate/Contracts/Cache/LockProvider.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-d3c3d0cb9516e509d9a94ebda3e18a101671fec0361a8508d883ad259db47d23-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\contracts\\cache\\lockprovider' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));