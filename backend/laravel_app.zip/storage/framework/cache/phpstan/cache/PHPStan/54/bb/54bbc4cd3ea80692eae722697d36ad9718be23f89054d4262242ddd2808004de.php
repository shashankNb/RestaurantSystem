<?php declare(strict_types = 1);

// ftm-/var/www/html/vendor/laravel/framework/src/Illuminate/Database/Eloquent/Relations/HasOneOrMany.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '8ad0d996c83fb4feb5e03fc5d5bf8b50' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
          'TRelatedModel' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TRelatedModel',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 2,
                'endLine' => 2,
              ),
            )),
          ),
          'TDeclaringModel' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TDeclaringModel',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 3,
                'endLine' => 3,
              ),
            )),
          ),
          'TResult' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TResult',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e23b458e5cc3bae380bef71a484969b9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns',
         'uses' => 
        array (
          'invalidargumentexception' => 'InvalidArgumentException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/laravel/framework/src/Illuminate/Database/Eloquent/Relations/HasOneOrMany.php',
          1 => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
          2 => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '9cee63f9485c1927cfae6546c31c353d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns',
         'uses' => 
        array (
          'invalidargumentexception' => 'InvalidArgumentException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'getDictionaryKey',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/laravel/framework/src/Illuminate/Database/Eloquent/Relations/HasOneOrMany.php',
          1 => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
          2 => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '79abbc008b349ef735c7bc9302266076' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns',
         'uses' => 
        array (
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'relationnotfoundexception' => 'Illuminate\\Database\\Eloquent\\RelationNotFoundException',
          'arr' => 'Illuminate\\Support\\Arr',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/laravel/framework/src/Illuminate/Database/Eloquent/Relations/HasOneOrMany.php',
          1 => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
          2 => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '0f29869f8994c73fdcf6e6bb196b5e3d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns',
         'uses' => 
        array (
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'relationnotfoundexception' => 'Illuminate\\Database\\Eloquent\\RelationNotFoundException',
          'arr' => 'Illuminate\\Support\\Arr',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'inverse',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/laravel/framework/src/Illuminate/Database/Eloquent/Relations/HasOneOrMany.php',
          1 => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
          2 => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '95cc92bbd957389a3d97aca42d8e95e4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns',
         'uses' => 
        array (
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'relationnotfoundexception' => 'Illuminate\\Database\\Eloquent\\RelationNotFoundException',
          'arr' => 'Illuminate\\Support\\Arr',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'chaperone',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/laravel/framework/src/Illuminate/Database/Eloquent/Relations/HasOneOrMany.php',
          1 => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
          2 => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'b114a8722aaaf3f24497080d5a689075' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns',
         'uses' => 
        array (
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'relationnotfoundexception' => 'Illuminate\\Database\\Eloquent\\RelationNotFoundException',
          'arr' => 'Illuminate\\Support\\Arr',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'guessInverseRelation',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/laravel/framework/src/Illuminate/Database/Eloquent/Relations/HasOneOrMany.php',
          1 => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
          2 => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'dd4f32dbabde72212c41e6b5b7f19e32' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns',
         'uses' => 
        array (
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'relationnotfoundexception' => 'Illuminate\\Database\\Eloquent\\RelationNotFoundException',
          'arr' => 'Illuminate\\Support\\Arr',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'getPossibleInverseRelations',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/laravel/framework/src/Illuminate/Database/Eloquent/Relations/HasOneOrMany.php',
          1 => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
          2 => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'b4887091c642693dc0dacf04b6a0d6df' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns',
         'uses' => 
        array (
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'relationnotfoundexception' => 'Illuminate\\Database\\Eloquent\\RelationNotFoundException',
          'arr' => 'Illuminate\\Support\\Arr',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'applyInverseRelationToCollection',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/laravel/framework/src/Illuminate/Database/Eloquent/Relations/HasOneOrMany.php',
          1 => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
          2 => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '0f9b476d1708cd54ceb1f4feb1114bff' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns',
         'uses' => 
        array (
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'relationnotfoundexception' => 'Illuminate\\Database\\Eloquent\\RelationNotFoundException',
          'arr' => 'Illuminate\\Support\\Arr',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'applyInverseRelationToModel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/laravel/framework/src/Illuminate/Database/Eloquent/Relations/HasOneOrMany.php',
          1 => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
          2 => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'a475adb31ec5308192f73ba5d58c34c5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns',
         'uses' => 
        array (
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'relationnotfoundexception' => 'Illuminate\\Database\\Eloquent\\RelationNotFoundException',
          'arr' => 'Illuminate\\Support\\Arr',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'getInverseRelationship',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/laravel/framework/src/Illuminate/Database/Eloquent/Relations/HasOneOrMany.php',
          1 => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
          2 => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'e3be4e3fa80a80fa9dc791d7d3e12205' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns',
         'uses' => 
        array (
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'relationnotfoundexception' => 'Illuminate\\Database\\Eloquent\\RelationNotFoundException',
          'arr' => 'Illuminate\\Support\\Arr',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'withoutInverse',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/laravel/framework/src/Illuminate/Database/Eloquent/Relations/HasOneOrMany.php',
          1 => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
          2 => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'f22e08bf6e0cb4d384fe76ed1fcc5e0b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns',
         'uses' => 
        array (
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'relationnotfoundexception' => 'Illuminate\\Database\\Eloquent\\RelationNotFoundException',
          'arr' => 'Illuminate\\Support\\Arr',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'withoutChaperone',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/laravel/framework/src/Illuminate/Database/Eloquent/Relations/HasOneOrMany.php',
          1 => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
          2 => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '6a7008aa05da1451b7be43317b90b9b6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bcda11485055a13aa123bc638a588ddc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'make',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3a67c667b6612d8e18cc7184678835b8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'makeMany',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '09d9f8d1cd12577c1cf7df9d69fcac8f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'addConstraints',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6ba373ba4f596e0f62b48a82a2eea5d0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'addEagerConstraints',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7404184fd985e6151bfe75af229e7093' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'matchOne',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '025d94ee631166170b9bb892973da2ad' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'matchMany',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '81f6695a5e0d75044ffcdb87544c0f8c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'matchOneOrMany',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2658ba7091959a59b35e602d3b5ef7dd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'getRelationValue',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6f872d266e59d1e81b44b075088e1629' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'buildDictionary',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e95e52f3b5d4607419fc804a95cc267f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'findOrNew',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3de0cefe82619288540b5fc9b0f23a44' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'firstOrNew',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0362bb6b8e00418253f083e26dff7f63' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'firstOrCreate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '236bd66fcd3c606e4307a7ff3368cb09' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'createOrFirst',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4b4f25b692ae90e023ae7f67deb87f2b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'updateOrCreate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '797c6f7b7f47737d0c4de2766dcf18d5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'upsert',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '88bd2f9c8e3e1667ffce5913c86a04df' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'save',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ff58c3da0be220211bccaf0f0e12bbb7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'saveQuietly',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9ee474cd0a4adb82d75e5ddfb93c7107' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'saveMany',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '33003a8c9039a4175659a9983cc77b36' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'saveManyQuietly',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a247382fd76e3bc81a2493fab69b3785' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'create',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0da45c0e2048ba2da360558f070bb0eb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'createQuietly',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '39f12f8965b3cce603b924f74f6a5a34' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'forceCreate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f0d7840393125950313a5a4e3b1ce463' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'forceCreateQuietly',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '75ca04d13a74a4f5d0f3f136294586e7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'createMany',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f5b98626948a8f046e4a0604e2a15477' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'createManyQuietly',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '65e4aff5cb024a37580e13aa8af8c0fe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'forceCreateMany',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9703a2e1c6186cc4587dc166fc47310f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'forceCreateManyQuietly',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a7768bc38955c53f118b2789d01b8a6b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'setForeignAttributesForCreate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4a8c4a6c21027b5f7881173223e122ab' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'getRelationExistenceQuery',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6f44a19603170fd744628757321b8bd0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'getRelationExistenceQueryForSelfRelation',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b9aa85907b24f2bbbe7db10d74ceb62a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'take',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b127865f59391b6cff7aee7e97392bcd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'limit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '40b0de0eae0cae22c0cf0540e57df3cc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'getExistenceCompareKey',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0f0da0de118e52030bc64dbf9313b4bd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'getParentKey',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '12f450274821c0c39495c61eb7fd4bd7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'getQualifiedParentKeyName',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f3ae96372760d3ba4b58b77690507362' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'getForeignKeyName',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c14cc1cd48fbf4bf49ee3317ff329649' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'getQualifiedForeignKeyName',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4fa5dcd077377143f38b4f65e442ae42' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
         'uses' => 
        array (
          'closure' => 'Closure',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
          'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
         'functionName' => 'getLocalKeyName',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Relations',
           'uses' => 
          array (
            'closure' => 'Closure',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'eloquentcollection' => 'Illuminate\\Database\\Eloquent\\Collection',
            'model' => 'Illuminate\\Database\\Eloquent\\Model',
            'interactswithdictionary' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\InteractsWithDictionary',
            'supportsinverserelations' => 'Illuminate\\Database\\Eloquent\\Relations\\Concerns\\SupportsInverseRelations',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'arr' => 'Illuminate\\Support\\Arr',
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Relations\\HasOneOrMany',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TRelatedModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TRelatedModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TDeclaringModel' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDeclaringModel',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => '\\Illuminate\\Database\\Eloquent\\Model',
                   'attributes' => 
                  array (
                    'startLine' => 3,
                    'endLine' => 3,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 3,
                  'endLine' => 3,
                ),
              )),
            ),
            'TResult' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TResult',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/vendor/laravel/framework/src/Illuminate/Database/Eloquent/Relations/HasOneOrMany.php' => '0fa1c51ab031767fb7fe0b92181dee312c8f1f8b6b2fc13a72733075309c493d',
      '/var/www/html/vendor/composer/../laravel/framework/src/Illuminate/Database/Eloquent/Relations/Concerns/InteractsWithDictionary.php' => '339952973ea62669745b6505c3bf1b887a7e4d39d25fd657d816e654ae7b1426',
      '/var/www/html/vendor/composer/../laravel/framework/src/Illuminate/Database/Eloquent/Relations/Concerns/SupportsInverseRelations.php' => 'a3b1bf009c0a4c6e796099ea41d03b005b7aa876fe90e570640cf63f7dff74fa',
    ),
  ),
));