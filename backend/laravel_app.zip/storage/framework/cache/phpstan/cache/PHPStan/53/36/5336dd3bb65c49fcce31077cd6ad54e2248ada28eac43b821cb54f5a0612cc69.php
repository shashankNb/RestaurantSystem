<?php declare(strict_types = 1);

// ftm-/var/www/html/database/factories/CustomerAddressFactory.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'a723550a0b1bd6cf8aefa33163c88c7f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Database\\Factories',
         'uses' => 
        array (
          'customeraddress' => 'App\\Models\\CustomerAddress',
          'user' => 'App\\Models\\User',
          'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
        ),
         'className' => 'Database\\Factories\\CustomerAddressFactory',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8da77006fbb36a59e64a97b5dd0dc808' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Database\\Factories',
         'uses' => 
        array (
          'customeraddress' => 'App\\Models\\CustomerAddress',
          'user' => 'App\\Models\\User',
          'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
        ),
         'className' => 'Database\\Factories\\CustomerAddressFactory',
         'functionName' => 'definition',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Database\\Factories',
           'uses' => 
          array (
            'customeraddress' => 'App\\Models\\CustomerAddress',
            'user' => 'App\\Models\\User',
            'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
          ),
           'className' => 'Database\\Factories\\CustomerAddressFactory',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/database/factories/CustomerAddressFactory.php' => '2b250f22407badc9019f414c2205db13e1046102f12b9ab329dfb8c34b30adc9',
    ),
  ),
));