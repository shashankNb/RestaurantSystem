<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../stripe/stripe-php/lib/Service/PaymentRecordService.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-5b118dae60eb97a3c1784e84bb16176946e0e8f53c2df75c56a5c6e1ec98b1e4-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'stripe\\service\\paymentrecordservice' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));