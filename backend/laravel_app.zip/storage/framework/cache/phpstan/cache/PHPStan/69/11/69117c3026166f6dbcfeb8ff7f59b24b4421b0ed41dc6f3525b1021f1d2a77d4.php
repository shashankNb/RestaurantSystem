<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../livewire/livewire/src/Features/SupportFileUploads/WithFileUploads.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-ec6eb8b48b32e189e05f8a3ab871d41cae3540feb1426785ae6e879eb7b655d0-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'livewire\\features\\supportfileuploads\\withfileuploads' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));