<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/filament/src/Panel/Concerns/HasRoutes.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-66e1775f56dcc97b469228b6ea35275062017e6834e2cb2ba737d2639cd5c461-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\panel\\concerns\\hasroutes' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));