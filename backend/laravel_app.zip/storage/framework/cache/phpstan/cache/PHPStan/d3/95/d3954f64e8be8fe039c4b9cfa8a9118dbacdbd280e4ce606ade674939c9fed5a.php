<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../laravel/framework/src/Illuminate/Database/Eloquent/Attributes/RouteKey.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-e5117e047e75781e50d378c0e52df96de7c72ba964c1adc9431e7991fdff0dfc-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\database\\eloquent\\attributes\\routekey' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));