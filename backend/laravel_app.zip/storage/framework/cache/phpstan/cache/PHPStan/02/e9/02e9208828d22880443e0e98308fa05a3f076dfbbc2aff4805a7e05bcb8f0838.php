<?php declare(strict_types = 1);

// ftm-/var/www/html/database/migrations/2026_09_29_001300_create_orders_table.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'a5578637a78a9801e7beea079e7ad164' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'migration' => 'Illuminate\\Database\\Migrations\\Migration',
          'blueprint' => 'Illuminate\\Database\\Schema\\Blueprint',
          'schema' => 'Illuminate\\Support\\Facades\\Schema',
        ),
         'className' => NULL,
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5150eeb1e86b4ee870ac7b57ee494adf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'migration' => 'Illuminate\\Database\\Migrations\\Migration',
          'blueprint' => 'Illuminate\\Database\\Schema\\Blueprint',
          'schema' => 'Illuminate\\Support\\Facades\\Schema',
        ),
         'className' => 'AnonymousClass86bc2588cca2240cd20128e620e08b4b',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd572b9bb9f0bc692617357239ed23894' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'migration' => 'Illuminate\\Database\\Migrations\\Migration',
          'blueprint' => 'Illuminate\\Database\\Schema\\Blueprint',
          'schema' => 'Illuminate\\Support\\Facades\\Schema',
        ),
         'className' => 'AnonymousClass86bc2588cca2240cd20128e620e08b4b',
         'functionName' => 'up',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '68f6c19c46134b7dcce9b685955f04d4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'migration' => 'Illuminate\\Database\\Migrations\\Migration',
          'blueprint' => 'Illuminate\\Database\\Schema\\Blueprint',
          'schema' => 'Illuminate\\Support\\Facades\\Schema',
        ),
         'className' => 'AnonymousClass86bc2588cca2240cd20128e620e08b4b',
         'functionName' => 'down',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/database/migrations/2026_09_29_001300_create_orders_table.php' => '9cfa883f3a91ecfb790f763a3f81c1f9127c3d7ab24abdd5707acce3f8c91353',
    ),
  ),
));