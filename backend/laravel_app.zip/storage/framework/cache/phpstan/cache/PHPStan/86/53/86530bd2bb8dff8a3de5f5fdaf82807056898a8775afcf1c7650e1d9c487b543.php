<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/actions/src/Concerns/InteractsWithActions.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6af5cf08865acbfc5098dbc6316452f820404df08040acd0fdd2618fbb3169a9-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\actions\\concerns\\interactswithactions' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));