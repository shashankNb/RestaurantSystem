<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/forms/src/Components/Concerns/HasEnum.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-e4570df1b971d3fb9d179876454ee687bf55e94bf3f83c3d5c00f017db3171b1-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\forms\\components\\concerns\\hasenum' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));