<?php declare(strict_types = 1);

// ftm-/var/www/html/app/Http/Controllers/Api/MeController.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'ac882b6660fc0eae754b52545e788a53' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Http\\Controllers\\Api',
         'uses' => 
        array (
          'controller' => 'App\\Http\\Controllers\\Controller',
          'userresource' => 'App\\Http\\Resources\\UserResource',
          'user' => 'App\\Models\\User',
          'accountservice' => 'App\\Services\\AccountService',
          'request' => 'Illuminate\\Http\\Request',
          'response' => 'Illuminate\\Http\\Response',
          'gate' => 'Illuminate\\Support\\Facades\\Gate',
        ),
         'className' => 'App\\Http\\Controllers\\Api\\MeController',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8b7a4c8edc212af92c029f65b009ef46' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Http\\Controllers\\Api',
         'uses' => 
        array (
          'controller' => 'App\\Http\\Controllers\\Controller',
          'userresource' => 'App\\Http\\Resources\\UserResource',
          'user' => 'App\\Models\\User',
          'accountservice' => 'App\\Services\\AccountService',
          'request' => 'Illuminate\\Http\\Request',
          'response' => 'Illuminate\\Http\\Response',
          'gate' => 'Illuminate\\Support\\Facades\\Gate',
        ),
         'className' => 'App\\Http\\Controllers\\Api\\MeController',
         'functionName' => 'show',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e027b4a5c084131c5cded8c34d56efd7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Http\\Controllers\\Api',
         'uses' => 
        array (
          'controller' => 'App\\Http\\Controllers\\Controller',
          'userresource' => 'App\\Http\\Resources\\UserResource',
          'user' => 'App\\Models\\User',
          'accountservice' => 'App\\Services\\AccountService',
          'request' => 'Illuminate\\Http\\Request',
          'response' => 'Illuminate\\Http\\Response',
          'gate' => 'Illuminate\\Support\\Facades\\Gate',
        ),
         'className' => 'App\\Http\\Controllers\\Api\\MeController',
         'functionName' => 'destroy',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/app/Http/Controllers/Api/MeController.php' => '37f34282966a2412414380130c328eff1aa601bd904f8c449ab24773744a5f16',
    ),
  ),
));