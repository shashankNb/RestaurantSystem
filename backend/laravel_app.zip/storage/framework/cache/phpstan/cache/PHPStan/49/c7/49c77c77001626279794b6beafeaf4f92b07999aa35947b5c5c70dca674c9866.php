<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/filament/src/Pages/Dashboard.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-f5b3828b99b799782fcf20970b59cee599a72b0bd7db4223bd7b4320d7d3a7af-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\pages\\dashboard' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));