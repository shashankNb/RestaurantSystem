<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/infolists/src/Components/Concerns/HasExtraEntryWrapperAttributes.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-dc3c8e8b0cb235c145824517934cf5e1e17a52b02f563367cd0a5d8fb758b2ba-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\infolists\\components\\concerns\\hasextraentrywrapperattributes' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));