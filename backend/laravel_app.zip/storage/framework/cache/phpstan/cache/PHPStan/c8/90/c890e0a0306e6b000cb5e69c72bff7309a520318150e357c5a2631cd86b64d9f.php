<?php declare(strict_types = 1);

// ftm-/var/www/html/vendor/filament/filament/src/Panel/Concerns/HasTenancy.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'c8cccc3b4faf6db1456bbb63c575a743' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '563fea199cef3e68b036610ebb77cae6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'requiresTenantSubscription',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3da98ac40c47f0e5efbe4afe04d022fc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'tenantMenuItems',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '736a4c52cdac459b450aea849874d9e5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'splitTenantMenuRegistrationGroups',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '49f2e77f7af2f56b664ae7378522054c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'hasMultipleTenantMenuItemGroups',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e53bfe74115fe6a8109325f920e309a0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'tenantSwitcher',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fc0a2817b60b5a1f2bdc6f05612c0f79' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'searchableTenantMenu',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0d8b484df2264a55e1c3d881d0e2d4f8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'tenantMenu',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0bfc82697870ad33a5ff03fc609a016a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'tenant',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '33ddb663584b647fff5ad3e0e6cf3770' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'tenantRoutePrefix',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '902e521783d153618f463b38a6c9481e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'tenantDomain',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '362c6a20253803501f03543e3c162cd7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'tenantBillingProvider',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '09828b840d3b696fd80e4121beea838d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'tenantBillingRouteSlug',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fce642b8711b9ca9296513587eb772a9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'tenantProfile',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '954a26bd8056a6b7c4d37a9a7a526afd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'tenantRegistration',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '19d9c85320bde0aba011b7acb44a46fe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'resolveTenantUsing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9555d34ea3691bbc4bfb4247e5e0474f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'hasTenancy',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1138acc3798154258006e5d98950b05a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'isTenantSubscriptionRequired',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '425702527af262b5db87f6c8c40e22b8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'hasTenantBilling',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8940c8774dbcb3c269422fb86fbaacfe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'hasTenantProfile',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2ffff322bdb66f82c389f18fd119f16b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'hasTenantRegistration',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '10129bfab7e5987c59b353ad136c8489' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'hasTenantRoutePrefix',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '323f5aa1f3a5dac8ca0c149f56f14f06' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'getTenantRoutePrefix',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fa9c3b43be81887e6a7cd22d1838ee4c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'hasTenantDomain',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8c0ebf385390773860207793a8d0f2a8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'getTenantDomain',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '458aae59ec49db6760e111e84063b71f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'getTenantBillingProvider',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '177ceb46ca38e5581015b0448f560f84' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'getTenantBillingRouteSlug',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c757394a02a28273207257dc541effaa' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'getTenantProfilePage',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '254c7905824c4f6a97a64bf6a8d7f325' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'getTenantRegistrationPage',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '14036948328d33a8993f40248fe54737' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'getTenant',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fae60319fded660b649091b038b7fb8a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'getTenantModel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0393f3dd3c5525f3ec1e33eb8957c792' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'getTenantSlugAttribute',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9fefc17fe81a906846c4d744fe9603dd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'getTenantBillingUrl',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a6b95f909e3d593dcdb1093f23b7644d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'getTenantProfileUrl',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'da7243a22c344f7ccca350c367744858' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'getTenantRegistrationUrl',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e8ccd84c99a6995a8a313e6e14532509' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'hasTenantMenu',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'eb3f947a785ea9d99cc219326052abe5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'getTenantProfileMenuItem',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ac7342d31ed3a71c715eae4684354114' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'getTenantBillingMenuItem',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f53adc8e6bbb7d7c1bf1530b315b4cd9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'getTenantRegistrationMenuItem',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '16875c82908019acaac7e665020f37b2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'hasTenantSwitcher',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2572ec05b96f7a36fa040256a537051f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'isTenantMenuSearchable',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '43462daef0524005fa815f65896f7268' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'getTenantMenuItemGroups',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ceba25c6b9b9a2733583dab83d816b50' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'getTenantMenuItems',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e4061712a4d2b1055f775798400ee112' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'getTenantOwnershipRelationshipName',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a6326480e1718078e4216de4d2aa92d5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Panel\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'billingprovider' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
          'filament' => 'Filament\\Facades\\Filament',
          'menuitem' => 'Filament\\Navigation\\MenuItem',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'panelsiconalias' => 'Filament\\View\\PanelsIconAlias',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'modelnotfoundexception' => 'Illuminate\\Database\\Eloquent\\ModelNotFoundException',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Filament\\Panel\\Concerns\\HasTenancy',
         'functionName' => 'getTenancyScopeName',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/vendor/filament/filament/src/Panel/Concerns/HasTenancy.php' => '56fff0f79df7e214af4d0306429353851be30b020548fbba4431974fed3dfe7d',
    ),
  ),
));