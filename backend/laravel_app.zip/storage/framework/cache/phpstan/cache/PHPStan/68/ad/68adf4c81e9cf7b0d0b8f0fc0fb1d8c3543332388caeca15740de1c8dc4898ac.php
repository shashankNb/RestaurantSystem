<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../stripe/stripe-php/lib/Util/RequestOptions.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Stripe\Util\RequestOptions
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-920c919af97026707119737188388d1e181eea874b83808e71f8c16554c11ea5-8.5.11-6.73.0.5',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Stripe\\Util\\RequestOptions',
        'filename' => '/var/www/html/vendor/composer/../stripe/stripe-php/lib/Util/RequestOptions.php',
      ),
    ),
    'namespace' => 'Stripe\\Util',
    'name' => 'Stripe\\Util\\RequestOptions',
    'shortName' => 'RequestOptions',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => '/**
 * @phpstan-type RequestOptionsArray array{api_key?: string, idempotency_key?: string, stripe_account?: string, stripe_context?: string|\\Stripe\\StripeContext, stripe_version?: string, api_base?: string, max_network_retries?: int, headers?: Array }
 *
 * @psalm-type RequestOptionsArray = array{api_key?: string, idempotency_key?: string, stripe_account?: string, stripe_context?: string|\\Stripe\\StripeContext, stripe_version?: string, api_base?: string, max_network_retries?: int, headers?: Array }
 */',
    'attributes' => 
    array (
    ),
    'startLine' => 10,
    'endLine' => 215,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => NULL,
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
      'HEADERS_TO_PERSIST' => 
      array (
        'declaringClassName' => 'Stripe\\Util\\RequestOptions',
        'implementingClassName' => 'Stripe\\Util\\RequestOptions',
        'name' => 'HEADERS_TO_PERSIST',
        'modifiers' => 17,
        'type' => NULL,
        'default' => 
        array (
          'code' => '[\'Stripe-Account\', \'Stripe-Context\', \'Stripe-Version\']',
          'attributes' => 
          array (
            'startLine' => 15,
            'endLine' => 19,
            'startTokenPos' => 25,
            'startFilePos' => 702,
            'endTokenPos' => 36,
            'endFilePos' => 786,
          ),
        ),
        'docComment' => '/**
 * @var array<string> a list of headers that should be persisted across requests
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 15,
        'endLine' => 19,
        'startColumn' => 5,
        'endColumn' => 6,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'headers' => 
      array (
        'declaringClassName' => 'Stripe\\Util\\RequestOptions',
        'implementingClassName' => 'Stripe\\Util\\RequestOptions',
        'name' => 'headers',
        'modifiers' => 1,
        'type' => NULL,
        'default' => NULL,
        'docComment' => '/** @var array<string, string> */',
        'attributes' => 
        array (
        ),
        'startLine' => 22,
        'endLine' => 22,
        'startColumn' => 5,
        'endColumn' => 20,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'apiKey' => 
      array (
        'declaringClassName' => 'Stripe\\Util\\RequestOptions',
        'implementingClassName' => 'Stripe\\Util\\RequestOptions',
        'name' => 'apiKey',
        'modifiers' => 1,
        'type' => NULL,
        'default' => NULL,
        'docComment' => '/** @var null|string */',
        'attributes' => 
        array (
        ),
        'startLine' => 25,
        'endLine' => 25,
        'startColumn' => 5,
        'endColumn' => 19,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'apiBase' => 
      array (
        'declaringClassName' => 'Stripe\\Util\\RequestOptions',
        'implementingClassName' => 'Stripe\\Util\\RequestOptions',
        'name' => 'apiBase',
        'modifiers' => 1,
        'type' => NULL,
        'default' => NULL,
        'docComment' => '/** @var null|string */',
        'attributes' => 
        array (
        ),
        'startLine' => 28,
        'endLine' => 28,
        'startColumn' => 5,
        'endColumn' => 20,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'maxNetworkRetries' => 
      array (
        'declaringClassName' => 'Stripe\\Util\\RequestOptions',
        'implementingClassName' => 'Stripe\\Util\\RequestOptions',
        'name' => 'maxNetworkRetries',
        'modifiers' => 1,
        'type' => NULL,
        'default' => NULL,
        'docComment' => '/** @var null|int */',
        'attributes' => 
        array (
        ),
        'startLine' => 31,
        'endLine' => 31,
        'startColumn' => 5,
        'endColumn' => 30,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
    ),
    'immediateMethods' => 
    array (
      '__construct' => 
      array (
        'name' => '__construct',
        'parameters' => 
        array (
          'key' => 
          array (
            'name' => 'key',
            'default' => 
            array (
              'code' => 'null',
              'attributes' => 
              array (
                'startLine' => 39,
                'endLine' => 39,
                'startTokenPos' => 79,
                'startFilePos' => 1211,
                'endTokenPos' => 79,
                'endFilePos' => 1214,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 39,
            'endLine' => 39,
            'startColumn' => 33,
            'endColumn' => 43,
            'parameterIndex' => 0,
            'isOptional' => true,
          ),
          'headers' => 
          array (
            'name' => 'headers',
            'default' => 
            array (
              'code' => '[]',
              'attributes' => 
              array (
                'startLine' => 39,
                'endLine' => 39,
                'startTokenPos' => 86,
                'startFilePos' => 1228,
                'endTokenPos' => 87,
                'endFilePos' => 1229,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 39,
            'endLine' => 39,
            'startColumn' => 46,
            'endColumn' => 58,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
          'base' => 
          array (
            'name' => 'base',
            'default' => 
            array (
              'code' => 'null',
              'attributes' => 
              array (
                'startLine' => 39,
                'endLine' => 39,
                'startTokenPos' => 94,
                'startFilePos' => 1240,
                'endTokenPos' => 94,
                'endFilePos' => 1243,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 39,
            'endLine' => 39,
            'startColumn' => 61,
            'endColumn' => 72,
            'parameterIndex' => 2,
            'isOptional' => true,
          ),
          'maxNetworkRetries' => 
          array (
            'name' => 'maxNetworkRetries',
            'default' => 
            array (
              'code' => 'null',
              'attributes' => 
              array (
                'startLine' => 39,
                'endLine' => 39,
                'startTokenPos' => 101,
                'startFilePos' => 1267,
                'endTokenPos' => 101,
                'endFilePos' => 1270,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 39,
            'endLine' => 39,
            'startColumn' => 75,
            'endColumn' => 99,
            'parameterIndex' => 3,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * @param null|string $key
 * @param array<string, string> $headers
 * @param null|string $base
 * @param null|int $maxNetworkRetries
 */',
        'startLine' => 39,
        'endLine' => 45,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Stripe\\Util',
        'declaringClassName' => 'Stripe\\Util\\RequestOptions',
        'implementingClassName' => 'Stripe\\Util\\RequestOptions',
        'currentClassName' => 'Stripe\\Util\\RequestOptions',
        'aliasName' => NULL,
      ),
      '__debugInfo' => 
      array (
        'name' => '__debugInfo',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * @return array<string, string>
 */',
        'startLine' => 50,
        'endLine' => 58,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Stripe\\Util',
        'declaringClassName' => 'Stripe\\Util\\RequestOptions',
        'implementingClassName' => 'Stripe\\Util\\RequestOptions',
        'currentClassName' => 'Stripe\\Util\\RequestOptions',
        'aliasName' => NULL,
      ),
      'merge' => 
      array (
        'name' => 'merge',
        'parameters' => 
        array (
          'options' => 
          array (
            'name' => 'options',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 69,
            'endLine' => 69,
            'startColumn' => 27,
            'endColumn' => 34,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'strict' => 
          array (
            'name' => 'strict',
            'default' => 
            array (
              'code' => 'false',
              'attributes' => 
              array (
                'startLine' => 69,
                'endLine' => 69,
                'startTokenPos' => 218,
                'startFilePos' => 2125,
                'endTokenPos' => 218,
                'endFilePos' => 2129,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 69,
            'endLine' => 69,
            'startColumn' => 37,
            'endColumn' => 51,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Unpacks an options array and merges it into the existing RequestOptions
 * object.
 *
 * @param null|array|RequestOptions|string $options a key => value array
 * @param bool $strict when true, forbid string form and arbitrary keys in array form
 *
 * @return RequestOptions
 */',
        'startLine' => 69,
        'endLine' => 90,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Stripe\\Util',
        'declaringClassName' => 'Stripe\\Util\\RequestOptions',
        'implementingClassName' => 'Stripe\\Util\\RequestOptions',
        'currentClassName' => 'Stripe\\Util\\RequestOptions',
        'aliasName' => NULL,
      ),
      'discardNonPersistentHeaders' => 
      array (
        'name' => 'discardNonPersistentHeaders',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Discards all headers that we don\'t want to persist across requests.
 */',
        'startLine' => 95,
        'endLine' => 102,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Stripe\\Util',
        'declaringClassName' => 'Stripe\\Util\\RequestOptions',
        'implementingClassName' => 'Stripe\\Util\\RequestOptions',
        'currentClassName' => 'Stripe\\Util\\RequestOptions',
        'aliasName' => NULL,
      ),
      'parse' => 
      array (
        'name' => 'parse',
        'parameters' => 
        array (
          'options' => 
          array (
            'name' => 'options',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 114,
            'endLine' => 114,
            'startColumn' => 34,
            'endColumn' => 41,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'strict' => 
          array (
            'name' => 'strict',
            'default' => 
            array (
              'code' => 'false',
              'attributes' => 
              array (
                'startLine' => 114,
                'endLine' => 114,
                'startTokenPos' => 475,
                'startFilePos' => 3740,
                'endTokenPos' => 475,
                'endFilePos' => 3744,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 114,
            'endLine' => 114,
            'startColumn' => 44,
            'endColumn' => 58,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Unpacks an options array into an RequestOptions object.
 *
 * @param null|array|RequestOptions|string $options a key => value array
 * @param bool $strict when true, forbid string form and arbitrary keys in array form
 *
 * @return RequestOptions
 *
 * @throws \\Stripe\\Exception\\InvalidArgumentException
 */',
        'startLine' => 114,
        'endLine' => 197,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 17,
        'namespace' => 'Stripe\\Util',
        'declaringClassName' => 'Stripe\\Util\\RequestOptions',
        'implementingClassName' => 'Stripe\\Util\\RequestOptions',
        'currentClassName' => 'Stripe\\Util\\RequestOptions',
        'aliasName' => NULL,
      ),
      'redactedApiKey' => 
      array (
        'name' => 'redactedApiKey',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/** @return string */',
        'startLine' => 200,
        'endLine' => 214,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 4,
        'namespace' => 'Stripe\\Util',
        'declaringClassName' => 'Stripe\\Util\\RequestOptions',
        'implementingClassName' => 'Stripe\\Util\\RequestOptions',
        'currentClassName' => 'Stripe\\Util\\RequestOptions',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));