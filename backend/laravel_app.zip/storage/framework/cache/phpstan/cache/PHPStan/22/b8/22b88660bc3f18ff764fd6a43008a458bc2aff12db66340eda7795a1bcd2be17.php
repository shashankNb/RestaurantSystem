<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../laravel/framework/src/Illuminate/Contracts/Support/ValidatedData.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-df98cf7afa78bc0217aee7cbd13433c77e3119f34209f2345e0766a68006c17f-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\contracts\\support\\validateddata' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));