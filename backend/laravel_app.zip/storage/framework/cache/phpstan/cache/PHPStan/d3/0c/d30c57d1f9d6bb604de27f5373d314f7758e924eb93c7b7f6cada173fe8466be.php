<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../stripe/stripe-php/lib/Customer.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-c63f57176da1284069bd276003451045ff267767c8081e7928bb59830195723d-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'stripe\\customer' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));