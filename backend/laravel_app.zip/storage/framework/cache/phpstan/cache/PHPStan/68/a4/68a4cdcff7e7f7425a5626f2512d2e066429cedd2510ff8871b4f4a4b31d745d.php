<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/tables/src/Table/Concerns/HasRecords.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-b38dc431bec7a026347546bb91668d79c5c883a4b4356e52494ecfc77167ad74-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\tables\\table\\concerns\\hasrecords' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));