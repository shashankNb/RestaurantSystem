<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/tables/src/Table/Concerns/HasFilters.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-eefe650291886f45637e034b8a39ca7d9c616a732aea4c651ea2a882963b795f-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\tables\\table\\concerns\\hasfilters' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));