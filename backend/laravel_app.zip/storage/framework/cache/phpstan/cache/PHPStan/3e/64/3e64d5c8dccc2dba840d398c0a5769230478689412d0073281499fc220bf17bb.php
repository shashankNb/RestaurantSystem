<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/tables/src/Table/Concerns/HasHeader.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-499b5ee9e63047c8992030145250817cd78cae92f1bd1d6e1ac22ec96581a6ca-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\tables\\table\\concerns\\hasheader' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));