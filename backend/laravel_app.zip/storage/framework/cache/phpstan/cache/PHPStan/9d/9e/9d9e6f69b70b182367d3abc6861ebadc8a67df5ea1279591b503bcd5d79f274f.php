<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../laravel/framework/src/Illuminate/Database/Connection.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-7ac2392c7236486fd92040bdb55760cd195f7cbc2b8f753fffcda70a5edaf39c-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\database\\connection' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));