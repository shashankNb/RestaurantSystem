<?php declare(strict_types = 1);

// ftm-/var/www/html/vendor/larastan/larastan/stubs/common/Database/Eloquent/Concerns/HasRelationships.stub
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'bc1cf2cc1d758b67f11986a104ac6a59' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Concerns',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Concerns\\HasRelationships',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f09596438d1024558c3edbbac9349097' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Concerns',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Concerns\\HasRelationships',
         'functionName' => 'getTouchedRelations',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Eloquent\\Concerns',
           'uses' => 
          array (
          ),
           'className' => 'Illuminate\\Database\\Eloquent\\Concerns\\HasRelationships',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/vendor/larastan/larastan/stubs/common/Database/Eloquent/Concerns/HasRelationships.stub' => '3beb10526e731f163a4adde15db32ef73d0187e3bdb3413e113e32ec31e93418',
    ),
  ),
));