<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../laravel/framework/src/Illuminate/Broadcasting/BroadcastException.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Illuminate\Broadcasting\BroadcastException
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-933f7ae1c01f6045e0b2e0ce8c20823d9f1cbcf0898525049ee2d4f58dff4169-8.5.11-6.73.0.5',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Illuminate\\Broadcasting\\BroadcastException',
        'filename' => '/var/www/html/vendor/composer/../laravel/framework/src/Illuminate/Broadcasting/BroadcastException.php',
      ),
    ),
    'namespace' => 'Illuminate\\Broadcasting',
    'name' => 'Illuminate\\Broadcasting\\BroadcastException',
    'shortName' => 'BroadcastException',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 7,
    'endLine' => 10,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'RuntimeException',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));