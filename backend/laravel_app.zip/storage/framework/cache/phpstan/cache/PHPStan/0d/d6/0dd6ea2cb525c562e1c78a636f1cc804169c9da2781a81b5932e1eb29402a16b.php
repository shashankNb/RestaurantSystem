<?php declare(strict_types = 1);

// ftm-/var/www/html/app/Services/PricingService.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'd4b698af896ed4a8f4655517d36fa286' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Services',
         'uses' => 
        array (
          'cart' => 'App\\Data\\Cart',
          'cartitem' => 'App\\Data\\CartItem',
          'quote' => 'App\\Data\\Quote',
          'quoteerror' => 'App\\Data\\QuoteError',
          'quoteline' => 'App\\Data\\QuoteLine',
          'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
          'promocodetype' => 'App\\Enums\\PromoCodeType',
          'deliveryzone' => 'App\\Models\\DeliveryZone',
          'diningtable' => 'App\\Models\\DiningTable',
          'menuitem' => 'App\\Models\\MenuItem',
          'modifiergroup' => 'App\\Models\\ModifierGroup',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'promocode' => 'App\\Models\\PromoCode',
          'restaurant' => 'App\\Models\\Restaurant',
          'localtime' => 'App\\Support\\LocalTime',
          'money' => 'App\\Support\\Money',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'App\\Services\\PricingService',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e15028f8204ef412d48d8828df937745' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Services',
         'uses' => 
        array (
          'cart' => 'App\\Data\\Cart',
          'cartitem' => 'App\\Data\\CartItem',
          'quote' => 'App\\Data\\Quote',
          'quoteerror' => 'App\\Data\\QuoteError',
          'quoteline' => 'App\\Data\\QuoteLine',
          'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
          'promocodetype' => 'App\\Enums\\PromoCodeType',
          'deliveryzone' => 'App\\Models\\DeliveryZone',
          'diningtable' => 'App\\Models\\DiningTable',
          'menuitem' => 'App\\Models\\MenuItem',
          'modifiergroup' => 'App\\Models\\ModifierGroup',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'promocode' => 'App\\Models\\PromoCode',
          'restaurant' => 'App\\Models\\Restaurant',
          'localtime' => 'App\\Support\\LocalTime',
          'money' => 'App\\Support\\Money',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'App\\Services\\PricingService',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Services',
           'uses' => 
          array (
            'cart' => 'App\\Data\\Cart',
            'cartitem' => 'App\\Data\\CartItem',
            'quote' => 'App\\Data\\Quote',
            'quoteerror' => 'App\\Data\\QuoteError',
            'quoteline' => 'App\\Data\\QuoteLine',
            'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
            'promocodetype' => 'App\\Enums\\PromoCodeType',
            'deliveryzone' => 'App\\Models\\DeliveryZone',
            'diningtable' => 'App\\Models\\DiningTable',
            'menuitem' => 'App\\Models\\MenuItem',
            'modifiergroup' => 'App\\Models\\ModifierGroup',
            'modifieroption' => 'App\\Models\\ModifierOption',
            'promocode' => 'App\\Models\\PromoCode',
            'restaurant' => 'App\\Models\\Restaurant',
            'localtime' => 'App\\Support\\LocalTime',
            'money' => 'App\\Support\\Money',
            'carbonimmutable' => 'Carbon\\CarbonImmutable',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'collection' => 'Illuminate\\Support\\Collection',
          ),
           'className' => 'App\\Services\\PricingService',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6b410d7395c86c9d474eba9e7a585dfe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Services',
         'uses' => 
        array (
          'cart' => 'App\\Data\\Cart',
          'cartitem' => 'App\\Data\\CartItem',
          'quote' => 'App\\Data\\Quote',
          'quoteerror' => 'App\\Data\\QuoteError',
          'quoteline' => 'App\\Data\\QuoteLine',
          'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
          'promocodetype' => 'App\\Enums\\PromoCodeType',
          'deliveryzone' => 'App\\Models\\DeliveryZone',
          'diningtable' => 'App\\Models\\DiningTable',
          'menuitem' => 'App\\Models\\MenuItem',
          'modifiergroup' => 'App\\Models\\ModifierGroup',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'promocode' => 'App\\Models\\PromoCode',
          'restaurant' => 'App\\Models\\Restaurant',
          'localtime' => 'App\\Support\\LocalTime',
          'money' => 'App\\Support\\Money',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'App\\Services\\PricingService',
         'functionName' => 'quote',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Services',
           'uses' => 
          array (
            'cart' => 'App\\Data\\Cart',
            'cartitem' => 'App\\Data\\CartItem',
            'quote' => 'App\\Data\\Quote',
            'quoteerror' => 'App\\Data\\QuoteError',
            'quoteline' => 'App\\Data\\QuoteLine',
            'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
            'promocodetype' => 'App\\Enums\\PromoCodeType',
            'deliveryzone' => 'App\\Models\\DeliveryZone',
            'diningtable' => 'App\\Models\\DiningTable',
            'menuitem' => 'App\\Models\\MenuItem',
            'modifiergroup' => 'App\\Models\\ModifierGroup',
            'modifieroption' => 'App\\Models\\ModifierOption',
            'promocode' => 'App\\Models\\PromoCode',
            'restaurant' => 'App\\Models\\Restaurant',
            'localtime' => 'App\\Support\\LocalTime',
            'money' => 'App\\Support\\Money',
            'carbonimmutable' => 'Carbon\\CarbonImmutable',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'collection' => 'Illuminate\\Support\\Collection',
          ),
           'className' => 'App\\Services\\PricingService',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e031cdfa1771368afbaec1d27db49e64' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Services',
         'uses' => 
        array (
          'cart' => 'App\\Data\\Cart',
          'cartitem' => 'App\\Data\\CartItem',
          'quote' => 'App\\Data\\Quote',
          'quoteerror' => 'App\\Data\\QuoteError',
          'quoteline' => 'App\\Data\\QuoteLine',
          'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
          'promocodetype' => 'App\\Enums\\PromoCodeType',
          'deliveryzone' => 'App\\Models\\DeliveryZone',
          'diningtable' => 'App\\Models\\DiningTable',
          'menuitem' => 'App\\Models\\MenuItem',
          'modifiergroup' => 'App\\Models\\ModifierGroup',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'promocode' => 'App\\Models\\PromoCode',
          'restaurant' => 'App\\Models\\Restaurant',
          'localtime' => 'App\\Support\\LocalTime',
          'money' => 'App\\Support\\Money',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'App\\Services\\PricingService',
         'functionName' => 'gst',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Services',
           'uses' => 
          array (
            'cart' => 'App\\Data\\Cart',
            'cartitem' => 'App\\Data\\CartItem',
            'quote' => 'App\\Data\\Quote',
            'quoteerror' => 'App\\Data\\QuoteError',
            'quoteline' => 'App\\Data\\QuoteLine',
            'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
            'promocodetype' => 'App\\Enums\\PromoCodeType',
            'deliveryzone' => 'App\\Models\\DeliveryZone',
            'diningtable' => 'App\\Models\\DiningTable',
            'menuitem' => 'App\\Models\\MenuItem',
            'modifiergroup' => 'App\\Models\\ModifierGroup',
            'modifieroption' => 'App\\Models\\ModifierOption',
            'promocode' => 'App\\Models\\PromoCode',
            'restaurant' => 'App\\Models\\Restaurant',
            'localtime' => 'App\\Support\\LocalTime',
            'money' => 'App\\Support\\Money',
            'carbonimmutable' => 'Carbon\\CarbonImmutable',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'collection' => 'Illuminate\\Support\\Collection',
          ),
           'className' => 'App\\Services\\PricingService',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5aa83418885132996ce3a3c0a76c10f1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Services',
         'uses' => 
        array (
          'cart' => 'App\\Data\\Cart',
          'cartitem' => 'App\\Data\\CartItem',
          'quote' => 'App\\Data\\Quote',
          'quoteerror' => 'App\\Data\\QuoteError',
          'quoteline' => 'App\\Data\\QuoteLine',
          'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
          'promocodetype' => 'App\\Enums\\PromoCodeType',
          'deliveryzone' => 'App\\Models\\DeliveryZone',
          'diningtable' => 'App\\Models\\DiningTable',
          'menuitem' => 'App\\Models\\MenuItem',
          'modifiergroup' => 'App\\Models\\ModifierGroup',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'promocode' => 'App\\Models\\PromoCode',
          'restaurant' => 'App\\Models\\Restaurant',
          'localtime' => 'App\\Support\\LocalTime',
          'money' => 'App\\Support\\Money',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'App\\Services\\PricingService',
         'functionName' => 'orderableItems',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Services',
           'uses' => 
          array (
            'cart' => 'App\\Data\\Cart',
            'cartitem' => 'App\\Data\\CartItem',
            'quote' => 'App\\Data\\Quote',
            'quoteerror' => 'App\\Data\\QuoteError',
            'quoteline' => 'App\\Data\\QuoteLine',
            'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
            'promocodetype' => 'App\\Enums\\PromoCodeType',
            'deliveryzone' => 'App\\Models\\DeliveryZone',
            'diningtable' => 'App\\Models\\DiningTable',
            'menuitem' => 'App\\Models\\MenuItem',
            'modifiergroup' => 'App\\Models\\ModifierGroup',
            'modifieroption' => 'App\\Models\\ModifierOption',
            'promocode' => 'App\\Models\\PromoCode',
            'restaurant' => 'App\\Models\\Restaurant',
            'localtime' => 'App\\Support\\LocalTime',
            'money' => 'App\\Support\\Money',
            'carbonimmutable' => 'Carbon\\CarbonImmutable',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'collection' => 'Illuminate\\Support\\Collection',
          ),
           'className' => 'App\\Services\\PricingService',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '824b0e6dbb6048b2432c5175a6b7a735' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Services',
         'uses' => 
        array (
          'cart' => 'App\\Data\\Cart',
          'cartitem' => 'App\\Data\\CartItem',
          'quote' => 'App\\Data\\Quote',
          'quoteerror' => 'App\\Data\\QuoteError',
          'quoteline' => 'App\\Data\\QuoteLine',
          'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
          'promocodetype' => 'App\\Enums\\PromoCodeType',
          'deliveryzone' => 'App\\Models\\DeliveryZone',
          'diningtable' => 'App\\Models\\DiningTable',
          'menuitem' => 'App\\Models\\MenuItem',
          'modifiergroup' => 'App\\Models\\ModifierGroup',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'promocode' => 'App\\Models\\PromoCode',
          'restaurant' => 'App\\Models\\Restaurant',
          'localtime' => 'App\\Support\\LocalTime',
          'money' => 'App\\Support\\Money',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'App\\Services\\PricingService',
         'functionName' => 'priceLine',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Services',
           'uses' => 
          array (
            'cart' => 'App\\Data\\Cart',
            'cartitem' => 'App\\Data\\CartItem',
            'quote' => 'App\\Data\\Quote',
            'quoteerror' => 'App\\Data\\QuoteError',
            'quoteline' => 'App\\Data\\QuoteLine',
            'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
            'promocodetype' => 'App\\Enums\\PromoCodeType',
            'deliveryzone' => 'App\\Models\\DeliveryZone',
            'diningtable' => 'App\\Models\\DiningTable',
            'menuitem' => 'App\\Models\\MenuItem',
            'modifiergroup' => 'App\\Models\\ModifierGroup',
            'modifieroption' => 'App\\Models\\ModifierOption',
            'promocode' => 'App\\Models\\PromoCode',
            'restaurant' => 'App\\Models\\Restaurant',
            'localtime' => 'App\\Support\\LocalTime',
            'money' => 'App\\Support\\Money',
            'carbonimmutable' => 'Carbon\\CarbonImmutable',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'collection' => 'Illuminate\\Support\\Collection',
          ),
           'className' => 'App\\Services\\PricingService',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8189f001c20cefd4e2610513180ac2b6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Services',
         'uses' => 
        array (
          'cart' => 'App\\Data\\Cart',
          'cartitem' => 'App\\Data\\CartItem',
          'quote' => 'App\\Data\\Quote',
          'quoteerror' => 'App\\Data\\QuoteError',
          'quoteline' => 'App\\Data\\QuoteLine',
          'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
          'promocodetype' => 'App\\Enums\\PromoCodeType',
          'deliveryzone' => 'App\\Models\\DeliveryZone',
          'diningtable' => 'App\\Models\\DiningTable',
          'menuitem' => 'App\\Models\\MenuItem',
          'modifiergroup' => 'App\\Models\\ModifierGroup',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'promocode' => 'App\\Models\\PromoCode',
          'restaurant' => 'App\\Models\\Restaurant',
          'localtime' => 'App\\Support\\LocalTime',
          'money' => 'App\\Support\\Money',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'App\\Services\\PricingService',
         'functionName' => 'selectionProblem',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Services',
           'uses' => 
          array (
            'cart' => 'App\\Data\\Cart',
            'cartitem' => 'App\\Data\\CartItem',
            'quote' => 'App\\Data\\Quote',
            'quoteerror' => 'App\\Data\\QuoteError',
            'quoteline' => 'App\\Data\\QuoteLine',
            'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
            'promocodetype' => 'App\\Enums\\PromoCodeType',
            'deliveryzone' => 'App\\Models\\DeliveryZone',
            'diningtable' => 'App\\Models\\DiningTable',
            'menuitem' => 'App\\Models\\MenuItem',
            'modifiergroup' => 'App\\Models\\ModifierGroup',
            'modifieroption' => 'App\\Models\\ModifierOption',
            'promocode' => 'App\\Models\\PromoCode',
            'restaurant' => 'App\\Models\\Restaurant',
            'localtime' => 'App\\Support\\LocalTime',
            'money' => 'App\\Support\\Money',
            'carbonimmutable' => 'Carbon\\CarbonImmutable',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'collection' => 'Illuminate\\Support\\Collection',
          ),
           'className' => 'App\\Services\\PricingService',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '06637f95b0e093fd7a92dabc847fbce3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Services',
         'uses' => 
        array (
          'cart' => 'App\\Data\\Cart',
          'cartitem' => 'App\\Data\\CartItem',
          'quote' => 'App\\Data\\Quote',
          'quoteerror' => 'App\\Data\\QuoteError',
          'quoteline' => 'App\\Data\\QuoteLine',
          'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
          'promocodetype' => 'App\\Enums\\PromoCodeType',
          'deliveryzone' => 'App\\Models\\DeliveryZone',
          'diningtable' => 'App\\Models\\DiningTable',
          'menuitem' => 'App\\Models\\MenuItem',
          'modifiergroup' => 'App\\Models\\ModifierGroup',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'promocode' => 'App\\Models\\PromoCode',
          'restaurant' => 'App\\Models\\Restaurant',
          'localtime' => 'App\\Support\\LocalTime',
          'money' => 'App\\Support\\Money',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'App\\Services\\PricingService',
         'functionName' => 'fulfilment',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Services',
           'uses' => 
          array (
            'cart' => 'App\\Data\\Cart',
            'cartitem' => 'App\\Data\\CartItem',
            'quote' => 'App\\Data\\Quote',
            'quoteerror' => 'App\\Data\\QuoteError',
            'quoteline' => 'App\\Data\\QuoteLine',
            'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
            'promocodetype' => 'App\\Enums\\PromoCodeType',
            'deliveryzone' => 'App\\Models\\DeliveryZone',
            'diningtable' => 'App\\Models\\DiningTable',
            'menuitem' => 'App\\Models\\MenuItem',
            'modifiergroup' => 'App\\Models\\ModifierGroup',
            'modifieroption' => 'App\\Models\\ModifierOption',
            'promocode' => 'App\\Models\\PromoCode',
            'restaurant' => 'App\\Models\\Restaurant',
            'localtime' => 'App\\Support\\LocalTime',
            'money' => 'App\\Support\\Money',
            'carbonimmutable' => 'Carbon\\CarbonImmutable',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'collection' => 'Illuminate\\Support\\Collection',
          ),
           'className' => 'App\\Services\\PricingService',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6c34a20bc55d47ff2914d973d1440dcb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Services',
         'uses' => 
        array (
          'cart' => 'App\\Data\\Cart',
          'cartitem' => 'App\\Data\\CartItem',
          'quote' => 'App\\Data\\Quote',
          'quoteerror' => 'App\\Data\\QuoteError',
          'quoteline' => 'App\\Data\\QuoteLine',
          'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
          'promocodetype' => 'App\\Enums\\PromoCodeType',
          'deliveryzone' => 'App\\Models\\DeliveryZone',
          'diningtable' => 'App\\Models\\DiningTable',
          'menuitem' => 'App\\Models\\MenuItem',
          'modifiergroup' => 'App\\Models\\ModifierGroup',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'promocode' => 'App\\Models\\PromoCode',
          'restaurant' => 'App\\Models\\Restaurant',
          'localtime' => 'App\\Support\\LocalTime',
          'money' => 'App\\Support\\Money',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'App\\Services\\PricingService',
         'functionName' => 'dineIn',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Services',
           'uses' => 
          array (
            'cart' => 'App\\Data\\Cart',
            'cartitem' => 'App\\Data\\CartItem',
            'quote' => 'App\\Data\\Quote',
            'quoteerror' => 'App\\Data\\QuoteError',
            'quoteline' => 'App\\Data\\QuoteLine',
            'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
            'promocodetype' => 'App\\Enums\\PromoCodeType',
            'deliveryzone' => 'App\\Models\\DeliveryZone',
            'diningtable' => 'App\\Models\\DiningTable',
            'menuitem' => 'App\\Models\\MenuItem',
            'modifiergroup' => 'App\\Models\\ModifierGroup',
            'modifieroption' => 'App\\Models\\ModifierOption',
            'promocode' => 'App\\Models\\PromoCode',
            'restaurant' => 'App\\Models\\Restaurant',
            'localtime' => 'App\\Support\\LocalTime',
            'money' => 'App\\Support\\Money',
            'carbonimmutable' => 'Carbon\\CarbonImmutable',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'collection' => 'Illuminate\\Support\\Collection',
          ),
           'className' => 'App\\Services\\PricingService',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'aa11aeda7ca2d3718ae3ddedfa30de41' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Services',
         'uses' => 
        array (
          'cart' => 'App\\Data\\Cart',
          'cartitem' => 'App\\Data\\CartItem',
          'quote' => 'App\\Data\\Quote',
          'quoteerror' => 'App\\Data\\QuoteError',
          'quoteline' => 'App\\Data\\QuoteLine',
          'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
          'promocodetype' => 'App\\Enums\\PromoCodeType',
          'deliveryzone' => 'App\\Models\\DeliveryZone',
          'diningtable' => 'App\\Models\\DiningTable',
          'menuitem' => 'App\\Models\\MenuItem',
          'modifiergroup' => 'App\\Models\\ModifierGroup',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'promocode' => 'App\\Models\\PromoCode',
          'restaurant' => 'App\\Models\\Restaurant',
          'localtime' => 'App\\Support\\LocalTime',
          'money' => 'App\\Support\\Money',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'App\\Services\\PricingService',
         'functionName' => 'timing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Services',
           'uses' => 
          array (
            'cart' => 'App\\Data\\Cart',
            'cartitem' => 'App\\Data\\CartItem',
            'quote' => 'App\\Data\\Quote',
            'quoteerror' => 'App\\Data\\QuoteError',
            'quoteline' => 'App\\Data\\QuoteLine',
            'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
            'promocodetype' => 'App\\Enums\\PromoCodeType',
            'deliveryzone' => 'App\\Models\\DeliveryZone',
            'diningtable' => 'App\\Models\\DiningTable',
            'menuitem' => 'App\\Models\\MenuItem',
            'modifiergroup' => 'App\\Models\\ModifierGroup',
            'modifieroption' => 'App\\Models\\ModifierOption',
            'promocode' => 'App\\Models\\PromoCode',
            'restaurant' => 'App\\Models\\Restaurant',
            'localtime' => 'App\\Support\\LocalTime',
            'money' => 'App\\Support\\Money',
            'carbonimmutable' => 'Carbon\\CarbonImmutable',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'collection' => 'Illuminate\\Support\\Collection',
          ),
           'className' => 'App\\Services\\PricingService',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '69602ad99eb34919ceff4c3b2d1fb68c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Services',
         'uses' => 
        array (
          'cart' => 'App\\Data\\Cart',
          'cartitem' => 'App\\Data\\CartItem',
          'quote' => 'App\\Data\\Quote',
          'quoteerror' => 'App\\Data\\QuoteError',
          'quoteline' => 'App\\Data\\QuoteLine',
          'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
          'promocodetype' => 'App\\Enums\\PromoCodeType',
          'deliveryzone' => 'App\\Models\\DeliveryZone',
          'diningtable' => 'App\\Models\\DiningTable',
          'menuitem' => 'App\\Models\\MenuItem',
          'modifiergroup' => 'App\\Models\\ModifierGroup',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'promocode' => 'App\\Models\\PromoCode',
          'restaurant' => 'App\\Models\\Restaurant',
          'localtime' => 'App\\Support\\LocalTime',
          'money' => 'App\\Support\\Money',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'App\\Services\\PricingService',
         'functionName' => 'findPromo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Services',
           'uses' => 
          array (
            'cart' => 'App\\Data\\Cart',
            'cartitem' => 'App\\Data\\CartItem',
            'quote' => 'App\\Data\\Quote',
            'quoteerror' => 'App\\Data\\QuoteError',
            'quoteline' => 'App\\Data\\QuoteLine',
            'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
            'promocodetype' => 'App\\Enums\\PromoCodeType',
            'deliveryzone' => 'App\\Models\\DeliveryZone',
            'diningtable' => 'App\\Models\\DiningTable',
            'menuitem' => 'App\\Models\\MenuItem',
            'modifiergroup' => 'App\\Models\\ModifierGroup',
            'modifieroption' => 'App\\Models\\ModifierOption',
            'promocode' => 'App\\Models\\PromoCode',
            'restaurant' => 'App\\Models\\Restaurant',
            'localtime' => 'App\\Support\\LocalTime',
            'money' => 'App\\Support\\Money',
            'carbonimmutable' => 'Carbon\\CarbonImmutable',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'collection' => 'Illuminate\\Support\\Collection',
          ),
           'className' => 'App\\Services\\PricingService',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0c64602c5d7a18954d463fc2026a4a95' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Services',
         'uses' => 
        array (
          'cart' => 'App\\Data\\Cart',
          'cartitem' => 'App\\Data\\CartItem',
          'quote' => 'App\\Data\\Quote',
          'quoteerror' => 'App\\Data\\QuoteError',
          'quoteline' => 'App\\Data\\QuoteLine',
          'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
          'promocodetype' => 'App\\Enums\\PromoCodeType',
          'deliveryzone' => 'App\\Models\\DeliveryZone',
          'diningtable' => 'App\\Models\\DiningTable',
          'menuitem' => 'App\\Models\\MenuItem',
          'modifiergroup' => 'App\\Models\\ModifierGroup',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'promocode' => 'App\\Models\\PromoCode',
          'restaurant' => 'App\\Models\\Restaurant',
          'localtime' => 'App\\Support\\LocalTime',
          'money' => 'App\\Support\\Money',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'App\\Services\\PricingService',
         'functionName' => 'promoProblem',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Services',
           'uses' => 
          array (
            'cart' => 'App\\Data\\Cart',
            'cartitem' => 'App\\Data\\CartItem',
            'quote' => 'App\\Data\\Quote',
            'quoteerror' => 'App\\Data\\QuoteError',
            'quoteline' => 'App\\Data\\QuoteLine',
            'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
            'promocodetype' => 'App\\Enums\\PromoCodeType',
            'deliveryzone' => 'App\\Models\\DeliveryZone',
            'diningtable' => 'App\\Models\\DiningTable',
            'menuitem' => 'App\\Models\\MenuItem',
            'modifiergroup' => 'App\\Models\\ModifierGroup',
            'modifieroption' => 'App\\Models\\ModifierOption',
            'promocode' => 'App\\Models\\PromoCode',
            'restaurant' => 'App\\Models\\Restaurant',
            'localtime' => 'App\\Support\\LocalTime',
            'money' => 'App\\Support\\Money',
            'carbonimmutable' => 'Carbon\\CarbonImmutable',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'collection' => 'Illuminate\\Support\\Collection',
          ),
           'className' => 'App\\Services\\PricingService',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a5b8d127d2ce00098bad9fd872184efb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Services',
         'uses' => 
        array (
          'cart' => 'App\\Data\\Cart',
          'cartitem' => 'App\\Data\\CartItem',
          'quote' => 'App\\Data\\Quote',
          'quoteerror' => 'App\\Data\\QuoteError',
          'quoteline' => 'App\\Data\\QuoteLine',
          'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
          'promocodetype' => 'App\\Enums\\PromoCodeType',
          'deliveryzone' => 'App\\Models\\DeliveryZone',
          'diningtable' => 'App\\Models\\DiningTable',
          'menuitem' => 'App\\Models\\MenuItem',
          'modifiergroup' => 'App\\Models\\ModifierGroup',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'promocode' => 'App\\Models\\PromoCode',
          'restaurant' => 'App\\Models\\Restaurant',
          'localtime' => 'App\\Support\\LocalTime',
          'money' => 'App\\Support\\Money',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'App\\Services\\PricingService',
         'functionName' => 'discount',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Services',
           'uses' => 
          array (
            'cart' => 'App\\Data\\Cart',
            'cartitem' => 'App\\Data\\CartItem',
            'quote' => 'App\\Data\\Quote',
            'quoteerror' => 'App\\Data\\QuoteError',
            'quoteline' => 'App\\Data\\QuoteLine',
            'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
            'promocodetype' => 'App\\Enums\\PromoCodeType',
            'deliveryzone' => 'App\\Models\\DeliveryZone',
            'diningtable' => 'App\\Models\\DiningTable',
            'menuitem' => 'App\\Models\\MenuItem',
            'modifiergroup' => 'App\\Models\\ModifierGroup',
            'modifieroption' => 'App\\Models\\ModifierOption',
            'promocode' => 'App\\Models\\PromoCode',
            'restaurant' => 'App\\Models\\Restaurant',
            'localtime' => 'App\\Support\\LocalTime',
            'money' => 'App\\Support\\Money',
            'carbonimmutable' => 'Carbon\\CarbonImmutable',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'collection' => 'Illuminate\\Support\\Collection',
          ),
           'className' => 'App\\Services\\PricingService',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/app/Services/PricingService.php' => 'a4bd0c21b4e07f2eb7f240c33307c8ea1aa5ad30153a45ab4d0335de53d67c0c',
    ),
  ),
));