<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../laravel/sanctum/src/Http/Middleware/AuthenticateSession.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-29c95faa5740d16fcb75f3929dc917765bafc5b8ee5728ec80dd4b3dcd360aef-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'laravel\\sanctum\\http\\middleware\\authenticatesession' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));