<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../stripe/stripe-php/lib/Source.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-33d0eb71330de9a2f994c292e5568d54a1f35b6e63770efe516915ddb82c3fa1-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'stripe\\source' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));