<?php declare(strict_types = 1);

// ftm-/var/www/html/vendor/laravel/framework/src/Illuminate/Database/Eloquent/Attributes/RouteKey.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '9fc94308088f8cc2f903286bcb4ecc92' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Attributes',
         'uses' => 
        array (
          'attribute' => 'Attribute',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Attributes\\RouteKey',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '434d072bc42b3843d333e87fa402591e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Eloquent\\Attributes',
         'uses' => 
        array (
          'attribute' => 'Attribute',
        ),
         'className' => 'Illuminate\\Database\\Eloquent\\Attributes\\RouteKey',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/vendor/laravel/framework/src/Illuminate/Database/Eloquent/Attributes/RouteKey.php' => 'e5117e047e75781e50d378c0e52df96de7c72ba964c1adc9431e7991fdff0dfc',
    ),
  ),
));