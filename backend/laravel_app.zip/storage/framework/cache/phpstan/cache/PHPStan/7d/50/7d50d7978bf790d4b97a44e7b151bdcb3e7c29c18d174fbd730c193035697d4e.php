<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/support/src/Concerns/HasBadgeTooltip.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-5eca6b59488c69fd3996cdff15345fdc8ed603859d654eef58a9d34170bb12d0-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\support\\concerns\\hasbadgetooltip' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));