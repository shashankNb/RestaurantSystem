<?php declare(strict_types = 1);

// ftm-/var/www/html/vendor/laravel/framework/src/Illuminate/Broadcasting/PrivateChannel.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '4417edc9ff699004b3160c87db8880fd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Broadcasting',
         'uses' => 
        array (
          'hasbroadcastchannel' => 'Illuminate\\Contracts\\Broadcasting\\HasBroadcastChannel',
        ),
         'className' => 'Illuminate\\Broadcasting\\PrivateChannel',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd9d4848778cdcd89b2efdc46728f59a5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Broadcasting',
         'uses' => 
        array (
          'hasbroadcastchannel' => 'Illuminate\\Contracts\\Broadcasting\\HasBroadcastChannel',
        ),
         'className' => 'Illuminate\\Broadcasting\\PrivateChannel',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/vendor/laravel/framework/src/Illuminate/Broadcasting/PrivateChannel.php' => 'a927446dfa80fc8c52db68008ee0f6430e6edb95e4f4b889155c6eddc0200686',
    ),
  ),
));