<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../symfony/http-kernel/Exception/HttpException.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-eb9012af4a3bb1eef340f3b329abba79971ee2ab3bfc7bbec4802db13ced3d68-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'symfony\\component\\httpkernel\\exception\\httpexception' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));