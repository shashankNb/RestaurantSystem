<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/forms/src/Components/Concerns/CanLimitItemsLength.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-e2a7e5c94a1845085b9e761e884d78d42a3ee6e03ac5c9a354af8658b184619a-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\forms\\components\\concerns\\canlimititemslength' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));