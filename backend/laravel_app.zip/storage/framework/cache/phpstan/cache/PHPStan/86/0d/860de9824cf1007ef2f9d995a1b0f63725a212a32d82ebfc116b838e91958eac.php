<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../laravel/framework/src/Illuminate/Image/Image.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-e5c1e84434e07c6eeccf0e3c6919cf7b7c1ffe180e4dc606f412eb01ef609b5b-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\image\\image' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));