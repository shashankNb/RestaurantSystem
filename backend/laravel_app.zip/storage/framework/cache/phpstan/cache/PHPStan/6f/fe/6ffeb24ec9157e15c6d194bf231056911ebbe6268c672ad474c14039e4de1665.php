<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../stripe/stripe-php/lib/Service/OAuthService.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-1421515a488785a4a556910edd582c4c6f0fe188628bdf2f97a3c37e88f0f5fb-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'stripe\\service\\oauthservice' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));