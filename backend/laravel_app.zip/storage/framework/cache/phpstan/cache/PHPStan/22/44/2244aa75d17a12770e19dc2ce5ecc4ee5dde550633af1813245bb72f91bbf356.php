<?php declare(strict_types = 1);

// ftm-/var/www/html/database/factories/MembershipFactory.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'c920aa9e0bd008b896df2e1decc0c607' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Database\\Factories',
         'uses' => 
        array (
          'restaurantrole' => 'App\\Enums\\RestaurantRole',
          'membership' => 'App\\Models\\Membership',
          'restaurant' => 'App\\Models\\Restaurant',
          'user' => 'App\\Models\\User',
          'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
        ),
         'className' => 'Database\\Factories\\MembershipFactory',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1ef177a3d34d30529c036cccd9fec31a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Database\\Factories',
         'uses' => 
        array (
          'restaurantrole' => 'App\\Enums\\RestaurantRole',
          'membership' => 'App\\Models\\Membership',
          'restaurant' => 'App\\Models\\Restaurant',
          'user' => 'App\\Models\\User',
          'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
        ),
         'className' => 'Database\\Factories\\MembershipFactory',
         'functionName' => 'definition',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Database\\Factories',
           'uses' => 
          array (
            'restaurantrole' => 'App\\Enums\\RestaurantRole',
            'membership' => 'App\\Models\\Membership',
            'restaurant' => 'App\\Models\\Restaurant',
            'user' => 'App\\Models\\User',
            'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
          ),
           'className' => 'Database\\Factories\\MembershipFactory',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8109146e3a8d58745fd1047230b0a27b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Database\\Factories',
         'uses' => 
        array (
          'restaurantrole' => 'App\\Enums\\RestaurantRole',
          'membership' => 'App\\Models\\Membership',
          'restaurant' => 'App\\Models\\Restaurant',
          'user' => 'App\\Models\\User',
          'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
        ),
         'className' => 'Database\\Factories\\MembershipFactory',
         'functionName' => 'owner',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Database\\Factories',
           'uses' => 
          array (
            'restaurantrole' => 'App\\Enums\\RestaurantRole',
            'membership' => 'App\\Models\\Membership',
            'restaurant' => 'App\\Models\\Restaurant',
            'user' => 'App\\Models\\User',
            'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
          ),
           'className' => 'Database\\Factories\\MembershipFactory',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/database/factories/MembershipFactory.php' => 'b42d3740a52e50526cb6e0cae2c81c037ee0655bc3790f27e9b07dfa568b829d',
    ),
  ),
));