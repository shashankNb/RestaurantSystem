<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/actions/src/Concerns/CanRedirect.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-9653a3cbbefe3e6493d382ae2f6c6219d70353d0052673e547c1df0ee6a7ea3e-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\actions\\concerns\\canredirect' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));