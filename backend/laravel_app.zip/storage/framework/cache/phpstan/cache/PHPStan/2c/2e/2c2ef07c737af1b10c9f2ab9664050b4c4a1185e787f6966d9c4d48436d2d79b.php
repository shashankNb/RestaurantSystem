<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../laravel/framework/src/Illuminate/Http/Client/PendingRequest.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-bfd651eae2b2529fc276cb436f1188e4e01f8022ed6a6594b1c9ed62d2dc42c0-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\http\\client\\pendingrequest' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));