<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/widgets/src/Concerns/CanPoll.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-c1f491bb10c553149118f5ad329ed92d8e2b64c0dcb4ab94e1cc6f4f737e826f-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\widgets\\concerns\\canpoll' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));