<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../stripe/stripe-php/lib/Service/SetupIntentService.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-43e295e05236fe8b4e6b7baea6e12e4a87186a1dd1d49f787686f829f4491fde-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'stripe\\service\\setupintentservice' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));