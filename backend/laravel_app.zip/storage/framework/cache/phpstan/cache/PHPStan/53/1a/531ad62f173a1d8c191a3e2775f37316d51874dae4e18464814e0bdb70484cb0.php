<?php declare(strict_types = 1);

// osfsl-/var/www/html/bootstrap/app.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-d5cf646e1cd9014bb140bb1657fdedb1f5bb245593dd495bd6322a66ffea2b8f-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));