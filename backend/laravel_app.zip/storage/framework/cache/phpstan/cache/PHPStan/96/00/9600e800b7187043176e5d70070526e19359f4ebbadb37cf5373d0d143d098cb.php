<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../stripe/stripe-php/lib/Service/TaxIdService.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6f4b2622223706120b9a3c32e30e30dd5c16407e74d48041e0185a78c9eee0fa-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'stripe\\service\\taxidservice' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));