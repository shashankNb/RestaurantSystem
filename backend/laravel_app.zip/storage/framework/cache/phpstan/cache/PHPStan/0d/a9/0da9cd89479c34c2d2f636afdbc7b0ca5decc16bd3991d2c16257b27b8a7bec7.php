<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../stripe/stripe-php/lib/Service/V2/V2ServiceFactory.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-4d513eade9421a9d6061d795ec37239aa64720090284c4df0d323e652f2c97d0-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'stripe\\service\\v2\\v2servicefactory' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));