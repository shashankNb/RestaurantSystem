<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../laravel/framework/src/Illuminate/Broadcasting/PendingBroadcast.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-1efbf66f8b5d9e05aa0571f8c44b7085634315952b56db562afa4a75d4c294ef-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\broadcasting\\pendingbroadcast' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));