<?php declare(strict_types = 1);

// odsl-/var/www/html/app/Filament/Resources/ModifierGroups/Tables/ModifierGroupsTable.php-PHPStan\BetterReflection\Reflection\ReflectionClass-App\Filament\Resources\ModifierGroups\Tables\ModifierGroupsTable
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.73.0.5-8.5.11-22bb74e4fe2b8ffa88712561a2ee8bad42d696db3e2a89ab736a9de839b54805',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'App\\Filament\\Resources\\ModifierGroups\\Tables\\ModifierGroupsTable',
        'filename' => '/var/www/html/app/Filament/Resources/ModifierGroups/Tables/ModifierGroupsTable.php',
      ),
    ),
    'namespace' => 'App\\Filament\\Resources\\ModifierGroups\\Tables',
    'name' => 'App\\Filament\\Resources\\ModifierGroups\\Tables\\ModifierGroupsTable',
    'shortName' => 'ModifierGroupsTable',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 10,
    'endLine' => 36,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => NULL,
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'configure' => 
      array (
        'name' => 'configure',
        'parameters' => 
        array (
          'table' => 
          array (
            'name' => 'table',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'Filament\\Tables\\Table',
                'isIdentifier' => false,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 12,
            'endLine' => 12,
            'startColumn' => 38,
            'endColumn' => 49,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'Filament\\Tables\\Table',
            'isIdentifier' => false,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 12,
        'endLine' => 35,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 17,
        'namespace' => 'App\\Filament\\Resources\\ModifierGroups\\Tables',
        'declaringClassName' => 'App\\Filament\\Resources\\ModifierGroups\\Tables\\ModifierGroupsTable',
        'implementingClassName' => 'App\\Filament\\Resources\\ModifierGroups\\Tables\\ModifierGroupsTable',
        'currentClassName' => 'App\\Filament\\Resources\\ModifierGroups\\Tables\\ModifierGroupsTable',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));