<?php declare(strict_types = 1);

// ftm-/var/www/html/app/Data/Shift.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '812e13286de0f9e83a63105e4c9be9b9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Data',
         'uses' => 
        array (
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
        ),
         'className' => 'App\\Data\\Shift',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bfc5feb6154324bde4a186c476206753' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Data',
         'uses' => 
        array (
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
        ),
         'className' => 'App\\Data\\Shift',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Data',
           'uses' => 
          array (
            'carbonimmutable' => 'Carbon\\CarbonImmutable',
          ),
           'className' => 'App\\Data\\Shift',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b244047974eea96b861e911a9f38afa8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Data',
         'uses' => 
        array (
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
        ),
         'className' => 'App\\Data\\Shift',
         'functionName' => 'contains',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Data',
           'uses' => 
          array (
            'carbonimmutable' => 'Carbon\\CarbonImmutable',
          ),
           'className' => 'App\\Data\\Shift',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/app/Data/Shift.php' => 'c45414fd2be0b04e1d8e9b4848bd2a13b40a5e268652a4ac5222e44c6b6026ae',
    ),
  ),
));