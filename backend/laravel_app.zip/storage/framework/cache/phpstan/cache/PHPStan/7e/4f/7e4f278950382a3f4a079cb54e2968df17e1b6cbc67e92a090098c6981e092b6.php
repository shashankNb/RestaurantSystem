<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../stripe/stripe-php/lib/Exception/UnexpectedValueException.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Stripe\Exception\UnexpectedValueException
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-214a04ac102e55fc065ee491d05e2bf79b5e564a06c40bf989825f51fbbf02de-8.5.11-6.73.0.5',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Stripe\\Exception\\UnexpectedValueException',
        'filename' => '/var/www/html/vendor/composer/../stripe/stripe-php/lib/Exception/UnexpectedValueException.php',
      ),
    ),
    'namespace' => 'Stripe\\Exception',
    'name' => 'Stripe\\Exception\\UnexpectedValueException',
    'shortName' => 'UnexpectedValueException',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 5,
    'endLine' => 5,
    'startColumn' => 1,
    'endColumn' => 97,
    'parentClassName' => 'UnexpectedValueException',
    'implementsClassNames' => 
    array (
      0 => 'Stripe\\Exception\\ExceptionInterface',
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));