<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/tables/src/Table/Concerns/HasRecordActions.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-49c467aaef7477adfc1b45f534577ffbc7a76ea41ab03cc679018d9aef70957a-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\tables\\table\\concerns\\hasrecordactions' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));