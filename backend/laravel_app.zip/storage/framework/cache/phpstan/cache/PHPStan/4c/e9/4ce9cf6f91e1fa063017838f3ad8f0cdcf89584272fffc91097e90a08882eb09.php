<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/support/src/Concerns/HasCellState.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-1705ba35cda39eab025266d06e95349cddb522d3163a7dfe4ede3b22ff5d1639-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\support\\concerns\\hascellstate' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));