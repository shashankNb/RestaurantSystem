<?php declare(strict_types = 1);

// ftm-/var/www/html/app/Policies/CustomerAddressPolicy.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '24a18022456e059895275a499793ca7f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Policies',
         'uses' => 
        array (
          'customeraddress' => 'App\\Models\\CustomerAddress',
          'user' => 'App\\Models\\User',
          'response' => 'Illuminate\\Auth\\Access\\Response',
        ),
         'className' => 'App\\Policies\\CustomerAddressPolicy',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '02a28331030ec9b298be2f6d074c14cb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Policies',
         'uses' => 
        array (
          'customeraddress' => 'App\\Models\\CustomerAddress',
          'user' => 'App\\Models\\User',
          'response' => 'Illuminate\\Auth\\Access\\Response',
        ),
         'className' => 'App\\Policies\\CustomerAddressPolicy',
         'functionName' => 'update',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Policies',
           'uses' => 
          array (
            'customeraddress' => 'App\\Models\\CustomerAddress',
            'user' => 'App\\Models\\User',
            'response' => 'Illuminate\\Auth\\Access\\Response',
          ),
           'className' => 'App\\Policies\\CustomerAddressPolicy',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd4830b46b405060f5c00a56958b5db37' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Policies',
         'uses' => 
        array (
          'customeraddress' => 'App\\Models\\CustomerAddress',
          'user' => 'App\\Models\\User',
          'response' => 'Illuminate\\Auth\\Access\\Response',
        ),
         'className' => 'App\\Policies\\CustomerAddressPolicy',
         'functionName' => 'delete',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Policies',
           'uses' => 
          array (
            'customeraddress' => 'App\\Models\\CustomerAddress',
            'user' => 'App\\Models\\User',
            'response' => 'Illuminate\\Auth\\Access\\Response',
          ),
           'className' => 'App\\Policies\\CustomerAddressPolicy',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/app/Policies/CustomerAddressPolicy.php' => 'f339a15b835e1a72e561988da4b4aee6bf3af9d2520afd5a731350c726c81739',
    ),
  ),
));