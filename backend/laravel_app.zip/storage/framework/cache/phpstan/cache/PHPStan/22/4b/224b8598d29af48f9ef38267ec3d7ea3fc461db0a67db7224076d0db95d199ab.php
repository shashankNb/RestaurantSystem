<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../laravel/framework/src/Illuminate/Support/Facades/Log.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Illuminate\Support\Facades\Log
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-9bd1ef34080a4622b92f698ecb0e1ae96aff81ec85d8cac6239bdb521230323a-8.5.11-6.73.0.5',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Illuminate\\Support\\Facades\\Log',
        'filename' => '/var/www/html/vendor/composer/../laravel/framework/src/Illuminate/Support/Facades/Log.php',
      ),
    ),
    'namespace' => 'Illuminate\\Support\\Facades',
    'name' => 'Illuminate\\Support\\Facades\\Log',
    'shortName' => 'Log',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => '/**
 * @method static \\Psr\\Log\\LoggerInterface build(array $config)
 * @method static \\Psr\\Log\\LoggerInterface stack(array $channels, string|null $channel = null)
 * @method static \\Psr\\Log\\LoggerInterface channel(\\UnitEnum|string|null $channel = null)
 * @method static \\Psr\\Log\\LoggerInterface driver(\\UnitEnum|string|null $driver = null)
 * @method static \\Illuminate\\Log\\LogManager shareContext(array $context)
 * @method static array sharedContext()
 * @method static \\Illuminate\\Log\\LogManager withoutContext(string[]|null $keys = null)
 * @method static \\Illuminate\\Log\\LogManager flushSharedContext()
 * @method static string|null getDefaultDriver()
 * @method static void setDefaultDriver(\\UnitEnum|string $name)
 * @method static \\Illuminate\\Log\\LogManager extend(string $driver, \\Closure $callback)
 * @method static void forgetChannel(\\UnitEnum|string|null $driver = null)
 * @method static array getChannels()
 * @method static void emergency(string|\\Stringable $message, array $context = [])
 * @method static void alert(string|\\Stringable $message, array $context = [])
 * @method static void critical(string|\\Stringable $message, array $context = [])
 * @method static void error(string|\\Stringable $message, array $context = [])
 * @method static void warning(string|\\Stringable $message, array $context = [])
 * @method static void notice(string|\\Stringable $message, array $context = [])
 * @method static void info(string|\\Stringable $message, array $context = [])
 * @method static void debug(string|\\Stringable $message, array $context = [])
 * @method static void log(mixed $level, string|\\Stringable $message, array $context = [])
 * @method static \\Illuminate\\Log\\LogManager setApplication(\\Illuminate\\Contracts\\Foundation\\Application $app)
 * @method static void write(string $level, \\Illuminate\\Contracts\\Support\\Arrayable|\\Illuminate\\Contracts\\Support\\Jsonable|\\Illuminate\\Support\\Stringable|array|string $message, array $context = [])
 * @method static \\Illuminate\\Log\\Logger withContext(array $context = [])
 * @method static void listen(\\Closure $callback)
 * @method static \\Psr\\Log\\LoggerInterface getLogger()
 * @method static \\Illuminate\\Contracts\\Events\\Dispatcher|null getEventDispatcher()
 * @method static void setEventDispatcher(\\Illuminate\\Contracts\\Events\\Dispatcher $dispatcher)
 * @method static \\Illuminate\\Log\\Logger|mixed when(\\Closure|mixed|null $value = null, callable|null $callback = null, callable|null $default = null)
 * @method static \\Illuminate\\Log\\Logger|mixed unless(\\Closure|mixed|null $value = null, callable|null $callback = null, callable|null $default = null)
 *
 * @see \\Illuminate\\Log\\LogManager
 */',
    'attributes' => 
    array (
    ),
    'startLine' => 40,
    'endLine' => 51,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'Illuminate\\Support\\Facades\\Facade',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'getFacadeAccessor' => 
      array (
        'name' => 'getFacadeAccessor',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Get the registered name of the component.
 *
 * @return string
 */',
        'startLine' => 47,
        'endLine' => 50,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 18,
        'namespace' => 'Illuminate\\Support\\Facades',
        'declaringClassName' => 'Illuminate\\Support\\Facades\\Log',
        'implementingClassName' => 'Illuminate\\Support\\Facades\\Log',
        'currentClassName' => 'Illuminate\\Support\\Facades\\Log',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));