<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../stripe/stripe-php/lib/Service/BillingPortal/BillingPortalServiceFactory.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-13d53d8337c299ae09f5fcd076fb323602514656c6fc56402898a2aa60670867-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'stripe\\service\\billingportal\\billingportalservicefactory' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));