<?php declare(strict_types = 1);

// ftm-/var/www/html/app/Services/CheckoutService.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '7feb92e8f25f8203961f9da72add0834' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Services',
         'uses' => 
        array (
          'cart' => 'App\\Data\\Cart',
          'checkout' => 'App\\Data\\Checkout',
          'customer' => 'App\\Data\\Customer',
          'quote' => 'App\\Data\\Quote',
          'quoteline' => 'App\\Data\\QuoteLine',
          'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
          'orderstatus' => 'App\\Enums\\OrderStatus',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'order' => 'App\\Models\\Order',
          'restaurant' => 'App\\Models\\Restaurant',
          'user' => 'App\\Models\\User',
          'paymentgateway' => 'App\\Payments\\PaymentGateway',
          'paymentintent' => 'App\\Payments\\PaymentIntent',
          'paymentsunavailable' => 'App\\Payments\\PaymentsUnavailable',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'cache' => 'Illuminate\\Support\\Facades\\Cache',
          'db' => 'Illuminate\\Support\\Facades\\DB',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'App\\Services\\CheckoutService',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c3ed42140d148b25d325a918fa83d313' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Services',
         'uses' => 
        array (
          'cart' => 'App\\Data\\Cart',
          'checkout' => 'App\\Data\\Checkout',
          'customer' => 'App\\Data\\Customer',
          'quote' => 'App\\Data\\Quote',
          'quoteline' => 'App\\Data\\QuoteLine',
          'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
          'orderstatus' => 'App\\Enums\\OrderStatus',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'order' => 'App\\Models\\Order',
          'restaurant' => 'App\\Models\\Restaurant',
          'user' => 'App\\Models\\User',
          'paymentgateway' => 'App\\Payments\\PaymentGateway',
          'paymentintent' => 'App\\Payments\\PaymentIntent',
          'paymentsunavailable' => 'App\\Payments\\PaymentsUnavailable',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'cache' => 'Illuminate\\Support\\Facades\\Cache',
          'db' => 'Illuminate\\Support\\Facades\\DB',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'App\\Services\\CheckoutService',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Services',
           'uses' => 
          array (
            'cart' => 'App\\Data\\Cart',
            'checkout' => 'App\\Data\\Checkout',
            'customer' => 'App\\Data\\Customer',
            'quote' => 'App\\Data\\Quote',
            'quoteline' => 'App\\Data\\QuoteLine',
            'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
            'orderstatus' => 'App\\Enums\\OrderStatus',
            'modifieroption' => 'App\\Models\\ModifierOption',
            'order' => 'App\\Models\\Order',
            'restaurant' => 'App\\Models\\Restaurant',
            'user' => 'App\\Models\\User',
            'paymentgateway' => 'App\\Payments\\PaymentGateway',
            'paymentintent' => 'App\\Payments\\PaymentIntent',
            'paymentsunavailable' => 'App\\Payments\\PaymentsUnavailable',
            'carbonimmutable' => 'Carbon\\CarbonImmutable',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'cache' => 'Illuminate\\Support\\Facades\\Cache',
            'db' => 'Illuminate\\Support\\Facades\\DB',
            'str' => 'Illuminate\\Support\\Str',
          ),
           'className' => 'App\\Services\\CheckoutService',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '45f42c205ab821f2ff43e00296fa4a44' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Services',
         'uses' => 
        array (
          'cart' => 'App\\Data\\Cart',
          'checkout' => 'App\\Data\\Checkout',
          'customer' => 'App\\Data\\Customer',
          'quote' => 'App\\Data\\Quote',
          'quoteline' => 'App\\Data\\QuoteLine',
          'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
          'orderstatus' => 'App\\Enums\\OrderStatus',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'order' => 'App\\Models\\Order',
          'restaurant' => 'App\\Models\\Restaurant',
          'user' => 'App\\Models\\User',
          'paymentgateway' => 'App\\Payments\\PaymentGateway',
          'paymentintent' => 'App\\Payments\\PaymentIntent',
          'paymentsunavailable' => 'App\\Payments\\PaymentsUnavailable',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'cache' => 'Illuminate\\Support\\Facades\\Cache',
          'db' => 'Illuminate\\Support\\Facades\\DB',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'App\\Services\\CheckoutService',
         'functionName' => 'checkout',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Services',
           'uses' => 
          array (
            'cart' => 'App\\Data\\Cart',
            'checkout' => 'App\\Data\\Checkout',
            'customer' => 'App\\Data\\Customer',
            'quote' => 'App\\Data\\Quote',
            'quoteline' => 'App\\Data\\QuoteLine',
            'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
            'orderstatus' => 'App\\Enums\\OrderStatus',
            'modifieroption' => 'App\\Models\\ModifierOption',
            'order' => 'App\\Models\\Order',
            'restaurant' => 'App\\Models\\Restaurant',
            'user' => 'App\\Models\\User',
            'paymentgateway' => 'App\\Payments\\PaymentGateway',
            'paymentintent' => 'App\\Payments\\PaymentIntent',
            'paymentsunavailable' => 'App\\Payments\\PaymentsUnavailable',
            'carbonimmutable' => 'Carbon\\CarbonImmutable',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'cache' => 'Illuminate\\Support\\Facades\\Cache',
            'db' => 'Illuminate\\Support\\Facades\\DB',
            'str' => 'Illuminate\\Support\\Str',
          ),
           'className' => 'App\\Services\\CheckoutService',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '490c0b5368be4c85269ee339b35d42ee' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Services',
         'uses' => 
        array (
          'cart' => 'App\\Data\\Cart',
          'checkout' => 'App\\Data\\Checkout',
          'customer' => 'App\\Data\\Customer',
          'quote' => 'App\\Data\\Quote',
          'quoteline' => 'App\\Data\\QuoteLine',
          'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
          'orderstatus' => 'App\\Enums\\OrderStatus',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'order' => 'App\\Models\\Order',
          'restaurant' => 'App\\Models\\Restaurant',
          'user' => 'App\\Models\\User',
          'paymentgateway' => 'App\\Payments\\PaymentGateway',
          'paymentintent' => 'App\\Payments\\PaymentIntent',
          'paymentsunavailable' => 'App\\Payments\\PaymentsUnavailable',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'cache' => 'Illuminate\\Support\\Facades\\Cache',
          'db' => 'Illuminate\\Support\\Facades\\DB',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'App\\Services\\CheckoutService',
         'functionName' => 'resume',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Services',
           'uses' => 
          array (
            'cart' => 'App\\Data\\Cart',
            'checkout' => 'App\\Data\\Checkout',
            'customer' => 'App\\Data\\Customer',
            'quote' => 'App\\Data\\Quote',
            'quoteline' => 'App\\Data\\QuoteLine',
            'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
            'orderstatus' => 'App\\Enums\\OrderStatus',
            'modifieroption' => 'App\\Models\\ModifierOption',
            'order' => 'App\\Models\\Order',
            'restaurant' => 'App\\Models\\Restaurant',
            'user' => 'App\\Models\\User',
            'paymentgateway' => 'App\\Payments\\PaymentGateway',
            'paymentintent' => 'App\\Payments\\PaymentIntent',
            'paymentsunavailable' => 'App\\Payments\\PaymentsUnavailable',
            'carbonimmutable' => 'Carbon\\CarbonImmutable',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'cache' => 'Illuminate\\Support\\Facades\\Cache',
            'db' => 'Illuminate\\Support\\Facades\\DB',
            'str' => 'Illuminate\\Support\\Str',
          ),
           'className' => 'App\\Services\\CheckoutService',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dad4c6ff3f2271742e619eb8f25e5dd4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Services',
         'uses' => 
        array (
          'cart' => 'App\\Data\\Cart',
          'checkout' => 'App\\Data\\Checkout',
          'customer' => 'App\\Data\\Customer',
          'quote' => 'App\\Data\\Quote',
          'quoteline' => 'App\\Data\\QuoteLine',
          'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
          'orderstatus' => 'App\\Enums\\OrderStatus',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'order' => 'App\\Models\\Order',
          'restaurant' => 'App\\Models\\Restaurant',
          'user' => 'App\\Models\\User',
          'paymentgateway' => 'App\\Payments\\PaymentGateway',
          'paymentintent' => 'App\\Payments\\PaymentIntent',
          'paymentsunavailable' => 'App\\Payments\\PaymentsUnavailable',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'cache' => 'Illuminate\\Support\\Facades\\Cache',
          'db' => 'Illuminate\\Support\\Facades\\DB',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'App\\Services\\CheckoutService',
         'functionName' => 'attachPaymentIntent',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Services',
           'uses' => 
          array (
            'cart' => 'App\\Data\\Cart',
            'checkout' => 'App\\Data\\Checkout',
            'customer' => 'App\\Data\\Customer',
            'quote' => 'App\\Data\\Quote',
            'quoteline' => 'App\\Data\\QuoteLine',
            'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
            'orderstatus' => 'App\\Enums\\OrderStatus',
            'modifieroption' => 'App\\Models\\ModifierOption',
            'order' => 'App\\Models\\Order',
            'restaurant' => 'App\\Models\\Restaurant',
            'user' => 'App\\Models\\User',
            'paymentgateway' => 'App\\Payments\\PaymentGateway',
            'paymentintent' => 'App\\Payments\\PaymentIntent',
            'paymentsunavailable' => 'App\\Payments\\PaymentsUnavailable',
            'carbonimmutable' => 'Carbon\\CarbonImmutable',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'cache' => 'Illuminate\\Support\\Facades\\Cache',
            'db' => 'Illuminate\\Support\\Facades\\DB',
            'str' => 'Illuminate\\Support\\Str',
          ),
           'className' => 'App\\Services\\CheckoutService',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c439785fca5367deba6a0dab1726ddb8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Services',
         'uses' => 
        array (
          'cart' => 'App\\Data\\Cart',
          'checkout' => 'App\\Data\\Checkout',
          'customer' => 'App\\Data\\Customer',
          'quote' => 'App\\Data\\Quote',
          'quoteline' => 'App\\Data\\QuoteLine',
          'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
          'orderstatus' => 'App\\Enums\\OrderStatus',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'order' => 'App\\Models\\Order',
          'restaurant' => 'App\\Models\\Restaurant',
          'user' => 'App\\Models\\User',
          'paymentgateway' => 'App\\Payments\\PaymentGateway',
          'paymentintent' => 'App\\Payments\\PaymentIntent',
          'paymentsunavailable' => 'App\\Payments\\PaymentsUnavailable',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'cache' => 'Illuminate\\Support\\Facades\\Cache',
          'db' => 'Illuminate\\Support\\Facades\\DB',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'App\\Services\\CheckoutService',
         'functionName' => 'createOrder',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Services',
           'uses' => 
          array (
            'cart' => 'App\\Data\\Cart',
            'checkout' => 'App\\Data\\Checkout',
            'customer' => 'App\\Data\\Customer',
            'quote' => 'App\\Data\\Quote',
            'quoteline' => 'App\\Data\\QuoteLine',
            'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
            'orderstatus' => 'App\\Enums\\OrderStatus',
            'modifieroption' => 'App\\Models\\ModifierOption',
            'order' => 'App\\Models\\Order',
            'restaurant' => 'App\\Models\\Restaurant',
            'user' => 'App\\Models\\User',
            'paymentgateway' => 'App\\Payments\\PaymentGateway',
            'paymentintent' => 'App\\Payments\\PaymentIntent',
            'paymentsunavailable' => 'App\\Payments\\PaymentsUnavailable',
            'carbonimmutable' => 'Carbon\\CarbonImmutable',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'cache' => 'Illuminate\\Support\\Facades\\Cache',
            'db' => 'Illuminate\\Support\\Facades\\DB',
            'str' => 'Illuminate\\Support\\Str',
          ),
           'className' => 'App\\Services\\CheckoutService',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ba4bc05c4ea42a51aefb6f1c1d566dfc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Services',
         'uses' => 
        array (
          'cart' => 'App\\Data\\Cart',
          'checkout' => 'App\\Data\\Checkout',
          'customer' => 'App\\Data\\Customer',
          'quote' => 'App\\Data\\Quote',
          'quoteline' => 'App\\Data\\QuoteLine',
          'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
          'orderstatus' => 'App\\Enums\\OrderStatus',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'order' => 'App\\Models\\Order',
          'restaurant' => 'App\\Models\\Restaurant',
          'user' => 'App\\Models\\User',
          'paymentgateway' => 'App\\Payments\\PaymentGateway',
          'paymentintent' => 'App\\Payments\\PaymentIntent',
          'paymentsunavailable' => 'App\\Payments\\PaymentsUnavailable',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
          'cache' => 'Illuminate\\Support\\Facades\\Cache',
          'db' => 'Illuminate\\Support\\Facades\\DB',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'App\\Services\\CheckoutService',
         'functionName' => 'createItem',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Services',
           'uses' => 
          array (
            'cart' => 'App\\Data\\Cart',
            'checkout' => 'App\\Data\\Checkout',
            'customer' => 'App\\Data\\Customer',
            'quote' => 'App\\Data\\Quote',
            'quoteline' => 'App\\Data\\QuoteLine',
            'fulfilmenttype' => 'App\\Enums\\FulfilmentType',
            'orderstatus' => 'App\\Enums\\OrderStatus',
            'modifieroption' => 'App\\Models\\ModifierOption',
            'order' => 'App\\Models\\Order',
            'restaurant' => 'App\\Models\\Restaurant',
            'user' => 'App\\Models\\User',
            'paymentgateway' => 'App\\Payments\\PaymentGateway',
            'paymentintent' => 'App\\Payments\\PaymentIntent',
            'paymentsunavailable' => 'App\\Payments\\PaymentsUnavailable',
            'carbonimmutable' => 'Carbon\\CarbonImmutable',
            'uniqueconstraintviolationexception' => 'Illuminate\\Database\\UniqueConstraintViolationException',
            'cache' => 'Illuminate\\Support\\Facades\\Cache',
            'db' => 'Illuminate\\Support\\Facades\\DB',
            'str' => 'Illuminate\\Support\\Str',
          ),
           'className' => 'App\\Services\\CheckoutService',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/app/Services/CheckoutService.php' => 'f3406c777da19b19e47763e77e26f6b3c1e7ef67f76ab59b5affe49cae20e871',
    ),
  ),
));