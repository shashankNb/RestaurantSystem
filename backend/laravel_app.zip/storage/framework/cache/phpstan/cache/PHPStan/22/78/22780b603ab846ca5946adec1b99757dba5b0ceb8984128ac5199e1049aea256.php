<?php declare(strict_types = 1);

// ftm-/var/www/html/app/Http/Controllers/Api/RestaurantController.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '1b4d2d8c25a7cba63f0d6671fcebab2f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Http\\Controllers\\Api',
         'uses' => 
        array (
          'controller' => 'App\\Http\\Controllers\\Controller',
          'restaurantresource' => 'App\\Http\\Resources\\RestaurantResource',
          'restaurant' => 'App\\Models\\Restaurant',
          'openinghoursservice' => 'App\\Services\\OpeningHoursService',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'hasmany' => 'Illuminate\\Database\\Eloquent\\Relations\\HasMany',
        ),
         'className' => 'App\\Http\\Controllers\\Api\\RestaurantController',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9f70f07222f1f1f8f94401a87100d748' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Http\\Controllers\\Api',
         'uses' => 
        array (
          'controller' => 'App\\Http\\Controllers\\Controller',
          'restaurantresource' => 'App\\Http\\Resources\\RestaurantResource',
          'restaurant' => 'App\\Models\\Restaurant',
          'openinghoursservice' => 'App\\Services\\OpeningHoursService',
          'carbonimmutable' => 'Carbon\\CarbonImmutable',
          'hasmany' => 'Illuminate\\Database\\Eloquent\\Relations\\HasMany',
        ),
         'className' => 'App\\Http\\Controllers\\Api\\RestaurantController',
         'functionName' => 'show',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/app/Http/Controllers/Api/RestaurantController.php' => '6f84e2843222b1a8ae0e8eb5e921779050dfaaa5a1c8d8dc843600f3c5ea977a',
    ),
  ),
));