<?php declare(strict_types = 1);

// odsl-/var/www/html/app/Filament/Resources/ModifierGroups/Pages/ListModifierGroups.php-PHPStan\BetterReflection\Reflection\ReflectionClass-App\Filament\Resources\ModifierGroups\Pages\ListModifierGroups
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.73.0.5-8.5.11-e54e8301b830f241d6f56d04f32b6cef30c2fde5853c319686f636bd9a461fd3',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'App\\Filament\\Resources\\ModifierGroups\\Pages\\ListModifierGroups',
        'filename' => '/var/www/html/app/Filament/Resources/ModifierGroups/Pages/ListModifierGroups.php',
      ),
    ),
    'namespace' => 'App\\Filament\\Resources\\ModifierGroups\\Pages',
    'name' => 'App\\Filament\\Resources\\ModifierGroups\\Pages\\ListModifierGroups',
    'shortName' => 'ListModifierGroups',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 9,
    'endLine' => 19,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'Filament\\Resources\\Pages\\ListRecords',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
      'resource' => 
      array (
        'declaringClassName' => 'App\\Filament\\Resources\\ModifierGroups\\Pages\\ListModifierGroups',
        'implementingClassName' => 'App\\Filament\\Resources\\ModifierGroups\\Pages\\ListModifierGroups',
        'name' => 'resource',
        'modifiers' => 18,
        'type' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'string',
            'isIdentifier' => true,
          ),
        ),
        'default' => 
        array (
          'code' => '\\App\\Filament\\Resources\\ModifierGroups\\ModifierGroupResource::class',
          'attributes' => 
          array (
            'startLine' => 11,
            'endLine' => 11,
            'startTokenPos' => 42,
            'startFilePos' => 293,
            'endTokenPos' => 44,
            'endFilePos' => 320,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 11,
        'endLine' => 11,
        'startColumn' => 5,
        'endColumn' => 69,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
    ),
    'immediateMethods' => 
    array (
      'getHeaderActions' => 
      array (
        'name' => 'getHeaderActions',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'array',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 13,
        'endLine' => 18,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'App\\Filament\\Resources\\ModifierGroups\\Pages',
        'declaringClassName' => 'App\\Filament\\Resources\\ModifierGroups\\Pages\\ListModifierGroups',
        'implementingClassName' => 'App\\Filament\\Resources\\ModifierGroups\\Pages\\ListModifierGroups',
        'currentClassName' => 'App\\Filament\\Resources\\ModifierGroups\\Pages\\ListModifierGroups',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));