<?php declare(strict_types = 1);

// ftm-/var/www/html/vendor/filament/support/src/Contracts/HasColor.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '2265ff8ca0d50b9d37c26735f5758bec' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Contracts',
         'uses' => 
        array (
        ),
         'className' => 'Filament\\Support\\Contracts\\HasColor',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cd177743b70ed5c6a3fc2470baee6d27' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Contracts',
         'uses' => 
        array (
        ),
         'className' => 'Filament\\Support\\Contracts\\HasColor',
         'functionName' => 'getColor',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/vendor/filament/support/src/Contracts/HasColor.php' => '6e16d5ba8f28e42641f9f981791c990529fb8c1a487af76d4de59574bd31ac67',
    ),
  ),
));