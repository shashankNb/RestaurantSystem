<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/tables/src/Columns/ColumnGroup.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-82a86c7dd7ae4e932d84a4103d809dd44bf637407f97b2c519b8d9186f05fb2c-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\tables\\columns\\columngroup' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));