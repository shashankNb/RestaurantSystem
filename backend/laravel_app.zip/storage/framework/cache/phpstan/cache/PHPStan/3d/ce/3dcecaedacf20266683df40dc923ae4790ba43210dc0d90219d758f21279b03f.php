<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/tables/src/Filters/Concerns/HasDefaultState.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Filament\Tables\Filters\Concerns\HasDefaultState
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6312aa26045d22147863982b41a441136fac335d414a625b9a13bc5dd1f2e0ca-8.5.11-6.73.0.5',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Filament\\Tables\\Filters\\Concerns\\HasDefaultState',
        'filename' => '/var/www/html/vendor/composer/../filament/tables/src/Filters/Concerns/HasDefaultState.php',
      ),
    ),
    'namespace' => 'Filament\\Tables\\Filters\\Concerns',
    'name' => 'Filament\\Tables\\Filters\\Concerns\\HasDefaultState',
    'shortName' => 'HasDefaultState',
    'isInterface' => false,
    'isTrait' => true,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 5,
    'endLine' => 20,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => NULL,
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
      'defaultState' => 
      array (
        'declaringClassName' => 'Filament\\Tables\\Filters\\Concerns\\HasDefaultState',
        'implementingClassName' => 'Filament\\Tables\\Filters\\Concerns\\HasDefaultState',
        'name' => 'defaultState',
        'modifiers' => 2,
        'type' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'mixed',
            'isIdentifier' => true,
          ),
        ),
        'default' => 
        array (
          'code' => 'null',
          'attributes' => 
          array (
            'startLine' => 7,
            'endLine' => 7,
            'startTokenPos' => 21,
            'startFilePos' => 112,
            'endTokenPos' => 21,
            'endFilePos' => 115,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 7,
        'endLine' => 7,
        'startColumn' => 5,
        'endColumn' => 41,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
    ),
    'immediateMethods' => 
    array (
      'default' => 
      array (
        'name' => 'default',
        'parameters' => 
        array (
          'state' => 
          array (
            'name' => 'state',
            'default' => 
            array (
              'code' => 'true',
              'attributes' => 
              array (
                'startLine' => 9,
                'endLine' => 9,
                'startTokenPos' => 36,
                'startFilePos' => 162,
                'endTokenPos' => 36,
                'endFilePos' => 165,
              ),
            ),
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'mixed',
                'isIdentifier' => true,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 9,
            'endLine' => 9,
            'startColumn' => 29,
            'endColumn' => 47,
            'parameterIndex' => 0,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'static',
            'isIdentifier' => false,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 9,
        'endLine' => 14,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Filament\\Tables\\Filters\\Concerns',
        'declaringClassName' => 'Filament\\Tables\\Filters\\Concerns\\HasDefaultState',
        'implementingClassName' => 'Filament\\Tables\\Filters\\Concerns\\HasDefaultState',
        'currentClassName' => 'Filament\\Tables\\Filters\\Concerns\\HasDefaultState',
        'aliasName' => NULL,
      ),
      'getDefaultState' => 
      array (
        'name' => 'getDefaultState',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'mixed',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 16,
        'endLine' => 19,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Filament\\Tables\\Filters\\Concerns',
        'declaringClassName' => 'Filament\\Tables\\Filters\\Concerns\\HasDefaultState',
        'implementingClassName' => 'Filament\\Tables\\Filters\\Concerns\\HasDefaultState',
        'currentClassName' => 'Filament\\Tables\\Filters\\Concerns\\HasDefaultState',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));