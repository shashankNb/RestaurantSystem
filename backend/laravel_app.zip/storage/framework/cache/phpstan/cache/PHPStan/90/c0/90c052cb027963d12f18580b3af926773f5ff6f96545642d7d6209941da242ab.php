<?php declare(strict_types = 1);

// ftm-/var/www/html/vendor/filament/actions/src/ActionGroup.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'bb3808a8c34ab058b54fcdebd67b1f50' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '81f7fe123d1c1ffda02f8cdbe2d77e2e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\View\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'iconposition' => 'Filament\\Support\\Enums\\IconPosition',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'size' => 'Filament\\Support\\Enums\\Size',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'badgecomponent' => 'Filament\\Support\\View\\Components\\BadgeComponent',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'js' => 'Illuminate\\Support\\Js',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'a7b056ce8665a799790c28d6bcff3593' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\View\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'iconposition' => 'Filament\\Support\\Enums\\IconPosition',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'size' => 'Filament\\Support\\Enums\\Size',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'badgecomponent' => 'Filament\\Support\\View\\Components\\BadgeComponent',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'js' => 'Illuminate\\Support\\Js',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'generateBadgeHtml',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'c7aedcc3a3ba75619ff07071b793d24d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\View\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'iconposition' => 'Filament\\Support\\Enums\\IconPosition',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'size' => 'Filament\\Support\\Enums\\Size',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'badgecomponent' => 'Filament\\Support\\View\\Components\\BadgeComponent',
          'buttoncomponent' => 'Filament\\Support\\View\\Components\\ButtonComponent',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'js' => 'Illuminate\\Support\\Js',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '6312d8fdffc60db29d684bad94d2d557' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\View\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'iconposition' => 'Filament\\Support\\Enums\\IconPosition',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'size' => 'Filament\\Support\\Enums\\Size',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'badgecomponent' => 'Filament\\Support\\View\\Components\\BadgeComponent',
          'buttoncomponent' => 'Filament\\Support\\View\\Components\\ButtonComponent',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'js' => 'Illuminate\\Support\\Js',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'generateButtonHtml',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'd5a929ec2cc21e38c7743a935f959941' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\View\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'badgecomponent' => 'Filament\\Support\\View\\Components\\BadgeComponent',
          'itemcomponent' => 'Filament\\Support\\View\\Components\\DropdownComponent\\ItemComponent',
          'iconcomponent' => 'Filament\\Support\\View\\Components\\DropdownComponent\\ItemComponent\\IconComponent',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'js' => 'Illuminate\\Support\\Js',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '36f18854c19610bb7da4ee71ff84ece6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\View\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'badgecomponent' => 'Filament\\Support\\View\\Components\\BadgeComponent',
          'itemcomponent' => 'Filament\\Support\\View\\Components\\DropdownComponent\\ItemComponent',
          'iconcomponent' => 'Filament\\Support\\View\\Components\\DropdownComponent\\ItemComponent\\IconComponent',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'js' => 'Illuminate\\Support\\Js',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'generateDropdownItemHtml',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '46392f41196f2f8826d58e7b0a33692a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\View\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'size' => 'Filament\\Support\\Enums\\Size',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'badgecomponent' => 'Filament\\Support\\View\\Components\\BadgeComponent',
          'iconbuttoncomponent' => 'Filament\\Support\\View\\Components\\IconButtonComponent',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'js' => 'Illuminate\\Support\\Js',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'b0ef3b6949a27d9e2c7edc8f689f16ad' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\View\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'size' => 'Filament\\Support\\Enums\\Size',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'badgecomponent' => 'Filament\\Support\\View\\Components\\BadgeComponent',
          'iconbuttoncomponent' => 'Filament\\Support\\View\\Components\\IconButtonComponent',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'js' => 'Illuminate\\Support\\Js',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'generateIconButtonHtml',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '99bbb7b868e9df0b5e0cf76cf731b1e0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\View\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'fontweight' => 'Filament\\Support\\Enums\\FontWeight',
          'iconposition' => 'Filament\\Support\\Enums\\IconPosition',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'size' => 'Filament\\Support\\Enums\\Size',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'badgecomponent' => 'Filament\\Support\\View\\Components\\BadgeComponent',
          'linkcomponent' => 'Filament\\Support\\View\\Components\\LinkComponent',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'js' => 'Illuminate\\Support\\Js',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'ebaf7294d797266a6b917a53c59cd4b5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\View\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'fontweight' => 'Filament\\Support\\Enums\\FontWeight',
          'iconposition' => 'Filament\\Support\\Enums\\IconPosition',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'size' => 'Filament\\Support\\Enums\\Size',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'badgecomponent' => 'Filament\\Support\\View\\Components\\BadgeComponent',
          'linkcomponent' => 'Filament\\Support\\View\\Components\\LinkComponent',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'js' => 'Illuminate\\Support\\Js',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'generateLinkHtml',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'd5ec7ef243539681e8a925dd6f6b8825' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'actiongroup' => 'Filament\\Actions\\ActionGroup',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\BelongsToGroup',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\BelongsToGroup',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'b672ccb7bf8b486e2a7f6587b2ab86df' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'actiongroup' => 'Filament\\Actions\\ActionGroup',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'group',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\BelongsToGroup',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\BelongsToGroup',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'eddfc01b09ec96fd6ff785821e368e47' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'actiongroup' => 'Filament\\Actions\\ActionGroup',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getGroup',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\BelongsToGroup',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\BelongsToGroup',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '0345cd25757b5eb7db46b84a3a691449' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'actiongroup' => 'Filament\\Actions\\ActionGroup',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getRootGroup',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\BelongsToGroup',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\BelongsToGroup',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '31f086f6eda6c8a500a24605a99f8077' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'hasactions' => 'Filament\\Actions\\Contracts\\HasActions',
          'component' => 'Livewire\\Component',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\BelongsToLivewire',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\BelongsToLivewire',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'f17aa26426f737c4758f95b7a3b93464' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'hasactions' => 'Filament\\Actions\\Contracts\\HasActions',
          'component' => 'Livewire\\Component',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'livewire',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\BelongsToLivewire',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\BelongsToLivewire',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '9b9e1e1bc32dcdd8d444cf8698561fe6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'hasactions' => 'Filament\\Actions\\Contracts\\HasActions',
          'component' => 'Livewire\\Component',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getLivewire',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\BelongsToLivewire',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\BelongsToLivewire',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '81a99341356cd73f006ea7cf7084f7b4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'hasactions' => 'Filament\\Actions\\Contracts\\HasActions',
          'component' => 'Livewire\\Component',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getHasActionsLivewire',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\BelongsToLivewire',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\BelongsToLivewire',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '22f40cfc0d0b26be60290dce5705dd40' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'component' => 'Filament\\Schemas\\Components\\Component',
          'schema' => 'Filament\\Schemas\\Schema',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\BelongsToSchemaComponent',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\BelongsToSchemaComponent',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'a24b8b3a2f0f6cbb50cf6c03eb32c980' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'component' => 'Filament\\Schemas\\Components\\Component',
          'schema' => 'Filament\\Schemas\\Schema',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'schemaComponent',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\BelongsToSchemaComponent',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\BelongsToSchemaComponent',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '3aa7f61c2793d250ec86a7174371de03' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'component' => 'Filament\\Schemas\\Components\\Component',
          'schema' => 'Filament\\Schemas\\Schema',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'schemaContainer',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\BelongsToSchemaComponent',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\BelongsToSchemaComponent',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '64e758ddc7cbb75c2da9e779d4071910' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'component' => 'Filament\\Schemas\\Components\\Component',
          'schema' => 'Filament\\Schemas\\Schema',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getSchemaComponent',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\BelongsToSchemaComponent',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\BelongsToSchemaComponent',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '39ca2fd972611f0b5f595febb5681af7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'component' => 'Filament\\Schemas\\Components\\Component',
          'schema' => 'Filament\\Schemas\\Schema',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getSchemaContainer',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\BelongsToSchemaComponent',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\BelongsToSchemaComponent',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'a9727f52e9779a96c4c8b995e9bd4ea0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'table' => 'Filament\\Tables\\Table',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\BelongsToTable',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\BelongsToTable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'f1c7a52354ead43d65db43d3c11ecad7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'table' => 'Filament\\Tables\\Table',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'table',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\BelongsToTable',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\BelongsToTable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '02e2d465443a8f85068c709ebd80a081' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'table' => 'Filament\\Tables\\Table',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getTable',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\BelongsToTable',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\BelongsToTable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '7f034d59dc5884528f55f033fd867fd8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'table' => 'Filament\\Tables\\Table',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasTable',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\BelongsToTable',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\BelongsToTable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '676d8fc1395ec025eda95627b556b8f0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'actiongroup' => 'Filament\\Actions\\ActionGroup',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\CanBeHidden',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\CanBeHidden',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '7d2194d2273bcf5745e8c200ab2fde4e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'actiongroup' => 'Filament\\Actions\\ActionGroup',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hidden',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\CanBeHidden',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\CanBeHidden',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '1913a94562049f20963d7d2b27bda3b6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'actiongroup' => 'Filament\\Actions\\ActionGroup',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'visible',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\CanBeHidden',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\CanBeHidden',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'bbda84884e21750b953d0c7bf79a30f0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'actiongroup' => 'Filament\\Actions\\ActionGroup',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'baseIsHidden',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\CanBeHidden',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\CanBeHidden',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '2c3d929999958d4a45d4448e35c99ad3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'actiongroup' => 'Filament\\Actions\\ActionGroup',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'isHiddenInGroup',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\CanBeHidden',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\CanBeHidden',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'efbc0c201704a0749fc32a9c911ef6f7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'actiongroup' => 'Filament\\Actions\\ActionGroup',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'resolveIsHiddenInGroup',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\CanBeHidden',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\CanBeHidden',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'c5ef7e31958b49c408f8641d16dd3740' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'actiongroup' => 'Filament\\Actions\\ActionGroup',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'isVisible',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\CanBeHidden',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\CanBeHidden',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '83581a61a1ccf643a636b653fc751394' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'actiongroup' => 'Filament\\Actions\\ActionGroup',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'prepareVisibilityCache',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\CanBeHidden',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\CanBeHidden',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'c48a72b5a816b0ac43e9cc3d02ff10b8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'actiongroup' => 'Filament\\Actions\\ActionGroup',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getCurrentVisibilityRecordKey',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\CanBeHidden',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\CanBeHidden',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'dec4bc9d688a9fc4ba109cfe5996d480' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'actiongroup' => 'Filament\\Actions\\ActionGroup',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'clearVisibilityCache',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\CanBeHidden',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\CanBeHidden',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'fda8772ee413fd09768637df9e0d2438' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\CanBeLabeledFrom',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\CanBeLabeledFrom',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '968fe6a1df6f96e3efd948c9efece34d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'labeledFrom',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\CanBeLabeledFrom',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\CanBeLabeledFrom',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '48e210858820e66b539bf6030825544b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getLabeledFromBreakpoint',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\CanBeLabeledFrom',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\CanBeLabeledFrom',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '5cade1da9a014a57091714f81ee50a6b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasLabeledFromBreakpoint',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\CanBeLabeledFrom',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\CanBeLabeledFrom',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'c9e87959436eec9716259b0e9c9b5c51' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\CanBeOutlined',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\CanBeOutlined',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'a2ab4c269870afafdada6c522a232f22' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'outlined',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\CanBeOutlined',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\CanBeOutlined',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'd8dd482ceae09464e92241ac08682c2f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'isOutlined',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\CanBeOutlined',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\CanBeOutlined',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '2f066b491933be8e667a8ecd8e852ffc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasOutlined',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\CanBeOutlined',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\CanBeOutlined',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'ea6d834c5c07222e5e3e03ea767e84ba' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'width' => 'Filament\\Support\\Enums\\Width',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasDropdown',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasDropdown',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '631983be4cf6c89e5f1ed05ae04086a1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'width' => 'Filament\\Support\\Enums\\Width',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'dropdown',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasDropdown',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasDropdown',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '00e2c98842a95e9678bcea82226ba7a8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'width' => 'Filament\\Support\\Enums\\Width',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'dropdownPlacement',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasDropdown',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasDropdown',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '551287a5cdebb398195094ce5e4c17f5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'width' => 'Filament\\Support\\Enums\\Width',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'dropdownAutoPlacement',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasDropdown',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasDropdown',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '965d63e7bef18fc9c3d8956cb680d2e2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'width' => 'Filament\\Support\\Enums\\Width',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'defaultDropdownPlacement',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasDropdown',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasDropdown',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'e516e4658829c86d87457d6cd772f870' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'width' => 'Filament\\Support\\Enums\\Width',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'dropdownMaxHeight',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasDropdown',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasDropdown',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'e3577b76a34b421b3f46e272d92735cc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'width' => 'Filament\\Support\\Enums\\Width',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'dropdownOffset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasDropdown',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasDropdown',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'b87d2a383c906919f394a169b4febfd5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'width' => 'Filament\\Support\\Enums\\Width',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'dropdownWidth',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasDropdown',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasDropdown',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '18d6e1044a754412be49a93e49d28079' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'width' => 'Filament\\Support\\Enums\\Width',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'dropdownFlip',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasDropdown',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasDropdown',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '00c80cf6c3b951af03bd37ed2c819fb6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'width' => 'Filament\\Support\\Enums\\Width',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'dropdownTeleport',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasDropdown',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasDropdown',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'a8fc183a701f1579fc1a7fcb3dbf3e70' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'width' => 'Filament\\Support\\Enums\\Width',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'defaultDropdownTeleport',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasDropdown',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasDropdown',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'f8b771c2eab7dec7af0c02cfe02b2622' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'width' => 'Filament\\Support\\Enums\\Width',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getDropdownPlacement',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasDropdown',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasDropdown',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'af12c262a8136e9d6cecaa8cfe832dc9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'width' => 'Filament\\Support\\Enums\\Width',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getDropdownMaxHeight',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasDropdown',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasDropdown',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'a7e21e7330630ef9d5475101512957d5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'width' => 'Filament\\Support\\Enums\\Width',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getDropdownOffset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasDropdown',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasDropdown',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '3fccdab61abdb228eae316c53e0dabd0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'width' => 'Filament\\Support\\Enums\\Width',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getDropdownWidth',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasDropdown',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasDropdown',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'a386c5d157361af3462ed47b17264305' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'width' => 'Filament\\Support\\Enums\\Width',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasDropdownFlip',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasDropdown',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasDropdown',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'e49ee4eb4f324ea4293a359edddbff92' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'width' => 'Filament\\Support\\Enums\\Width',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasDropdownTeleport',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasDropdown',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasDropdown',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '462cc3724c38f2e686a34ad33165dddb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'width' => 'Filament\\Support\\Enums\\Width',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasDropdown',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasDropdown',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasDropdown',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'e7f850fcd7424e944033848fa5cb659c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasGroupedIcon',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasGroupedIcon',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '95d34c7a50d5f714bf5c10d91c112aaf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'groupedIcon',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasGroupedIcon',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasGroupedIcon',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '87a96470af3af68df9507c3a60f967af' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getGroupedIcon',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasGroupedIcon',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasGroupedIcon',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '5d03e8451b6ef2d7f61d3dcd361bdff4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasGroupedIcon',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasGroupedIcon',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasGroupedIcon',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '2d7e052c571519e52302311c89a08c6c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasLabel',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasLabel',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '23e2fd08da7697d90bb96f60422ec2f9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'disableLabel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasLabel',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasLabel',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '1c0a043539d2eb60533910456fb42ffd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hiddenLabel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasLabel',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasLabel',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '3732f3d4cdb333e1503180481f6e80fd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'label',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasLabel',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasLabel',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'c24ee3323b5bdf90babf3a8b7dc6a396' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'translateLabel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasLabel',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasLabel',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'ca5d92ac010a98a99b2361f583731242' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getLabel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasLabel',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasLabel',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '3b2f6ff408749d96910e5b06dfc33671' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'isLabelHidden',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasLabel',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasLabel',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'f1e5ca98cfba4170292cbd20151efba1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasLabelHidden',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasLabel',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasLabel',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '151bf2b968c55148b095513dc17eb561' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'size' => 'Filament\\Support\\Enums\\Size',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasSize',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasSize',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '2548407937a26548a8f884762a9bd0cb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'size' => 'Filament\\Support\\Enums\\Size',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'defaultSize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasSize',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasSize',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '3d3817964856b891988cb7b055aefd5b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'size' => 'Filament\\Support\\Enums\\Size',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'size',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasSize',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasSize',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '9ca93c20db3b43dacbb93b0a4783a1a8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'size' => 'Filament\\Support\\Enums\\Size',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getDefaultSize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasSize',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasSize',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'c5ca1c656195690cb8860f7f552f7f92' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'size' => 'Filament\\Support\\Enums\\Size',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getSize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasSize',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasSize',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '01d84db2a4621571885fcb981f26f024' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'size' => 'Filament\\Support\\Enums\\Size',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasSize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasSize',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasSize',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'a5189cdf93c47a64aaf5fbe1ec04c62c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'size' => 'Filament\\Support\\Enums\\Size',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasSmallSizeDefault',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\HasSize',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\HasSize',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'a300babbfaccc2d132525aaf82ff45be' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasBadge',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasBadge',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '2b081d2612c793219bd8cee426e44515' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'badge',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasBadge',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasBadge',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'e36569ee854381d34bf24842b5a21ab7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'indicator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasBadge',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasBadge',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '59243cb67ff5768355dbb015cb1287a2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'badgeColor',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasBadge',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasBadge',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '7079445de65f7a08097033829be5854f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'indicatorColor',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasBadge',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasBadge',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '42f04e7bf0b8a17cdf5751e6a1347c80' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getBadge',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasBadge',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasBadge',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '91416e94e89b8a5f3582febda491ee38' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getBadgeColor',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasBadge',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasBadge',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '444d27a380f82448e026570f6908df7d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasBadge',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasBadge',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasBadge',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'b1b08be7ba129f8ec6ffaf0545fc9db8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '40d6c0b164473c66afdfcb53bd85b1ea' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'badgeTooltip',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '7ca9e3411da806fcebec97fad4562ce4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getBadgeTooltip',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '3bb4d61c437ab6fedd0938329975b88e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasColor',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasColor',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '3463787c957a8ce69ca48b9df7e139e5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'color',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasColor',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasColor',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'e9f5fc8b622031039018b32ed230531b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'defaultColor',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasColor',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasColor',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '3ecd1cfcd826417a40bedf34f90b002f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getColor',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasColor',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasColor',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '7b97eef8e3af03ec2faa4bc6e25dfed2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasColor',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasColor',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasColor',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '8f91d17d7547d0c9385501d07984fca9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'd3ea43a2a05aa438167aa51a23b2eae6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'extraAttributes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '1001f5ba27346182002d40b97f8e490a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getExtraAttributes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '30277c05b82569d89b9dffc4642cde62' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getExtraAttributeBag',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '0a2e56d0a3e37ca61bdbcb5f2623b3a5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasExtraAttributes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '13614f3bcb9ce985d6e1a24ad881428e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'renderable' => 'Illuminate\\Contracts\\Support\\Renderable',
          'htmlstring' => 'Illuminate\\Support\\HtmlString',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasIcon',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasIcon',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '3e516cb963959a272647662796770f71' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'renderable' => 'Illuminate\\Contracts\\Support\\Renderable',
          'htmlstring' => 'Illuminate\\Support\\HtmlString',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'icon',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasIcon',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasIcon',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'cc1156d5ddfe7124a052d8e4ae6f874f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'renderable' => 'Illuminate\\Contracts\\Support\\Renderable',
          'htmlstring' => 'Illuminate\\Support\\HtmlString',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getBaseIcon',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasIcon',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasIcon',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'c03bda70907962dd34af389fc7e41061' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'renderable' => 'Illuminate\\Contracts\\Support\\Renderable',
          'htmlstring' => 'Illuminate\\Support\\HtmlString',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasIcon',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasIcon',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasIcon',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '5affaab7e7cb41d9f8e69ade54e11f0f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'iconposition' => 'Filament\\Support\\Enums\\IconPosition',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasIconPosition',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasIconPosition',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '418866599ea31bdd9990696e1576244b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'iconposition' => 'Filament\\Support\\Enums\\IconPosition',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'iconPosition',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasIconPosition',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasIconPosition',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '9e4230caff019b25097282e7471101fa' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'iconposition' => 'Filament\\Support\\Enums\\IconPosition',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getIconPosition',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasIconPosition',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasIconPosition',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'e0f1d4babae8ccffa38356bb84702896' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'iconposition' => 'Filament\\Support\\Enums\\IconPosition',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasIconPosition',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasIconPosition',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasIconPosition',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '3ac155ff0e42747bc6fd226e31905295' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasIconSize',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasIconSize',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'e02b43c2a6771838305e8d8e14be914e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'iconSize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasIconSize',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasIconSize',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '842cd41c3b35d31f36947a8c386d391a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getIconSize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasIconSize',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasIconSize',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'b536ac249caa112faec2b7368b33f9f0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasIconSize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasIconSize',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasIconSize',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'e17ce127e9e848da464d15601dd02ee7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasTooltip',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasTooltip',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '5767d185108244925e355899bfcb021f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'tooltip',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasTooltip',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasTooltip',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '15f976bee4e0791ccd212b45a4bc07ad' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getTooltip',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasTooltip',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasTooltip',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '7228c996dea77621ed0d44ac887b9e14' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Support\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasTooltip',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Support\\Concerns\\HasTooltip',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Support\\Concerns\\HasTooltip',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'defe9f15e628fc367a684b943d92874c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '866c596b0c828cd7e6ca922d169bc816' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'record',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'ec8a5e8ff0dfec250a476a05cd78568a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'resolveRecordUsing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '8a7b1b186289def99e520e6a5b14601b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'model',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '4ac7561c2854d3cb484a7fedf51c7bc2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'modelLabel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'e9612c42f1cf6353dc1cabaa4a2d2b99' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'pluralModelLabel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '8ff640a578531257a9c40147c7c30f29' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'recordTitle',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '859e2e643780a3bc5a82467425e36ba7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'recordTitleAttribute',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'fbbec4d7c583ee2358fd2355c198bdfb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getRecord',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'fd983fe8d95f176498e85a363f78bc02' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'ensureCorrectRecordType',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'fd882e5aa65d8a69b006d2f59b106bdf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getRecordTitle',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '773bdf5483bc3b8ab079071e8a9d1e84' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'resolveRecordKey',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '1e337ddde57f02f9b377536e671d05ed' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getCustomRecordTitle',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '362e540d652d2e41d56c94cdb19deb06' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getRecordTitleAttribute',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '467099d24fb295d22078f29b047916a5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getCustomRecordTitleAttribute',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '180913018171fc66b2a5925869677d65' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasCustomRecordTitle',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '2e5e1a85c6620cf18082154a1fea0aee' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasCustomRecordTitleAttribute',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '16b0c5ef0d90a99e173e2662d223f667' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasRecord',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'ff45401c3fed0db4d03eda2ee5b072f9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getModel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'a4324ce39a59b3c527a2e665f1eb5ef3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getCustomModel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '60648ad19a3e72930b48d2c506d46d78' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getModelLabel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '92afd5985c80d9b56bac2dfb7ca72b86' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getTitleCaseModelLabel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'c0faeffbf69d880011efaacfd5288937' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getCustomModelLabel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'cc1cddba8aad000f44c9de9eb538b535' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getPluralModelLabel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '1e801db828649bde2029ec98060697ce' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getTitleCasePluralModelLabel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '5d15f14f374f4b563334af34e6eabf9b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'action' => 'Filament\\Actions\\Action',
          'arrayrecord' => 'Filament\\Support\\ArrayRecord',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getCustomPluralModelLabel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/filament/actions/src/ActionGroup.php',
          1 => 'Filament\\Actions\\ActionGroup',
          2 => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'bdf1f117ee7b048b3a2b3ac96d1341d9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9410523c143bf16651ac0ef988a7d01b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'make',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd94e3240f0835afa76de296f738bf1e0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'setUp',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9692d7608c0958b22cdfb3efd0c67084' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'actions',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd9f9f8407c34bf10d54eb30bec724534' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'isBadge',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '337c47ae10b3e4522a01d35f879b65cc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'badge',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cb31a19ff3303d6ea4700fc4adbc26a8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'button',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fcca2b94d080922a4497de134e2f4e76' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'buttonGroup',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c785939dc2ed817e0af763d579c27dff' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'isButton',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '19c9b35cf38ac8923ba27523d63b952e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'isButtonGroup',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '35b6bb1e14940b47228ff00539360419' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'grouped',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '39c17c0461610af4fda25a8ff0c10a58' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'iconButton',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a83df487de9fafc476094e337ac0942b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'isIconButton',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '742abd7f43948cec59a92facb522225a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'link',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ea864a110c78b478609ca74b99b5fb15' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'isLink',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2c837b8ae6c1223fea525bca827faa2c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getLabel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8173feff83d3af5b4234d27a1e0b3ae2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getActions',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dd6c740aa17395003d7c0d2e04159b5c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getFlatActions',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '163810a8b6593b1ad302f38f88e6015a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'hasNonBulkAction',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e761fda3555b5c040fe2a880018aee7a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getIcon',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bb2f5792837b60b457a0553f84fa1dea' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'isHidden',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8f18a9c209574afa940c8c7a3e3a585a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'resolveIsHidden',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '89e8d36f2d3d0ee90f41a052a5277584' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'toArray',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7b51ea4f2e1a5dee3815b387a9186b3f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'fromArray',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4d6e3e13e8221f7234fc0318a9a92a06' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'isViewSafe',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bd3cf6611bfa515b4c8b3b6429da6af9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'resolveDefaultClosureDependencyForEvaluationByName',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '004a3782746a8bbea8b9d0ceb6420f52' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getSchemaComponentState',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'df14bd7779b0ab5de7aeb3d94e5fa480' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getSchemaState',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '58fcf031f1c6eb4f06a702ce5dad0bd5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'resolveDefaultClosureDependencyForEvaluationByType',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4fe4f58d88f209bca4700efb001695f9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'toEmbeddedHtml',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fa22f373635a812d848fd9652b5da22a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'triggerView',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '756e42b99a6a51f0a7f9cadd14e05ec8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'defaultTriggerView',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '16c28b3596a61ddd39a91b793e663235' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getTriggerView',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c6d8c6459d91fd3fcfc64b4ffb4f6fc1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getDefaultTriggerView',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd61e7aedeaae5570c7077592f0e9af0b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'toTriggerHtml',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1cc539d63d380a43e3bdb5d9afac3048' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'toBadgeTriggerHtml',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9dbf8f5642731ed4d8efc09dc192d541' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'toButtonTriggerHtml',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fa22717837e9da635e2408051c8101a7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'toGroupedTriggerHtml',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '224d6c9c6f3ef890ad9a73c5ebc1fef0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'toIconButtonTriggerHtml',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e11bc983203d0f435e61c1e3265bd8d6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'toLinkTriggerHtml',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '754987823a24452f8057f5489bdeb79b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'renderTrigger',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c89dcd7d5b2a4d0630c2ddec1d4477e5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getClone',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '166b3f80d3ce709b34e9d7d9fda59376' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'cloneActions',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7d501678732b3b30a0d6c425457e407f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'extraDropdownAttributes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4431aecd3ee0641355ec1ac032c3e720' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getExtraDropdownAttributes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '89c5f67eeed9421e74afee4e66925ad6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Actions',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'interactswithrecord' => 'Filament\\Actions\\Concerns\\InteractsWithRecord',
          'actionsiconalias' => 'Filament\\Actions\\View\\ActionsIconAlias',
          'hasembeddedview' => 'Filament\\Support\\Components\\Contracts\\HasEmbeddedView',
          'viewcomponent' => 'Filament\\Support\\Components\\ViewComponent',
          'hasbadge' => 'Filament\\Support\\Concerns\\HasBadge',
          'hasbadgetooltip' => 'Filament\\Support\\Concerns\\HasBadgeTooltip',
          'hascolor' => 'Filament\\Support\\Concerns\\HasColor',
          'hasextraattributes' => 'Filament\\Support\\Concerns\\HasExtraAttributes',
          'hasicon' => 'Filament\\Support\\Concerns\\HasIcon',
          'hasiconposition' => 'Filament\\Support\\Concerns\\HasIconPosition',
          'hasiconsize' => 'Filament\\Support\\Concerns\\HasIconSize',
          'hastooltip' => 'Filament\\Support\\Concerns\\HasTooltip',
          'scalableicon' => 'Filament\\Support\\Contracts\\ScalableIcon',
          'iconsize' => 'Filament\\Support\\Enums\\IconSize',
          'width' => 'Filament\\Support\\Enums\\Width',
          'filamenticon' => 'Filament\\Support\\Facades\\FilamentIcon',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
          'filamentcomponentattributebag' => 'Filament\\Support\\View\\ComponentAttributeBag',
          'cangeneratebadgehtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateBadgeHtml',
          'cangeneratebuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateButtonHtml',
          'cangeneratedropdownitemhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateDropdownItemHtml',
          'cangenerateiconbuttonhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateIconButtonHtml',
          'cangeneratelinkhtml' => 'Filament\\Support\\View\\Concerns\\CanGenerateLinkHtml',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'htmlable' => 'Illuminate\\Contracts\\Support\\Htmlable',
          'view' => 'Illuminate\\Contracts\\View\\View',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'str' => 'Illuminate\\Support\\Str',
          'componentattributebag' => 'Illuminate\\View\\ComponentAttributeBag',
          'logicexception' => 'LogicException',
        ),
         'className' => 'Filament\\Actions\\ActionGroup',
         'functionName' => 'getExtraDropdownAttributeBag',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/vendor/filament/actions/src/ActionGroup.php' => '5d34513ba0d9cbbc8f90b1ba49bfe77207a7eccc255f2311ef4eba828f51f76a',
      '/var/www/html/vendor/composer/../filament/support/src/View/Concerns/CanGenerateBadgeHtml.php' => 'ed747b18104c4a4eebe4326f59d85a15089c8dd0e45020a6d397d9cd2789f1d6',
      '/var/www/html/vendor/composer/../filament/support/src/View/Concerns/CanGenerateButtonHtml.php' => '4b2e65529ca10ed868fb19d8e9e9a41537efc4194679b5f739b4ac6455f8f635',
      '/var/www/html/vendor/composer/../filament/support/src/View/Concerns/CanGenerateDropdownItemHtml.php' => 'f1a4b8ecf4d9c41227b1c22d643ddf8d4eb1612e9630d2784dc791b64ce3c60a',
      '/var/www/html/vendor/composer/../filament/support/src/View/Concerns/CanGenerateIconButtonHtml.php' => '0cd3414601567d0b289aff98e7f038e7de8ecc3a41dfd55a922ff4515c24788e',
      '/var/www/html/vendor/composer/../filament/support/src/View/Concerns/CanGenerateLinkHtml.php' => '795b1b16093d8b48bc328e99858d67a9adc598068ffa1c51ff041590a61cab0e',
      '/var/www/html/vendor/composer/../filament/actions/src/Concerns/BelongsToGroup.php' => '1b55ffaa6143f833a1fc0ce5ee440074a7dfe74d7984f23159e3e9e408e01d82',
      '/var/www/html/vendor/composer/../filament/actions/src/Concerns/BelongsToLivewire.php' => 'd6789a99bec071c7b52ead6f863c7927b8dd3b1c2e97de0632d3ef0fbc4b4de5',
      '/var/www/html/vendor/composer/../filament/actions/src/Concerns/BelongsToSchemaComponent.php' => 'c4fadcf6751e8184ca19bf23a292fb6bd01cdf425d8cdd9bf646abb9ed1a387a',
      '/var/www/html/vendor/composer/../filament/actions/src/Concerns/BelongsToTable.php' => '8a6d293f724bc6a15b4c757d3b16de6a088b55ede483ad3f9e2e2920897c5057',
      '/var/www/html/vendor/composer/../filament/actions/src/Concerns/CanBeHidden.php' => '66a8721ed30776763437b865c27ce45253ff3176bb9588cc39689936e8b355da',
      '/var/www/html/vendor/composer/../filament/actions/src/Concerns/CanBeLabeledFrom.php' => '48cf54d922c30d133663eff942ed57266e6762989ce3e559e5134e2729986691',
      '/var/www/html/vendor/composer/../filament/actions/src/Concerns/CanBeOutlined.php' => '053da98e6611cb66b3581bd272325df5d3d4d484035789cd7f4eae83135820ab',
      '/var/www/html/vendor/composer/../filament/actions/src/Concerns/HasDropdown.php' => '8b53bbbd9fb34863f568ae5c232402f5f332f6101b9277e235127601d1d94b2a',
      '/var/www/html/vendor/composer/../filament/actions/src/Concerns/HasGroupedIcon.php' => '0416d4f9c9d878ddbce82bde64b02bacab936445821393cd3783c9179e207cee',
      '/var/www/html/vendor/composer/../filament/actions/src/Concerns/HasLabel.php' => '80d849331b899ac99966b2d528a5570eac411a5d007b5110ffac4e55db774cb5',
      '/var/www/html/vendor/composer/../filament/actions/src/Concerns/HasSize.php' => 'c7e17ca1690cbe913ec5d1fc21b9936fcad8d4bda4d52ecad35bd77bd5b38eae',
      '/var/www/html/vendor/composer/../filament/support/src/Concerns/HasBadge.php' => 'd43dc7af8a85026aa60d2bba7975d99ba0ca9f841f91eb2be5b9d7dc2e7075fb',
      '/var/www/html/vendor/composer/../filament/support/src/Concerns/HasBadgeTooltip.php' => '5eca6b59488c69fd3996cdff15345fdc8ed603859d654eef58a9d34170bb12d0',
      '/var/www/html/vendor/composer/../filament/support/src/Concerns/HasColor.php' => 'd284c41218336f8d8033a7c9614794fdc091c81078824405c1896b6f4973dd81',
      '/var/www/html/vendor/composer/../filament/support/src/Concerns/HasExtraAttributes.php' => '8c1fd232f1436148cf0bae84a4b1fc0abc570edcd221cd364e18e663fcbbab18',
      '/var/www/html/vendor/composer/../filament/support/src/Concerns/HasIcon.php' => '62fa064d0e98d94f05a2efa41addf90392a1d54c2e2780d8d4fa0834b08cbd14',
      '/var/www/html/vendor/composer/../filament/support/src/Concerns/HasIconPosition.php' => 'bb7042edac0d0904b3ac233641e5c0cc7724475fbb0627d24e829e41cb1d394d',
      '/var/www/html/vendor/composer/../filament/support/src/Concerns/HasIconSize.php' => '1ad44849cfad94a344bd147d99109c9bbed674591d05c0d2d39e2b8275ec6518',
      '/var/www/html/vendor/composer/../filament/support/src/Concerns/HasTooltip.php' => '69905ba5c103e7e9c957bd3ae5adc67b28c0e57191c33f869773a432193a9b39',
      '/var/www/html/vendor/composer/../filament/actions/src/Concerns/InteractsWithRecord.php' => 'be14cceffc1d4b01ca56886180bc2fe06a281c4c8f50a00243e432be77fc1ec8',
    ),
  ),
));