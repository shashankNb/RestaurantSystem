<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/support/src/Concerns/CanWrapHeader.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-76ce00cdaeb22cd0ecf1337e2f4c3d08b2e8d9c189e94cac2ce41f122a82d560-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\support\\concerns\\canwrapheader' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));