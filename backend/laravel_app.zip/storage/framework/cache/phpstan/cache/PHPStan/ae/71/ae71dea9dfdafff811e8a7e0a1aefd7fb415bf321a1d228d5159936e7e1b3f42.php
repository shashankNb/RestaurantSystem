<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../laravel/framework/src/Illuminate/Contracts/Auth/Access/Authorizable.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-249faa210b467b778282218c7455448dbbf85370a2856f51e48971b7c8eb4095-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\contracts\\auth\\access\\authorizable' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));