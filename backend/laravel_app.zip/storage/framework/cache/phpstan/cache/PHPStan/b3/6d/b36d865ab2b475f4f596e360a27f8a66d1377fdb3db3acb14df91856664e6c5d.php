<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/filament/src/Models/Contracts/HasTenants.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-c2929e00a9e3c1794e63412eae4aecf5176be7eb674932b20d1ba693aec334ae-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\models\\contracts\\hastenants' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));