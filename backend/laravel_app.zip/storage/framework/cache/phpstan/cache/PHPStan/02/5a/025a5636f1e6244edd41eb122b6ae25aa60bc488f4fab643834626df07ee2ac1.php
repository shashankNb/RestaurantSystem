<?php declare(strict_types = 1);

// ftm-/var/www/html/vendor/filament/filament/src/Models/Contracts/HasTenants.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'b53eee0e21b5c4e0665f8c37408ea671' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Models\\Contracts',
         'uses' => 
        array (
          'panel' => 'Filament\\Panel',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'Filament\\Models\\Contracts\\HasTenants',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '242edf34b6af1e9b27b0327434e1af95' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Models\\Contracts',
         'uses' => 
        array (
          'panel' => 'Filament\\Panel',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'Filament\\Models\\Contracts\\HasTenants',
         'functionName' => 'canAccessTenant',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2ffaff8b5e7cb452230507e8f9102814' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Filament\\Models\\Contracts',
         'uses' => 
        array (
          'panel' => 'Filament\\Panel',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'Filament\\Models\\Contracts\\HasTenants',
         'functionName' => 'getTenants',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/vendor/filament/filament/src/Models/Contracts/HasTenants.php' => 'c2929e00a9e3c1794e63412eae4aecf5176be7eb674932b20d1ba693aec334ae',
    ),
  ),
));