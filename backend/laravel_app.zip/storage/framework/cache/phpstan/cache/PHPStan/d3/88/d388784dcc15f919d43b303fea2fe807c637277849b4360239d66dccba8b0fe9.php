<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/support/src/Concerns/HasExtraAttributes.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-8c1fd232f1436148cf0bae84a4b1fc0abc570edcd221cd364e18e663fcbbab18-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\support\\concerns\\hasextraattributes' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));