<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../stripe/stripe-php/lib/Service/InvoiceItemService.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-194021218decb7fbc399dbd189d53e35ff2c3356f6e7f8b9b7a91ed0c1e03350-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'stripe\\service\\invoiceitemservice' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));