<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/forms/src/Components/Toggle.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-3bcc375def03e9d478b0558f4e5505b61db2bfe08a8e9dc0d0b759c4206c022f-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\forms\\components\\toggle' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));