<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/support/src/Concerns/HasLineClamp.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-3192bb19d5c1a65ac1c3ba1cd67a0ea4c9831b4793cfc75058d5a428c0889ede-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\support\\concerns\\haslineclamp' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));