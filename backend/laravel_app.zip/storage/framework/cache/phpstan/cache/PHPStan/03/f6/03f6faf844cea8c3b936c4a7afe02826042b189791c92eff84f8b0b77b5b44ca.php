<?php declare(strict_types = 1);

// ftm-/var/www/html/database/migrations/2026_10_01_000100_create_dining_tables_table.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'ea61f27af76562f983dd48ddf7729719' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'migration' => 'Illuminate\\Database\\Migrations\\Migration',
          'blueprint' => 'Illuminate\\Database\\Schema\\Blueprint',
          'schema' => 'Illuminate\\Support\\Facades\\Schema',
        ),
         'className' => NULL,
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8750ab39c639e92bdecedc7ed17179ee' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'migration' => 'Illuminate\\Database\\Migrations\\Migration',
          'blueprint' => 'Illuminate\\Database\\Schema\\Blueprint',
          'schema' => 'Illuminate\\Support\\Facades\\Schema',
        ),
         'className' => 'AnonymousClass962e9d378801b7bc81de41f3a911076b',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '83c9e27560b6a3736498dcf79680714c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'migration' => 'Illuminate\\Database\\Migrations\\Migration',
          'blueprint' => 'Illuminate\\Database\\Schema\\Blueprint',
          'schema' => 'Illuminate\\Support\\Facades\\Schema',
        ),
         'className' => 'AnonymousClass962e9d378801b7bc81de41f3a911076b',
         'functionName' => 'up',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e50a3025d92daacd380a8559807bed53' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'migration' => 'Illuminate\\Database\\Migrations\\Migration',
          'blueprint' => 'Illuminate\\Database\\Schema\\Blueprint',
          'schema' => 'Illuminate\\Support\\Facades\\Schema',
        ),
         'className' => 'AnonymousClass962e9d378801b7bc81de41f3a911076b',
         'functionName' => 'down',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/database/migrations/2026_10_01_000100_create_dining_tables_table.php' => 'a1db45531a432f23183e023dd81e46882273c70cbc8b98cf952f65f8f16c10ca',
    ),
  ),
));