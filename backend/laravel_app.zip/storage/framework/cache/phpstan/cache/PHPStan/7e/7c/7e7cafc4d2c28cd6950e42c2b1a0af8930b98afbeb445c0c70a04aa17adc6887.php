<?php declare(strict_types = 1);

// ftm-/var/www/html/vendor/stripe/stripe-php/lib/Exception/SignatureVerificationException.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '818e4fcbfbc80c0e5023a790ca69099b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Stripe\\Exception',
         'uses' => 
        array (
        ),
         'className' => 'Stripe\\Exception\\SignatureVerificationException',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a8115c1dbd4eeba355268a3d3e636e8e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Stripe\\Exception',
         'uses' => 
        array (
        ),
         'className' => 'Stripe\\Exception\\SignatureVerificationException',
         'functionName' => 'factory',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Stripe\\Exception',
           'uses' => 
          array (
          ),
           'className' => 'Stripe\\Exception\\SignatureVerificationException',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dd591bf2b58e52fea029fd98fe170df8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Stripe\\Exception',
         'uses' => 
        array (
        ),
         'className' => 'Stripe\\Exception\\SignatureVerificationException',
         'functionName' => 'getHttpBody',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Stripe\\Exception',
           'uses' => 
          array (
          ),
           'className' => 'Stripe\\Exception\\SignatureVerificationException',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5abae403b5a6c53f1d17e62ad546f64f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Stripe\\Exception',
         'uses' => 
        array (
        ),
         'className' => 'Stripe\\Exception\\SignatureVerificationException',
         'functionName' => 'setHttpBody',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Stripe\\Exception',
           'uses' => 
          array (
          ),
           'className' => 'Stripe\\Exception\\SignatureVerificationException',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '25dbf43710f40cbc10cb15cb8bcbd7a6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Stripe\\Exception',
         'uses' => 
        array (
        ),
         'className' => 'Stripe\\Exception\\SignatureVerificationException',
         'functionName' => 'getSigHeader',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Stripe\\Exception',
           'uses' => 
          array (
          ),
           'className' => 'Stripe\\Exception\\SignatureVerificationException',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cb01637cf86e6846a0e9cffb3e481917' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Stripe\\Exception',
         'uses' => 
        array (
        ),
         'className' => 'Stripe\\Exception\\SignatureVerificationException',
         'functionName' => 'setSigHeader',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Stripe\\Exception',
           'uses' => 
          array (
          ),
           'className' => 'Stripe\\Exception\\SignatureVerificationException',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/vendor/stripe/stripe-php/lib/Exception/SignatureVerificationException.php' => 'b336f904d4747b3c948385d2a588cb6985cef265061a0f725835ad7d11d3630a',
    ),
  ),
));