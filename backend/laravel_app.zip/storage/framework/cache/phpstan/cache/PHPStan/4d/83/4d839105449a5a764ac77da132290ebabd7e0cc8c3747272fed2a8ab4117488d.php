<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../laravel/sanctum/src/Sanctum.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-cf72df8fd0650cf17cb83ef396841b6ee05065873eb83ce545b66aac67fa32f5-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'laravel\\sanctum\\sanctum' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));