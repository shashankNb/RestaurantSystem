<?php declare(strict_types = 1);

// ftm-/var/www/html/vendor/laravel/framework/src/Illuminate/Support/Facades/RateLimiter.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '031d3ef7c1ce2f090e94613ce48d8c38' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Facades',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\Support\\Facades\\RateLimiter',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '36e7905073e2200eceee3a0cab802e6b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Facades',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\Support\\Facades\\RateLimiter',
         'functionName' => 'getFacadeAccessor',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Facades',
           'uses' => 
          array (
          ),
           'className' => 'Illuminate\\Support\\Facades\\RateLimiter',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/vendor/laravel/framework/src/Illuminate/Support/Facades/RateLimiter.php' => '791309ff56e7058750049fb1c059422dbfc5cc13034bdbef940567793e99b3ad',
    ),
  ),
));