<?php declare(strict_types = 1);

// ftm-/var/www/html/vendor/larastan/larastan/stubs/common/View/View.stub
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '73bef19da27e534111adfce83b85a6ff' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\View',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\View\\View',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a66f19745a988f1b0b525ca082726bc2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\View',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\View\\Factory',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/vendor/larastan/larastan/stubs/common/View/View.stub' => 'f2ffe48947b3196223682620305873de6e2ddb9cf2bc5b3098839633e17d739a',
    ),
  ),
));