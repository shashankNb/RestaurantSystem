<?php declare(strict_types = 1);

// ftm-/var/www/html/app/Filament/Support/BrandPalette.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'a9bcc9caec425e7846af2491d19faf25' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Filament\\Support',
         'uses' => 
        array (
          'color' => 'Filament\\Support\\Colors\\Color',
        ),
         'className' => 'App\\Filament\\Support\\BrandPalette',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '871a1f27b79dae41b7294bfba23b2f01' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Filament\\Support',
         'uses' => 
        array (
          'color' => 'Filament\\Support\\Colors\\Color',
        ),
         'className' => 'App\\Filament\\Support\\BrandPalette',
         'functionName' => 'fromHex',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Filament\\Support',
           'uses' => 
          array (
            'color' => 'Filament\\Support\\Colors\\Color',
          ),
           'className' => 'App\\Filament\\Support\\BrandPalette',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5d1196b19873be6cb8a56fd1673e55a1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Filament\\Support',
         'uses' => 
        array (
          'color' => 'Filament\\Support\\Colors\\Color',
        ),
         'className' => 'App\\Filament\\Support\\BrandPalette',
         'functionName' => 'oklch',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'App\\Filament\\Support',
           'uses' => 
          array (
            'color' => 'Filament\\Support\\Colors\\Color',
          ),
           'className' => 'App\\Filament\\Support\\BrandPalette',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/app/Filament/Support/BrandPalette.php' => '32b73e53fe0de0f4035bc130a4a66ad371dcbd6405db3153578cfce49767b567',
    ),
  ),
));