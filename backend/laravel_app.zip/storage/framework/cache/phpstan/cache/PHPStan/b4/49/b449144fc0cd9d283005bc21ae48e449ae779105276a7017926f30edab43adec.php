<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../stripe/stripe-php/lib/Exception/ExceptionInterface.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-aa803b9e2be93eed65dba7469dfae9fe92a14ebba3e05c2330ec006d17d2d5d2-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'stripe\\exception\\exceptioninterface' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));