<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../livewire/livewire/src/Features/SupportValidation/HandlesValidation.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-167dac5fece2a46873c4465df0712a71ba5e4be7031ad09f4c7ce6d19212e490-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'livewire\\features\\supportvalidation\\handlesvalidation' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));