<?php declare(strict_types = 1);

// ftm-/var/www/html/app/Filament/Resources/DiningTables/Pages/ManageDiningTables.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'defe088027a22411b6ddd8f0fde6ace4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Filament\\Resources\\DiningTables\\Pages',
         'uses' => 
        array (
          'diningtableresource' => 'App\\Filament\\Resources\\DiningTables\\DiningTableResource',
          'restaurant' => 'App\\Models\\Restaurant',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'filament' => 'Filament\\Facades\\Filament',
          'textinput' => 'Filament\\Forms\\Components\\TextInput',
          'notification' => 'Filament\\Notifications\\Notification',
          'managerecords' => 'Filament\\Resources\\Pages\\ManageRecords',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
        ),
         'className' => 'App\\Filament\\Resources\\DiningTables\\Pages\\ManageDiningTables',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2d68d34e9d230024e9c943d2a3fca9f3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Filament\\Resources\\DiningTables\\Pages',
         'uses' => 
        array (
          'diningtableresource' => 'App\\Filament\\Resources\\DiningTables\\DiningTableResource',
          'restaurant' => 'App\\Models\\Restaurant',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'filament' => 'Filament\\Facades\\Filament',
          'textinput' => 'Filament\\Forms\\Components\\TextInput',
          'notification' => 'Filament\\Notifications\\Notification',
          'managerecords' => 'Filament\\Resources\\Pages\\ManageRecords',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
        ),
         'className' => 'App\\Filament\\Resources\\DiningTables\\Pages\\ManageDiningTables',
         'functionName' => 'getHeaderActions',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a9cefbcd243cb8c9e6bf6e6a0f86441f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Filament\\Resources\\DiningTables\\Pages',
         'uses' => 
        array (
          'diningtableresource' => 'App\\Filament\\Resources\\DiningTables\\DiningTableResource',
          'restaurant' => 'App\\Models\\Restaurant',
          'action' => 'Filament\\Actions\\Action',
          'createaction' => 'Filament\\Actions\\CreateAction',
          'filament' => 'Filament\\Facades\\Filament',
          'textinput' => 'Filament\\Forms\\Components\\TextInput',
          'notification' => 'Filament\\Notifications\\Notification',
          'managerecords' => 'Filament\\Resources\\Pages\\ManageRecords',
          'heroicon' => 'Filament\\Support\\Icons\\Heroicon',
        ),
         'className' => 'App\\Filament\\Resources\\DiningTables\\Pages\\ManageDiningTables',
         'functionName' => 'addTables',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/app/Filament/Resources/DiningTables/Pages/ManageDiningTables.php' => 'dee69a6af2595bc74cbd3d813f1a97f02322abbfbffa9e8179ffa09beca384e3',
    ),
  ),
));