<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../stripe/stripe-php/lib/Util/RequestOptions.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-920c919af97026707119737188388d1e181eea874b83808e71f8c16554c11ea5-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'stripe\\util\\requestoptions' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));