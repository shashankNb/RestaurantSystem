<?php declare(strict_types = 1);

// ftm-/var/www/html/database/factories/ModifierOptionFactory.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'bd72d205091ee4922c0f6895fab01e99' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Database\\Factories',
         'uses' => 
        array (
          'modifiergroup' => 'App\\Models\\ModifierGroup',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
        ),
         'className' => 'Database\\Factories\\ModifierOptionFactory',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '770ad5feda6a5bcfe80d5498bea87ac9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Database\\Factories',
         'uses' => 
        array (
          'modifiergroup' => 'App\\Models\\ModifierGroup',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
        ),
         'className' => 'Database\\Factories\\ModifierOptionFactory',
         'functionName' => 'definition',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Database\\Factories',
           'uses' => 
          array (
            'modifiergroup' => 'App\\Models\\ModifierGroup',
            'modifieroption' => 'App\\Models\\ModifierOption',
            'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
          ),
           'className' => 'Database\\Factories\\ModifierOptionFactory',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4b6094575861f785a3ef511e5d359e4f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Database\\Factories',
         'uses' => 
        array (
          'modifiergroup' => 'App\\Models\\ModifierGroup',
          'modifieroption' => 'App\\Models\\ModifierOption',
          'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
        ),
         'className' => 'Database\\Factories\\ModifierOptionFactory',
         'functionName' => 'soldOut',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Database\\Factories',
           'uses' => 
          array (
            'modifiergroup' => 'App\\Models\\ModifierGroup',
            'modifieroption' => 'App\\Models\\ModifierOption',
            'factory' => 'Illuminate\\Database\\Eloquent\\Factories\\Factory',
          ),
           'className' => 'Database\\Factories\\ModifierOptionFactory',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/database/factories/ModifierOptionFactory.php' => '2f0e7a8e2559d634f579a45ccc1865b2fd04fec0844bb9944b6ad5b1180e19a9',
    ),
  ),
));