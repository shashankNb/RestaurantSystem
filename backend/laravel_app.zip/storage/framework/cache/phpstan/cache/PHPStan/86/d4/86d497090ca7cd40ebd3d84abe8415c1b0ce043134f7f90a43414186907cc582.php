<?php declare(strict_types = 1);

// ftm-/var/www/html/vendor/stripe/stripe-php/lib/TransferReversal.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'b28812eefe1a10f83842cbfe63fe2262' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Stripe',
         'uses' => 
        array (
        ),
         'className' => 'Stripe\\TransferReversal',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '55d53b61ea2bf9deedef54df0a812727' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Stripe\\ApiOperations',
         'uses' => 
        array (
        ),
         'className' => 'Stripe\\TransferReversal',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Stripe\\ApiOperations\\Update',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/stripe/stripe-php/lib/TransferReversal.php',
          1 => 'Stripe\\TransferReversal',
          2 => 'Stripe\\ApiOperations\\Update',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '080fe1d7897afdae0957462d028befef' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Stripe\\ApiOperations',
         'uses' => 
        array (
        ),
         'className' => 'Stripe\\TransferReversal',
         'functionName' => 'update',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Stripe\\ApiOperations',
           'uses' => 
          array (
          ),
           'className' => 'Stripe\\TransferReversal',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Stripe\\ApiOperations\\Update',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Stripe\\ApiOperations\\Update',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/stripe/stripe-php/lib/TransferReversal.php',
          1 => 'Stripe\\TransferReversal',
          2 => 'Stripe\\ApiOperations\\Update',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'e8c9b6652824e3530791f3f9cf36c7fb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Stripe\\ApiOperations',
         'uses' => 
        array (
        ),
         'className' => 'Stripe\\TransferReversal',
         'functionName' => '_save',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Stripe\\ApiOperations',
           'uses' => 
          array (
          ),
           'className' => 'Stripe\\TransferReversal',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Stripe\\ApiOperations\\Update',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Stripe\\ApiOperations\\Update',
         'traitData' => 
        array (
          0 => '/var/www/html/vendor/stripe/stripe-php/lib/TransferReversal.php',
          1 => 'Stripe\\TransferReversal',
          2 => 'Stripe\\ApiOperations\\Update',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'f53d43dd06ef95534a995346f77068f6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Stripe',
         'uses' => 
        array (
        ),
         'className' => 'Stripe\\TransferReversal',
         'functionName' => 'instanceUrl',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Stripe',
           'uses' => 
          array (
          ),
           'className' => 'Stripe\\TransferReversal',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '066107690d26daf5907d098c767e400f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Stripe',
         'uses' => 
        array (
        ),
         'className' => 'Stripe\\TransferReversal',
         'functionName' => 'save',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Stripe',
           'uses' => 
          array (
          ),
           'className' => 'Stripe\\TransferReversal',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/vendor/stripe/stripe-php/lib/TransferReversal.php' => '650b29e673abedcab360c87d3b89dd1c6380fadd8c7d1aa22703e9a66da45778',
      '/var/www/html/vendor/composer/../stripe/stripe-php/lib/ApiOperations/Update.php' => '49cf10f127d38ca2abe071d779bfc6ae02cadde767406a345f5ce25be83212b6',
    ),
  ),
));