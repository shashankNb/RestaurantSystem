<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../stripe/stripe-php/lib/Service/ApplicationFeeService.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-5a6eeca73b2d41991638531eeaed1982ddf22480ecdfe822e031402d39514d70-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'stripe\\service\\applicationfeeservice' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));