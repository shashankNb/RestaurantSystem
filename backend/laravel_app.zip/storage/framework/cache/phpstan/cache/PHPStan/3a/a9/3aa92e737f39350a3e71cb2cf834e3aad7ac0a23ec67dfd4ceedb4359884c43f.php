<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/filament/src/Billing/Providers/Contracts/BillingProvider.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Filament\Billing\Providers\Contracts\BillingProvider
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-4afdc4682c7ef45d24551e1788566a8531c2f26dab06c5526b2fd41519f99376-8.5.11-6.73.0.5',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
        'filename' => '/var/www/html/vendor/composer/../filament/filament/src/Billing/Providers/Contracts/BillingProvider.php',
      ),
    ),
    'namespace' => 'Filament\\Billing\\Providers\\Contracts',
    'name' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
    'shortName' => 'BillingProvider',
    'isInterface' => true,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 7,
    'endLine' => 15,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => NULL,
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'getRouteAction' => 
      array (
        'name' => 'getRouteAction',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionUnionType',
          'data' => 
          array (
            'types' => 
            array (
              0 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'string',
                  'isIdentifier' => true,
                ),
              ),
              1 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'Closure',
                  'isIdentifier' => false,
                ),
              ),
              2 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'array',
                  'isIdentifier' => true,
                ),
              ),
            ),
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * @return class-string | callable-string | Closure | array<class-string, string>
 */',
        'startLine' => 12,
        'endLine' => 12,
        'startColumn' => 5,
        'endColumn' => 63,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Filament\\Billing\\Providers\\Contracts',
        'declaringClassName' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
        'implementingClassName' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
        'currentClassName' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
        'aliasName' => NULL,
      ),
      'getSubscribedMiddleware' => 
      array (
        'name' => 'getSubscribedMiddleware',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'string',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 14,
        'endLine' => 14,
        'startColumn' => 5,
        'endColumn' => 54,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Filament\\Billing\\Providers\\Contracts',
        'declaringClassName' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
        'implementingClassName' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
        'currentClassName' => 'Filament\\Billing\\Providers\\Contracts\\BillingProvider',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));