<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../filament/filament/src/Panel/Concerns/HasBreadcrumbs.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-476a08819cff152393b86da935e292c3f011003ec9e9eacb74e37c4cc2c8f3f2-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'filament\\panel\\concerns\\hasbreadcrumbs' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));