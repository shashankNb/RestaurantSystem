<?php declare(strict_types = 1);

// osfsl-/var/www/html/vendor/composer/../league/flysystem/src/FilesystemAdapter.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-8d917a716b1cd3bed2118d7bbfea40bacae69662556e36554eec214061057483-8.5.11',
   'data' => 
  array (
    'classes' => 
    array (
      'league\\flysystem\\filesystemadapter' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));