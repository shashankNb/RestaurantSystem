<?php declare(strict_types = 1);

// ftm-/var/www/html/app/Http/Controllers/Api/MenuController.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '851e1e18a36d3cb144217d562c80bc76' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Http\\Controllers\\Api',
         'uses' => 
        array (
          'controller' => 'App\\Http\\Controllers\\Controller',
          'menucategoryresource' => 'App\\Http\\Resources\\MenuCategoryResource',
          'menucategory' => 'App\\Models\\MenuCategory',
          'restaurant' => 'App\\Models\\Restaurant',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'jsonresponse' => 'Illuminate\\Http\\JsonResponse',
        ),
         'className' => 'App\\Http\\Controllers\\Api\\MenuController',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2002690ec73c89b3971ceb32447cb506' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'App\\Http\\Controllers\\Api',
         'uses' => 
        array (
          'controller' => 'App\\Http\\Controllers\\Controller',
          'menucategoryresource' => 'App\\Http\\Resources\\MenuCategoryResource',
          'menucategory' => 'App\\Models\\MenuCategory',
          'restaurant' => 'App\\Models\\Restaurant',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'jsonresponse' => 'Illuminate\\Http\\JsonResponse',
        ),
         'className' => 'App\\Http\\Controllers\\Api\\MenuController',
         'functionName' => 'show',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/var/www/html/app/Http/Controllers/Api/MenuController.php' => '411f09f7871a87b22a206a9aeedb99c50685e847496815f56c2e61cf18d3b4a6',
    ),
  ),
));